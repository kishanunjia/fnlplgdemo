<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/



Auth::routes();

//Route::get('register', 'Auth\AuthController@showRegistrationForm');
//Route::post('register', 'Auth\RegisterController@register');

Route::get('/adminpanel', 'AuthenticationController@index');
Route::post('/logincheck', 'AuthenticationController@logincheck');


Route::get('/adminpanel/dashboard', 'adminpanel\DashboardController@index')->middleware('admin');
Route::get('/adminpanel/general_option', 'adminpanel\SettingController@general_option')->middleware('admin')->name('general_option');

Route::get('/adminpanel/email_option', 'adminpanel\SettingController@email_option')->middleware('admin')->name('email_option');


Route::post('/adminpanel/update_general', 'adminpanel\SettingController@update_general')->middleware('admin')->name('update_general');

Route::post('/adminpanel/update_email', 'adminpanel\SettingController@update_email')->middleware('admin')->name('update_email');

Route::get('/adminpanel/product-attributes', 'adminpanel\ProductattributesController@index')->middleware('admin')->name('product_attributes');


Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');

//Route::get('/adminpanel/manage-color', 'adminpanel\ProductattributesController@manage_color')->middleware('admin')->name('manage_color');

Route::group(array('prefix' => '/adminpanel/manage-color','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'manage_color', 'uses' => 'adminpanel\ProductattributesController@manage_color'));
	Route::get('delete', 'adminpanel\ProductattributesController@delete');
	Route::get('search', 'adminpanel\ProductattributesController@search');	
});


Route::group(array('prefix' => '/adminpanel/manage-brand','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'manage_brand', 'uses' => 'adminpanel\ProductattributesController@manage_brand'));	
	Route::get('add-new', 'adminpanel\ProductattributesController@add_brand');
	Route::get('search', 'adminpanel\ProductattributesController@search_brand');
	Route::post('create', 'adminpanel\ProductattributesController@create_brand');	
	Route::get('edit/{id}', 'adminpanel\ProductattributesController@edit_brand');	
	Route::post('update', 'adminpanel\ProductattributesController@update_brand');
	Route::get('delete', 'adminpanel\ProductattributesController@brand_delete');			
});

Route::group(array('prefix' => '/adminpanel/manage-type','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'manage_type', 'uses' => 'adminpanel\ProductattributesController@manage_type'));
	Route::get('search', 'adminpanel\ProductattributesController@search_type');
	Route::get('add-new', 'adminpanel\ProductattributesController@add_type');
	Route::post('create', 'adminpanel\ProductattributesController@create_type');
	Route::get('edit/{id}', 'adminpanel\ProductattributesController@edit_type');
	Route::post('update', 'adminpanel\ProductattributesController@update_type');		
	Route::get('delete', 'adminpanel\ProductattributesController@type_delete');	
});

Route::group(array('prefix' => '/adminpanel/products','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'products', 'uses' => 'adminpanel\ProductsController@index'));
	Route::get('search', 'adminpanel\ProductsController@search');
	Route::get('add-new', 'adminpanel\ProductsController@add');
	Route::post('create', 'adminpanel\ProductsController@create');
	Route::get('edit/{id}', 'adminpanel\ProductsController@edit');
	Route::post('update', 'adminpanel\ProductsController@update');
	Route::get('delete', 'adminpanel\ProductsController@delete');	
	Route::post('productdetailimages', 'adminpanel\ProductsController@productdetailimages');	
	Route::post('deleteproimg', 'adminpanel\ProductsController@deleteproimg');	
});

Route::group(array('prefix' => '/adminpanel/cmspage','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'cmspage', 'uses' => 'adminpanel\CmspageController@index'));
	Route::get('search', 'adminpanel\CmspageController@search');
	Route::get('add-new', 'adminpanel\CmspageController@add');
	Route::post('create', 'adminpanel\CmspageController@create');
	Route::get('edit/{id}', 'adminpanel\CmspageController@edit');
	Route::post('update', 'adminpanel\CmspageController@update');
	Route::post('addmeta', 'adminpanel\CmspageController@addmeta');
	Route::post('editmeta', 'adminpanel\CmspageController@editmeta');
	Route::post('deletemeta', 'adminpanel\CmspageController@deletemeta');
	Route::get('delete', 'adminpanel\CmspageController@delete');
	
	Route::post('catproduct', 'adminpanel\CmspageController@get_cat_prod');
	Route::post('brandroduct', 'adminpanel\CmspageController@get_brand_prod');
		
});	

Route::group(array('prefix' => '/adminpanel/categories','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'categories', 'uses' => 'adminpanel\ProductcategoryController@index'));
	Route::get('search', 'adminpanel\ProductcategoryController@search');
	Route::get('add-new', 'adminpanel\ProductcategoryController@add');
	Route::post('create', 'adminpanel\ProductcategoryController@create');
	Route::get('edit/{id}', 'adminpanel\ProductcategoryController@edit');
	Route::post('update', 'adminpanel\ProductcategoryController@update');
	Route::get('delete', 'adminpanel\ProductcategoryController@delete');	
});

Route::group(array('prefix' => '/adminpanel/coupon','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'coupon', 'uses' => 'adminpanel\CouponController@index'));
	Route::get('search', 'adminpanel\CouponController@search');
	Route::get('add-new', 'adminpanel\CouponController@add');
	Route::post('create', 'adminpanel\CouponController@create');
	Route::get('edit/{id}', 'adminpanel\CouponController@edit');
	Route::post('update', 'adminpanel\CouponController@update');
	Route::get('delete', 'adminpanel\CouponController@delete');
	
});

Route::group(array('prefix' => '/adminpanel/menu','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'menu', 'uses' => 'adminpanel\MenuController@index'));
	Route::get('add-new', 'adminpanel\MenuController@add');
	Route::post('create', 'adminpanel\MenuController@create');
	Route::get('edit/{id}', 'adminpanel\MenuController@edit');
	Route::post('update', 'adminpanel\MenuController@update');
	Route::get('delete', 'adminpanel\MenuController@delete');
});	

Route::group(array('prefix' => '/adminpanel/bottommenu','middleware' => 'admin'), function () {
	Route::get('/', array('as' => 'bottommenu', 'uses' => 'adminpanel\MenuController@bottommenu'));
	Route::get('add-new', 'adminpanel\MenuController@addbottommenu');
	Route::get('edit/{id}', 'adminpanel\MenuController@editbottommenu');
	Route::get('delete', 'adminpanel\MenuController@bottomdelete');
	/*Route::post('create', 'adminpanel\MenuController@create');
	Route::get('edit/{id}', 'adminpanel\MenuController@edit');
	Route::post('update', 'adminpanel\MenuController@update');
	Route::get('delete', 'adminpanel\MenuController@delete');*/
});
		
Route::post('/adminpanel/save_attribute', 'adminpanel\ProductattributesController@save_attribute')->middleware('admin')->name('save_attribute');
Route::get('/adminpanel/add-color', 'adminpanel\ProductattributesController@add_color')->middleware('admin')->name('add_color');
Route::get('/adminpanel/edit-color/{id}', 'adminpanel\ProductattributesController@edit_color')->middleware('admin')->name('edit_color');
Route::post('/adminpanel/edit-attribute', 'adminpanel\ProductattributesController@edit_attribute')->middleware('admin')->name('edit_attribute');
Route::post('/adminpanel/update_menu_order','adminpanel\AjaxController@update_menu_order')->name('update_menu_order');

Route::get('/product/{slug}', 'ProductsController@index')->name('product_detail');
Route::post('prod_filt', 'FrontajxController@prod_filt')->name('prod_filt');
Route::post('add-to-cart', 'CartController@add_to_cart')->name('add_to_cart');
Route::get('remove-product/{id}', 'CartController@del_prod_to_cart')->name('delete_to_cart');

Route::get('remove-coupon/{id}', 'CartController@remove_coupon')->name('remove_coupon');

Route::post('apply_coupon', 'CartController@add_coupon_code')->name('apply_coupon');

Route::post('update_profile', 'HomeController@update_profile')->name('update_profile');
Route::post('shipping_billing', 'HomeController@shipping_billing')->name('shipping_billing');
Route::post('shipping_billing_delete', 'HomeController@shipping_billing_delete')->name('shipping_billing_delete');

Route::post('shipping_billing_cart_add', 'HomeController@shipping_billing_cart_add')->name('shipping_billing_cart_add');

Route::post('shipping_billing_cart_update', 'HomeController@shipping_billing_cart_update')->name('shipping_billing_cart_update');

Route::get('edit-address/{id}', 'HomeController@edit_address')->name('edit_address');
Route::get('delete-address/{id}', 'HomeController@delete_address')->name('delete_address');

Route::post('add_paymentmethod', 'CartController@add_paymentmethod')->name('add_paymentmethod');
Route::post('card_detail_save', 'CartController@card_detail_save')->name('card_detail_save');

Route::post('create_order', 'CartController@create_order')->name('create_order');
Route::post('cancel_order', 'CartController@cancel_order')->name('cancel_order');
Route::post('give_feedback', 'CartController@give_feedback')->name('give_feedback');

Route::post('contact_us_submit', 'HomeController@contact_us_submit')->name('contact_us_submit');

Route::get('order-completed/{id}', 'CartController@order_completed')->name('order_completed');

Route::get('/', 'HomeController@index')->name('home');
Route::get('/{slug}', 'HomeController@index')->name('home');




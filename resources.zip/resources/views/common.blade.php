@extends('layouts.app')

@section('content')

<div class="sitewrapper common-page-content">
    @php
    	$name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
    @endphp    
    <div class="pageheading">
      <div class="container-fluid">
          <h1>{{$name}}</h1>
      </div>
    </div>
    <div class="container-fluid common-content">{!! $data['page_content'] !!}</div>
</div>

@endsection

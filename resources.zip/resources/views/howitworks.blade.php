@extends('layouts.app')

@section('content')

<div class="sitewrapper how-it-work-page">
    @php
    	$name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
    @endphp    
    <div class="pageheading">
      <div class="container-fluid">
          <h1>{{$name}}</h1>
      </div>
    </div>
    <div class="howitworks-listing">
    
    @if(isset($data['how_it_content']) && !empty($data['how_it_content']))
    @php
      $i=1;
    @endphp
    @foreach($data['how_it_content'] as $hcont)
     @php
     	$i++;
        $meta_value=$hcont->meta_value;
        $meta_value_arr = explode(':::@@',$meta_value);
        
        $svg_code = (isset($meta_value_arr[0]))?$meta_value_arr[0]:'';
        $field_title = (isset($meta_value_arr[1]))?$meta_value_arr[1]:'';
        $field_detail = (isset($meta_value_arr[2]))?$meta_value_arr[2]:''; 
        $count = $i - 1;
        if($i%2 == 0){       
     @endphp
     <div class="row no-gutters howwork-bx">
        <div class="col-sm-5 col-md-3">
          <div class="workiconarea">
            <div class="howorkicon">{!! $svg_code !!}</div>
          </div>
        </div>
        <div class="col-sm-7 col-md-9">
          <div class="howorkdetail">
              
              <div class="work-title">
                <span class="work-number">0{{$count}}</span>  
                {{$field_title}}
              </div>
              <div class="work-desc">{{$field_detail}}</div>
          </div>
        </div>
     </div>
     @php
     }else{
     @endphp
     <div class="row no-gutters howwork-bx alternethow-work">
        <div class="col-sm-5 col-md-3 order-sm-1">
          <div class="workiconarea">
            <div class="howorkicon">{!! $svg_code !!}</div>
          </div>
        </div>
        <div class="col-sm-7 col-md-9">
          <div class="howorkdetail">
              <div class="work-title">
                <span class="work-number">0{{$count}}</span>
                {{$field_title}}
              </div>
              <div class="work-desc">{{$field_detail}}</div>
          </div>
        </div>
     </div>
      @php
      }
      @endphp 
	@endforeach 
    @endif 

     

  </div>
</div>

@endsection

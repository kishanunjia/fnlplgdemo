<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">    
  <meta name="title" content="{{display_meta_title($data['site_name'],$data['meta_title'],$data['page_name'])}}">
  <meta property="og:title" content="{{display_meta_title($data['site_name'],$data['meta_title'],$data['page_name'])}}" />
  <meta name="csrf-token" content="{{ csrf_token() }}" />   
  @if(!empty($data['meta_desc']))
    <meta name="description" content="{{$data['meta_desc']}}">
    <meta property="og:description" content="{{$data['meta_desc']}}" />
  @endif
  @if(!empty($data['meta_desc']))
    <meta name="keyword" content="{{$data['meta_keyword']}}">
  @endif 
   <meta property="og:site_name" content="{{$data['site_name']}}" />
   <meta name="author" content="{{$data['site_name']}}">    
  <link rel="shortcut icon" href="{{asset('images/').'/'.$data['site_favicon_logo']}}">  
  <title>{{display_meta_title($data['site_name'],$data['meta_title'],$data['page_name'])}}</title>    
  <link href="{{URL::asset('css/jquery-ui.css')}}" rel="stylesheet">  
  <link href="{{URL::asset('css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{URL::asset('css/fontawesome.css')}}" rel="stylesheet">
  <link href="{{URL::asset('css/style.css')}}" rel="stylesheet">
  <link href="{{URL::asset('css/responsive.css')}}" rel="stylesheet">
  <script src="{{URL::asset('js/jquery-3.2.1.min.js')}}"></script> 
</head>
<body>
<!-- header start -->
<header class="header sticky">
  <div class="menu-overlay"></div>
  <div class="cart-overlay"></div>
  <div class="container-fluid">
      <div class="row">
          <div class="col-3 brand-wrap">
              <a href="{{url('/')}}"><img src="{{asset('images/').'/'.$data['site_logo']}}" alt="{{$data['site_name']}}" /></a>
          </div>
          <div class="col-9 hdr-rgt">
              <div class="navigation">
                  @if(!empty($data['menutop']))
                  <div id="cssmenu">
                    <ul>
                      @foreach($data['menutop'] as $menu)
                       @php
                         $m_url = ($menu->pid == 0)?$menu->m_url:url('/').'/'.get_page_url_by_id($menu->pid);
                         $m_target = (!empty($menu->m_target))?'target="_blank"':'';
                         $class=($menu->pid == $data['page_id'])?'class="active"':'';
                       @endphp
                      <li {!! $class !!}><a {{$m_target}} href="{{$m_url}}">{{$menu->m_name}}</a></li>
                      @endforeach
                      @guest
                      <li class="show1024"><a href="{{url('/').'/'.get_page_url_by_id(15)}}">LOG IN / SIGN IN</a></li>
                      @else
                      <li class="show1024"><a href="{{ route('logout') }}"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a></li>                      
                      <li class="show1024"><a href="{{url('/').'/'.get_page_url_by_id(17)}}">MY ACCOUNT</a>
                        <ul>
                            <li><a href="{{url('/').'/'.get_page_url_by_id(20)}}">Order History</a></li>
                            <li><a href="{{url('/').'/'.get_page_url_by_id(17)}}">Edit Profile</a></li>
                            <li><a href="{{url('/').'/'.get_page_url_by_id(3)}}">Help</a></li>
                        </ul>
                      </li>
                      @endguest
                    </ul>
                  </div>
                  @endif
              </div>
              <div class="hdrrgt-crnr">
                  <div class="userarea">
                      <div class="usericon">
                          <svg version="1.1" id="user" fill="#020202" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                             width="32" height="32" viewBox="0 0 58.714 58.163" enable-background="new 0 0 58.714 58.163" xml:space="preserve">
                          <path  d="M29.357,30.816c7.27,0,13.165-6.899,13.165-15.409C42.522,3.606,36.628,0,29.357,0
                            S16.193,3.606,16.193,15.408C16.193,23.917,22.088,30.816,29.357,30.816"/>
                          <path d="M58.428,53.494l-6.642-14.961c-0.305-0.684-0.838-1.252-1.502-1.598l-10.308-5.366
                            c-0.228-0.118-0.503-0.095-0.706,0.06C36.354,33.834,32.926,35,29.357,35c-3.57,0-6.997-1.166-9.912-3.371
                            c-0.204-0.154-0.479-0.178-0.708-0.06L8.432,36.936c-0.666,0.346-1.197,0.913-1.502,1.598L0.288,53.494
                            c-0.459,1.031-0.365,2.213,0.25,3.158c0.616,0.945,1.656,1.511,2.784,1.511h52.07c1.128,0,2.169-0.565,2.783-1.511
                            C58.791,55.707,58.885,54.525,58.428,53.494"/>
                          </svg>
                      </div>
                       @guest
                      <div class="topdropbox dropuserinfo">                                                    
                              <div class="loginbx">
                              <a href="{{url('/').'/'.get_page_url_by_id(15)}}" class="sgnbtn">Sign in</a>
                              <p>Do not have an account? <a href="{{url('/').'/'.get_page_url_by_id(15)}}" class="regbtn">Register</a></p>
                              </div>                                                                                       
                              <ul>
                                  <li><a href="{{url('/').'/'.get_page_url_by_id(17)}}">Edit Profile</a></li>
                                  <li><a href="{{url('/').'/'.get_page_url_by_id(20)}}">Order History</a></li>
                                  <li><a href="{{url('/').'/'.get_page_url_by_id(3)}}">Help</a></li>
                              </ul>                                                                                                                                                   
                      </div>
                      @else
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>                      
                      <div class="topdropbox dropuserinfo afterlogin">
                          <div class="userinfo">
                              Hi {{get_user_name()}}!
                          </div>
                          <ul>
                              <li><a href="{{url('/').'/'.get_page_url_by_id(17)}}">Edit Profile</a></li>
                              <li><a href="{{url('/').'/'.get_page_url_by_id(20)}}">Order History</a></li>
                              <li><a href="{{url('/').'/'.get_page_url_by_id(3)}}">Help</a></li>
                              <li><a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Log out</a></li>
                          </ul>
                      </div>
                      @endguest
                  </div>
                  <div class="top-cart">
                          @php
                          	$cart_prod = get_cart_product();
                            $total_cart = (!empty($cart_prod))?count($cart_prod):0;
                            $get_cart_total = get_cart_total();
                          @endphp                  
                      <div class="cartbag">
                        <svg fill="#020202" version="1.1" id="shpng-cart" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                             width="32px" height="32px" viewBox="0 0 52.738 60.933" enable-background="new 0 0 52.738 60.933" xml:space="preserve">
                          <path  d="M52.729,58.93l-4.632-44.102c-0.096-0.923-0.875-1.625-1.804-1.625h-8.704v-1.984
                            C37.589,5.033,32.556,0,26.37,0c-6.187,0-11.22,5.033-11.22,11.219v1.984H6.445c-0.928,0-1.706,0.702-1.804,1.625L0.01,58.93
                            c-0.053,0.511,0.114,1.021,0.457,1.402c0.345,0.382,0.835,0.601,1.348,0.601h49.11c0.513,0,1.004-0.219,1.348-0.601
                            S52.782,59.44,52.729,58.93 M18.777,11.219c0-4.187,3.406-7.592,7.593-7.592s7.592,3.406,7.592,7.592v1.984H18.777V11.219z
                             M3.829,57.306l4.25-40.475h7.071v3.997c0,1.001,0.812,1.813,1.813,1.813s1.813-0.813,1.813-1.813v-3.997h15.185v3.997
                            c0,1.001,0.813,1.813,1.813,1.813c1.002,0,1.813-0.813,1.813-1.813v-3.997h7.071l4.25,40.475H3.829z"/>
                          </svg>
                        <span class="itemcount">{{$total_cart}}</span>
                      </div>
                      <div class="topdropbox cartdropmenu">
                          <div class="clsoseicon closequk-cart">
                          <img src="{{asset('/images/close.png')}}" alt="Close Icon" /></div>					  

                          <div class="mini-cart-wrap">
                            <h4>Shopping bag ({{$total_cart}})</h4>
                            <div class="quickcartlsitng">
                               @if(!empty($cart_prod))
                                @foreach($cart_prod as $prod) 
                                  @php        	
                                    $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
                                    $name = (isset($prod->pro_name))?$prod->pro_name:''; 
                                    $alldates = getDatesFromRange($prod->start_date,$prod->end_date); 
                                    $totaldays = count($alldates);
                                    $logprice=$prod->pro_price;
                                    if(!empty($prod->pro_sale_price)){
                                        $logprice=$prod->pro_sale_price;
                                    }                                   
                                  @endphp                                 
                                 <div class="quk-crt-bx">
                                    <div class="qukcrt-image">
                                        <a href="{{url('/').'/'.$slug}}"><img src="{{asset('products/').'/'.$prod->pro_cart_image}}" alt="{{$name}}" /></a>
                                    </div>
                                    <div class="quclprd-info">
                                        <h5><a href="{{url('/').'/'.$slug}}"><strong>{{get_brand_name_by_id($prod->pro_brand)}} </strong> - {{$name}}</a></h5>
                                        @if(!empty($prod->pro_sale_price))
                                        	<div class="rentalprice">RENTAL  PRICE: <span class="line-through">RS. {{$prod->pro_price}}</span> <span>RS. {{$prod->pro_sale_price}}</span></div>
                                        @else
                                        	<div class="rentalprice">RENTAL  PRICE: RS. {{$prod->pro_price}}</div>
                                        @endif
                                        <div class="deposite">DEPOSIT: RS. {{$prod->pro_deposit}}</div>
                                    </div>
                                  </div>
                                  @endforeach 
                               @endif 
                               @if(empty($cart_prod))
                               <h5 class="empty-cart-top-msg">Empty Cart!</h5>
                               @endif
                            </div>
                            <div class="qukcart-botom">
                                  <div class="quk-total">TOTAL: RS {{$get_cart_total}}</div>
                                  <div class="quk-shipping">FREE SHIPPING  AND  RETURN</div>
                                  <div class="checkuoutbtn">
                                      <a href="{{url('/').'/'.get_page_url_by_id(7)}}">CART</a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</header>
<!-- header over --> 
@yield('content')
<!-- footer start -->
<footer class="footer">
    <div class="footer-top">
        <div class="container">
            <div class="footer-navigation">
				@if(!empty($data['menubottom']))
                <ul>
                      @foreach($data['menubottom'] as $menu)
                       @php
                         $m_url = ($menu->pid == 0)?$menu->m_url:url('/').'/'.get_page_url_by_id($menu->pid);
                         $m_target = (!empty($menu->m_target))?'target="_blank"':'';
                       @endphp
                      <li><a {{$m_target}} href="{{$m_url}}">{{$menu->m_name}}</a></li>
                      @endforeach                      
                </ul>
                @endif
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container-fluid">
            <div class="row">
              <div class="col-4 footersocial order-1">
                    @if(!empty($data['instagram_link']))
                    <a target="_blank" href="{{$data['instagram_link']}}">
                          <svg fill="#231F20" version="1.1" id="insta" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                               width="55.65px" height="55.593px" viewBox="0 0 55.65 55.593" enable-background="new 0 0 55.65 55.593" xml:space="preserve">
                            <path d="M27.841,0.011c4.085,0,8.17-0.029,12.255,0.006c8.593,0.074,15.465,6.9,15.516,15.472
                              c0.049,8.224,0.055,16.448-0.003,24.673c-0.058,8.43-7.012,15.346-15.46,15.395c-8.224,0.047-16.448,0.052-24.673-0.001
                              c-8.444-0.054-15.368-6.967-15.43-15.422c-0.061-8.226-0.063-16.448,0-24.673c0.065-8.586,6.93-15.369,15.54-15.443
                              C19.67-0.018,23.755,0.011,27.841,0.011 M27.83,5.264c-3.979,0-7.956-0.022-11.934,0.005C9.865,5.311,5.311,9.875,5.292,15.916
                              c-0.023,7.9-0.021,15.803,0,23.705C5.308,45.65,9.844,50.248,15.89,50.289c7.955,0.053,15.911,0.053,23.865,0
                              c6.045-0.037,10.582-4.623,10.606-10.664c0.031-7.9,0.028-15.804,0-23.705C50.34,9.87,45.791,5.311,39.761,5.269
                              C35.784,5.242,31.806,5.264,27.83,5.264"/>
                            <path d="M27.95,13.289c7.912,0.026,14.391,6.566,14.384,14.521c-0.008,7.99-6.617,14.515-14.633,14.439
                              c-7.964-0.072-14.395-6.568-14.382-14.523C13.331,19.731,19.889,13.261,27.95,13.289 M27.869,36.935
                              c5.038-0.023,9.118-4.098,9.145-9.127c0.027-5.049-4.184-9.27-9.228-9.25c-4.969,0.019-9.119,4.178-9.153,9.172
                              C18.597,32.792,22.779,36.96,27.869,36.935"/>
                            <path d="M42.672,16.333c-1.848,0.006-3.265-1.383-3.283-3.215c-0.02-1.898,1.463-3.387,3.338-3.349
                              c1.81,0.038,3.211,1.491,3.205,3.323C45.924,14.926,44.514,16.328,42.672,16.333"/>
                            </svg>

                    </a>
                    @endif
                    @if(!empty($data['facebook_link']))
                    <a target="_blank" href="{{$data['facebook_link']}}">
                        <svg version="1.1" fill="#231F20" id="fb" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                         width="52.12px" height="51.741px" viewBox="0 0 52.12 51.741" enable-background="new 0 0 52.12 51.741" xml:space="preserve">
                      <path d="M52.12,24.386v3.707c-0.065,0.217-0.162,0.432-0.191,0.654c-1.351,10.248-6.849,17.354-16.298,21.421
                        c-2.002,0.861-4.103,1.444-6.319,1.573v-20.17c0.202-0.039,0.314-0.08,0.428-0.08c1.157-0.009,2.314-0.014,3.472-0.015
                        c2.258-0.001,2.281,0.003,2.602-2.232c0.237-1.657,0.403-3.327,0.618-5.14H29.22c0-1.482-0.002-2.829,0.001-4.176
                        c0-0.309-0.006-0.619,0.022-0.927c0.191-2.097,1.067-2.933,3.196-2.987c1.378-0.036,2.757-0.007,4.199-0.007V9.149
                        c-2.231,0-4.39-0.123-6.531,0.023c-4.928,0.337-8.076,3.571-8.335,8.521c-0.11,2.105-0.019,4.223-0.019,6.455h-6.268v7.379h6.144
                        v20.063c-0.465-0.061-0.853-0.068-1.217-0.163c-10.049-2.596-16.646-8.795-19.52-18.823C0.475,31.136,0.292,29.599,0,28.093v-4.403
                        c0.091-0.562,0.181-1.122,0.272-1.683C2.389,9.245,13.002,0.12,25.869,0c11.212-0.104,21.216,6.919,24.769,17.546
                        C51.374,19.745,51.638,22.102,52.12,24.386"/>
                      </svg>
                    </a>
                    @endif
                    @if(!empty($data['linkedin_link']))
                    <a target="_blank" href="{{$data['linkedin_link']}}">
                      <svg version="1.1" fill="#231F20" id="twtr" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                       width="58.564px" height="58.565px" viewBox="0 0 58.564 58.565" enable-background="new 0 0 58.564 58.565" xml:space="preserve">
                    <path  d="M58.564,58.565H0V0h58.564V58.565z M38.754,45.471h6.943c-0.135-5.327-0.146-10.565-0.448-15.787
                      c-0.162-2.787-1.486-5.123-4.37-6.033c-3.083-0.974-6.069-0.865-8.67,1.395c-0.403,0.351-0.806,0.702-1.324,1.156v-2.452h-6.483
                      v21.728h6.802V44.14c-0.002-3.206-0.043-6.415,0.016-9.621c0.021-1.065,0.159-2.169,0.489-3.176
                      c0.538-1.641,2.027-2.378,3.972-2.191c1.583,0.151,2.614,1.13,2.833,2.882c0.167,1.326,0.217,2.676,0.23,4.016
                      C38.775,39.164,38.754,42.276,38.754,45.471 M13.369,45.477h6.654V23.711h-6.654V45.477z M16.708,12.773
                      c-2.181,0.001-3.966,1.788-3.958,3.963c0.006,2.182,1.793,3.996,3.941,4.004c2.14,0.008,3.982-1.843,3.975-3.986
                      C20.658,14.568,18.872,12.773,16.708,12.773"/>
                    </svg>
                    </a>
                    @endif
                </div>
                <div class="col-8 copyright">{{$data['copy_rights']}}</div>                
            </div>
        </div>
    </div>

</footer>
<!-- footer over -->


<script src="{{URL::asset('js/bootstrap.min.js')}}"></script>
<script src="{{URL::asset('js/script.js')}}"></script> 
<script>
	jQuery(document).ready(function(){
		jQuery("#menu-button").bind('touchstart mousedown', function(event){
		   event.preventDefault();
		   if (jQuery("#menu-button").hasClass("menu-opened"))
		   {
        jQuery("#menu-button").removeClass("menu-opened");
		   }
		   else{
		    jQuery("#menu-button").addClass("menu-opened");
		   }
		});
	});
</script> 
<!-- slick slider --> 
<script src="{{URL::asset('js/slick.js')}}"></script> 
<script>
$(document).ready(function() {
    $('.sliderwrap').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 2500,
  });
  $('.shopbrandslider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    fade:true,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 2000,
    pauseOnHover: false,
    pauseOnFocus: false,
    responsive: [
     
      {
        breakpoint: 992,
        settings: {
            dots: false,
        }
      }
      ]
  });
   
});
</script> 
<!-- slick slider over --> 

<!-- search show hide script --> 
<script>
$(".usericon").click(function(e) {
        $(".dropuserinfo").toggleClass("showdropuserinfo");
});
$('body').click(function(evt){    
    if($(evt.target).closest('.dropuserinfo, .usericon').length)
    return;
    $(".dropuserinfo").removeClass("showdropuserinfo");
});
 

$(".cartbag").click(function(e) {
    $(".cartdropmenu").toggleClass("showcartdropmenu");
    $('body').toggleClass("scrldsbl");
    $(".cart-overlay").toggleClass("show-cartoverlay");
});
$('body').click(function(evt){    
    if($(evt.target).closest('.mini-cart-wrap, .cartbag').length)
    return;
    $(".cartdropmenu").removeClass("showcartdropmenu");
     $('body').removeClass("scrldsbl");
     $(".cart-overlay").removeClass("show-cartoverlay");
});
$(".closequk-cart").click(function(e) {
      $(".cartdropmenu").removeClass("showdropuserinfo");
       $('body').removeClass("scrldsbl");
       $(".cart-overlay").removeClass("show-cartoverlay");
});
</script>
<!-- sticky header script --> 
<script src="{{URL::asset('js/sticky-header.js')}}"></script> 
<script>
  $(document).ready(function(){
    $('.sticky').stickMe(); 
  })
</script> 

</body>
</html>
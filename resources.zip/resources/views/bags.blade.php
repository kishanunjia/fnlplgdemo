@extends('layouts.app')

@section('content')

<div class="sitewrapper bagspage pb-0">    
        <div class="pageheading">
            <h1>Bags</h1>
        </div>
        <div class="bagcntwrap mt-20">
        <div class="row no-gutters">
          
          <div class="col-md-4 col-lg-4 col-xl-3 filtersidebar">
              <div class="mobilefilterbtn">filter</div>

              <div class="accordion filtercnt" id="accordionExample">

              <form name="filter_forms" id="filter_forms" method="post" action="">
    		  @csrf
                  
                  <div class="closeicon fltclose">
                      <img src="images/close.png" alt="" />
                  </div>
                  <div class="flthght">
                  @if(!empty($data['color']))
                  <div class="fiterbx color-main">
                      <div class="flt-ttl"><h4 data-toggle="collapse" data-target="#colortab" aria-expanded="true">COLOUR</h4></div>
                      <div class="filterlist collapse show" id="colortab" data-parent="#accordionExample">
                         @foreach($data['color'] as $atr) 
                          <div class="fiteritem">
                              <label class="flt-checkbox">{{$atr->attr_name}}<input name="color[]" onchange="applyfilter('y');" value="{{$atr->attr_id}}" class="color" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
						 @endforeach
                      </div>
                  </div>
				  @endif
                  @if(!empty($data['brand']))
                  <div class="fiterbx brand-main">
                      <div class="flt-ttl"><h4 data-toggle="collapse" data-target="#brandtab" aria-expanded="false">BRAND</h4></div>
                      <div class="filterlist collapse" id="brandtab" data-parent="#accordionExample">
                          @foreach($data['brand'] as $atr)  
                          <div class="fiteritem">
                              <label class="flt-checkbox">{{$atr->attr_name}}<input name="brand[]" onchange="applyfilter('y');" value="{{$atr->attr_id}}" class="brand" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
                          @endforeach 
                      </div>
                  </div>
				  @endif
                  @if(!empty($data['type']))
                   <div class="fiterbx type-main">
                      <div class="flt-ttl"><h4 data-toggle="collapse" data-target="#typetab" aria-expanded="false">TYPE</h4></div>
                      <div class="filterlist collapse" id="typetab" data-parent="#accordionExample">
                          @foreach($data['type'] as $atr)
                          <div class="fiteritem">
                              <label class="flt-checkbox">{{$atr->attr_name}}<input name="type[]" onchange="applyfilter('y');" value="{{$atr->attr_id}}" class="type" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
                          @endforeach 
                      </div>
                  </div>
				  @endif
                  <div class="fiterbx ordering-main">
                      <div class="flt-ttl"><h4 data-toggle="collapse" data-target="#pricetab" aria-expanded="false">SORT BY</h4></div>
                      <div class="filterlist collapse" id="pricetab" data-parent="#accordionExample">
                          <div class="fiteritem">
                              <label class="flt-checkbox">Price low to high<input name="orderby" onchange="applyfilter('y');" class="orderby" value="pricelowhigh" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
                          <div class="fiteritem">
                              <label class="flt-checkbox">Price high to low<input name="orderby" onchange="applyfilter('y');" class="orderby" value="pricehighlow" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
                          <div class="fiteritem">
                              <label class="flt-checkbox">What's new<input name="orderby" onchange="applyfilter('y');" class="orderby" value="newprod" type="checkbox">
                                <span class="checkpin"></span>
                              </label>
                          </div>
                      </div>
                  </div>
                </div>                  
                <div class="applyfiletrbtn">
                   <a class="clear-filter" href="javascript:void(0);">Clear Filter</a>
                </div>

              <input type="hidden" name="rindex" id="rindex" value="0" />
              <input type="hidden" name="limit" id="limit" value="{{$data['limit']}}" />
              <input type="hidden" name="loadmore" id="loadmore" value="1" />
              <input type="hidden" name="loadaction" id="loadaction" value="inactive" />
              </form> 
                              
              </div>

          </div>          
          <div class="col-md-7 col-lg-7 col-xl-8 bags-listingwrap">
              <div class="bagslsiring">
                <div class="row pro-dynamic">                                 
                 @include('bags-list', ['products' => $data['products']])                                    
                </div>
                <div class="loader"></div>
              </div>
          </div>          
          <div class="col-md-1 col-lg-1 col-xl-1 bacttotopempty">
          </div>
        </div>
    </div>
    <div class="bottomquote"><div class="container"><div class="quote-msg">{{get_option('productlist_quote')}}</div></div></div>
</div>
<div class="back-to-top-btn">
  <a href="">
    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
      width="27.713px" height="19.254px" viewBox="0 0 27.713 19.254" enable-background="new 0 0 27.713 19.254" xml:space="preserve">
    <polyline fill="none" stroke="#FFFFFF" stroke-width="1.807" stroke-miterlimit="10" points="0.73,18.723 13.284,1.489 
    27.007,18.661 "/>
    </svg>
</a>
</div>
<script>
function applyfilter(restart=''){		
	jQuery('.color-main').show();
	jQuery('.brand-main').show();
	jQuery('.type-main').show();
	jQuery('.ordering-main').show();				
	var color = false;
	jQuery.each(jQuery(".color:checked"), function(){
		color = true;
	});
	var brand = false;
	jQuery.each(jQuery(".brand:checked"), function(){
		brand = true;
	});
	var type = false;
	jQuery.each(jQuery(".type:checked"), function(){
		type = true;
	});		
	
	var sortbyfil = false;
	jQuery.each(jQuery(".orderby:checked"), function(){
		sortbyfil = true;
	});
	
	if(color || brand || type || sortbyfil){
		jQuery('.applyfiletrbtn').show();	
	}else{
		jQuery('.applyfiletrbtn').hide();
	}
		
	if(sortbyfil){
		jQuery('.color-main').hide();
		jQuery('.brand-main').hide();
		jQuery('.type-main').hide();				
	}	
	if(color){
		jQuery('.brand-main').hide();
		jQuery('.type-main').hide();
		jQuery('.ordering-main').hide();		
	}
	if(brand){
		jQuery('.color-main').hide();
		jQuery('.type-main').hide();
		jQuery('.ordering-main').hide();		
	}
	if(type){
		jQuery('.color-main').hide();
		jQuery('.brand-main').hide();
		jQuery('.ordering-main').hide();		
	}
	if(restart){
		jQuery('#rindex').val(0);
		jQuery('#loadmore').val(1);
		//jQuery("html,body").animate({scrollTop:0},50);		
	}
	var formdata = new FormData(jQuery('#filter_forms')[0]);							
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
	formdata.append('_token',CSRF_TOKEN);
	formdata.append('screen','edit');

	var rindex = jQuery('#rindex').val();
	jQuery.ajaxSetup({
		headers:{
			'X-CSRF-TOKEN': CSRF_TOKEN
		}
	});					
	jQuery.ajax({
		type: "POST",
		url:  "{{route('prod_filt')}}",
		data: formdata,
		processData: false, 
		contentType: false,
		cache: false,
		success: function(res){
		  jQuery('#loadaction').val('inactive');	
		  jQuery('.loader').hide();
		  if(res.status == 'Y'){			  
			  if(rindex == 0){	
				 jQuery('.pro-dynamic').html(res.pdata);	
			  }else{
				 jQuery('.pro-dynamic').append(res.pdata); 
			  }
		  }else{
			  jQuery('#loadmore').val('');
			   if(rindex == 0){
				  jQuery('.pro-dynamic').html('<h3 class="no-prod">No Product Found.</h3>'); 
			   }
			  //no product found
		  }
		  //alert(JSON.stringify(res.pdata));
			
		}
	});			
}
jQuery(document).ready(function(e) {
	jQuery(".orderby").on('change', function() {
	  var box = jQuery(this);
	  if (box.is(":checked")) {
		var group = "input:checkbox[name='" + box.attr("name") + "']";
		jQuery(group).prop("checked", false);
		box.prop("checked", true);
		applyfilter(0);
	  }else{
		box.prop("checked", false);
		applyfilter(0);
	  }
	  //jQuery('#loadmore').val(1);
	}); 
	
	jQuery('.applyfiletrbtn').click(function(){				 		 
		 jQuery(":checkbox").prop("checked", false);
		 applyfilter('y');	
	});
	
	jQuery(window).scroll(function() {
		
		var loadaction = jQuery('#loadaction').val();	
		if((jQuery(window).scrollTop() + jQuery(window).height() > (jQuery(".pro-dynamic").height()+200)) && loadaction == 'inactive'){					 				 
			 jQuery('#loadaction').val('active');	 
			 var loadmore = jQuery('#loadmore').val();
			 if(loadmore){
			 	jQuery('.loader').show();
			 	var rindex = jQuery('#rindex').val();
			 	var limit = jQuery('#limit').val();
			 	jQuery('#rindex').val(parseInt(rindex)+parseInt(limit));
				applyfilter();
			 }
		}
	});	
	   
});
</script>
<script>
jQuery(window).scroll(function() {
    var height = jQuery(window).scrollTop();
    if (height > 60) {
        jQuery('.back-to-top-btn').addClass('show-backtop');
    } else {
        jQuery('.back-to-top-btn').removeClass('show-backtop');
    }
});
jQuery(document).ready(function() {
    jQuery('.back-to-top-btn').click(function(event) {
        event.preventDefault();
        jQuery("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});
</script> 
<script>

jQuery(".mobilefilterbtn").click(function(e) {
    jQuery(".filtercnt").toggleClass("showfiltercnt");
     jQuery('body').toggleClass("fltscrldsbl");
  });
jQuery(".fltclose").click(function(e) {
    jQuery(".filtercnt").removeClass("showfiltercnt");
    jQuery('body').removeClass("fltscrldsbl");
  });
</script>

@endsection

@if(!empty($products))   
    @foreach($products as $prod)
        @php        	
            $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
            $name = (isset($prod->pro_name))?$prod->pro_name:'';                                     
        @endphp                       
        <div class="col-sm-6 col-md-6">
            <div class="bags-bx">
                <div class="bags-img">
                    <a href="{{url('/').'/'.$slug}}"><img src="{{asset('products/').'/'.$prod->pro_main_image}}" alt="{{$prod->pro_name}}" /></a>
                    <a href="{{url('/').'/'.$slug}}" class="bagsrentbtn">Rent Now</a>
                </div>
                <div class="bags-detail">
                    <h5><a href="{{url('/').'/'.$slug}}"><strong>{{get_brand_name_by_id($prod->pro_brand)}}</strong> - {{$prod->pro_name}}</a></h5>
                    @if(!empty($prod->pro_sale_price))
                    <div class="bagrent">RENTAL  PRICE: <span class="line-through">RS. {{$prod->pro_price}}</span>&nbsp;&nbsp;<span>RS. {{$prod->pro_sale_price}}</span></div>
                    @else
                    <div class="bagrent">RENTAL  PRICE: RS. {{$prod->pro_price}}</div>
                    @endif                    
                    <div class="marketvalue">MARKET  VALUE: RS {{$prod->	pro_market_value}}</div>
                </div>
            </div>
        </div>
    @endforeach
@endif                                   
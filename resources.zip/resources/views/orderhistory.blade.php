@extends('layouts.app')
@section('content')
@php
    $name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
@endphp 

<div class="sitewrapper orderhistorypage">
    <div class="container-fluid">
         <div class="pageheading">
            <h1>{{$name}}</h1>
        </div>        
        @if(!empty($data['code']))
             <div class="infotex alert alert-success alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>         
               Your 10% discount  coupon code is "{{$data['code']}}" and it valid before {{indian_date_formate($data['valid'])}}.
             </div>        	
        @endif
        
        @if(!empty($data['last_order']))
			@if(empty($data['last_order']->feedback) && $data['last_order']->or_status != 'Cancel') 
          @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
          @endif                    
            <div class="feedbackbx mt-20 add-rev-from @if(count($errors) > 0) notuuu @else hide-div @endif">
              <form name="give_feedback" id="give_feedback" method="post" action="{{route('give_feedback')}}">
              @csrf              
              <div class="container">
                 <div class="fddbknew p0">               
                  <div class="editprofileadrs">
                   <span onclick="togglefun('add-rev-from','add-rev-btn')" class="adrsdltbtn"><img src="{{asset('/images/close.png')}}" alt="Close Icon"></span> 
                    <div class="fddbknew p0 pl-20 pr-20">
                      {!!$data['page_content']!!}
                      <textarea class="form-control" name="feedback" id="feedback"></textarea>
                      <input type="hidden" name="or_id" value="{{$data['last_order']->or_id}}" />                      
                      <input type="submit" name="submit" class="fbckbtn mt-20" value="Give Feedback" />
                    </div>
                  </div>
				 </div>
             </div>
           	 </form>   
            </div>                 
            <div class="feedbackbx mt-20 add-rev-btn @if(count($errors) > 0) hide-div @else notuuu @endif">
              <div class="container">
                  <div class="fddbk">
                      {!!$data['page_content']!!}

                      <a href="javascript:void(0);" onclick="togglefun('add-rev-btn','add-rev-from','feedback')" class="fbckbtn">Give Feedback</a>
                  </div>
    
              </div>
            </div>
		    @endif
        @endif
    </div>
    @if(empty($data['last_order']))
	<div class="feedbackbx mt-40 mb-30">
        <div class="container-fluid">
            <div class="thanksmsgbx">
                <svg version="1.1" fill="#E78F85" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                   width="173.514px" height="173.514px" viewBox="0 0 173.514 173.514" enable-background="new 0 0 173.514 173.514"
                   xml:space="preserve">
                  <path d="M173.514,86.757c0,47.916-38.844,86.757-86.758,86.757C38.841,173.514,0,134.672,0,86.757
                  C0,38.842,38.841,0,86.756,0C134.67,0,173.514,38.842,173.514,86.757"/>
                  <path fill="#F8EDEC" d="M65.151,64.643c0,4.021-3.259,7.28-7.28,7.28s-7.281-3.259-7.281-7.28c0-4.021,3.26-7.279,7.281-7.279
                  S65.151,60.622,65.151,64.643"/>
                  <path fill="#F8EDEC" d="M119.924,64.643c0,4.021-3.26,7.28-7.28,7.28c-4.02,0-7.279-3.259-7.279-7.28
                  c0-4.021,3.26-7.279,7.279-7.279C116.665,57.363,119.924,60.622,119.924,64.643"/>
                  <path d="M125.121,116.292c-9.988,10.699-23.91,16.783-38.62,16.783c-14.71,0-28.632-6.084-38.62-16.783h-1.966
                  c10.317,11.606,25.023,18.232,40.586,18.232c15.562,0,30.268-6.626,40.584-18.232H125.121z"/>
                  <path fill="none" stroke="#F8EDEC" stroke-width="3" stroke-miterlimit="10" d="M125.121,116.292
                  c-9.988,10.699-23.91,16.783-38.62,16.783c-14.71,0-28.632-6.084-38.62-16.783h-1.966c10.317,11.606,25.023,18.232,40.586,18.232
                  c15.562,0,30.268-6.626,40.584-18.232H125.121z"/>
                </svg>
                <div class="pageheading">
                  <h2>No Order Found.</h2>
                </div>
                <p>No order found... yep, that's it.</p>               
            </div>
        </div>
    </div>    
    @endif
</div>
<div class="order-listing">
    @if(!empty($data['order_list']))
     @foreach($data['order_list'] as $ordlist)
    	<div class="orderlist-bx">
        <div class="order-header">
          <div class="container">
            <div class="row no-gutters">
              <div class="col-8 col-md-8 offset-md-4 ord-top">
                  <div class="ordnum">Order Number: #{{$ordlist->or_id}}</div>
                  <div class="ordtopstat d-none d-md-block">Order Status: {{$ordlist->or_status}}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="order-listingwrap">
          @php
            $order_products = get_order_products($ordlist->or_id);
          @endphp
          @if(!empty($order_products))
          
            @foreach($order_products as $prod)
                @php
                $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
                $name = (isset($prod->pro_name))?$prod->pro_name:''; 
                $alldates = getDatesFromRange($prod->start_date,$prod->end_date); 
                $totaldays = count($alldates);
                $product=get_product_by_id($prod->pro_id); 
                $pro_cart_image = (isset($product->pro_cart_image))?$product->pro_cart_image:'';  
                @endphp          
            <div class="order-dtl">
              <div class="row no-gutters">
                <div class="col-4 col-md-4 ord-img">
                    <div class="ord-imgwrap">
                        @if(!empty($pro_cart_image))
                         	<img src="{{asset('products/').'/'.$pro_cart_image}}" alt="{{$name}}" />
                        @endif 
                    </div>
                </div>
                <div class="col-8 col-md-8 ord-dtl">
                    <div class="ord-dtl-cnt">
                          <h5><strong>{{$prod->pro_brand_name}}</strong> - {{$name}}</h5>
                          <div class="ord-price">
                              <div class="ordrentprice">RENTAL  PRICE: RS. {{$prod->pro_price}}</div>
                              <div class="orddeposite">Deposite Price: RS {{$prod->pro_deposit}}</div>
                          </div>
                      </div>
                      
                        <div class="datewrap">
                            <div class="date-item"><span>Expected Delivery Date:</span> {{indian_date_formate($prod->start_date)}}</div>
                            <div class="date-item"><span>Return Date:</span> {{indian_date_formate($prod->end_date)}}</div>
                        </div>
                      
                </div>
            </div>
            </div>
            @endforeach
          
          @endif
          
        </div>
        <div class="order-total">
            <div class="totalamount">TOTAL: RS  {{$ordlist->or_total_final}}</div>
        </div>
        <div class="order-footer">
            <div class="ordtopstat">Order Status: {{$ordlist->or_status}}</div>
        </div>
        @if($ordlist->or_status == 'Processing')
        <form id="removeorder-form{{$ordlist->or_id}}" action="{{ route('cancel_order') }}" method="POST" style="display: none;">
            @csrf
            <input type="hidden" name="or_id" id="or_id" value="{{$ordlist->or_id}}" />
        </form>        
        <div onclick="event.preventDefault();document.getElementById('removeorder-form{{$ordlist->or_id}}').submit();" class="cancelorder">
          <svg version="1.1" fill="#231F20" id="ordercn" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             width="79px" height="79px" viewBox="258.14 381.445 79 79" enable-background="new 258.14 381.445 79 79" xml:space="preserve">

              <path d="M302.004,420.945l34.232-34.232c1.204-1.205,1.204-3.159,0-4.364c-1.206-1.205-3.16-1.205-4.365,0l-34.231,34.232
                l-34.232-34.232c-1.205-1.205-3.159-1.205-4.364,0c-1.205,1.206-1.205,3.159,0,4.364l34.232,34.232l-34.232,34.232
                c-1.205,1.205-1.205,3.159,0,4.364c0.603,0.603,1.392,0.903,2.182,0.903s1.58-0.301,2.182-0.903l34.232-34.232l34.231,34.232
                c0.603,0.603,1.393,0.903,2.183,0.903s1.579-0.301,2.183-0.903c1.204-1.206,1.204-3.159,0-4.364L302.004,420.945z"/>
          </svg>
        Order Cancel</div>
        @endif
    </div>
     @endforeach
	@endif

    
    
</div>
<script>
function togglefun(thisfrm,thatfrm,focusid=''){
	jQuery('.'+thisfrm).addClass('hide-div');
	jQuery('.'+thatfrm).removeClass('hide-div');	
	if(focusid){
		jQuery('#'+focusid).focus();	
	}
}
</script>
@endsection

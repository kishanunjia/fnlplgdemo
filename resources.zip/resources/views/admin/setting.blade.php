@include('admin.header')

  <!-- Navbar -->  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Setting</a>
      </li>
    </ul>    
  </nav>  
  <!-- /.navbar -->

<div class='content-wrapper'>
  <section class='content'>
  <section class='content-header'>
    <h1> Setting</h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>
    
    <div class='card card-default color-palette-box'>
        
        <div class='settings-tabs'>
                @if($data['tabs'])
               <ul>
                  <?php
                    
                        //if($tab['id'] == $id){$class='active';}else{$class='';}
                  ?> 
                  @foreach ($data['tabs'] as $tab)
                   <li class="tab-title @if($tab['id'] == $data['id']) active @endif">
                     <a href="{{ $tab['url'] }}">{{ $tab['name'] }}</a>
                   </li>
                  @endforeach
               </ul>
              @endif
        </div>
                   
       <form name="general_setting" id="general_setting" method="post" action="{{route('update_general')}}" enctype="multipart/form-data">
       @csrf
        <div class='card-body'>		
            


            
       @php 
       $success = session()->get('success'); 
       @endphp
                         
	   @if(isset($success))
       <div class="alert alert-success delete_msg pull" style="width: 100%"> <i class="fa fa-check-circle"></i> {{session()->get('success')}} &nbsp;
        	<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
       </div>      	     
       @endif



            <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Site Name</label>
                    <input type="text" class="form-control" name="site_name" id="site_name" placeholder="Site Name" value="{{get_option('site_name')}}" />
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Site Phone</label>                    
                    <input type="text" class="form-control" name="site_phone" id="site_phone" placeholder="Site Phone" value="{{get_option('site_phone')}}" />
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Site Email</label>                    
                    <input type="text" class="form-control" name="site_email" id="site_email" placeholder="Site Email" value="{{get_option('site_email')}}" />
                  </div>
                </div>
                
              </div>
            
            <div class="row">
            
                <div class="col-sm-6">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Store Address</label>
                    <textarea class="form-control" id="site_description" name="store_address" rows="5">{{get_option('store_address')}}</textarea>
                  </div>
                </div>  
                
                <div class="col-sm-6">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Copy Right Text</label>
                    <textarea class="form-control" id="copy_rights" name="copy_rights" rows="5">{{get_option('copy_rights')}}</textarea>
                  </div>
                </div>                            
            
            </div>



            
            @php
            $site_logo = get_option('site_logo');
            @endphp
            <div class="row">
            
                <div class="col-sm-6">                  
                  <div class="form-group">
                    <label>Site Logo &nbsp;<small class="dim-msg"><b>(Image Dimensions : 267 * 76)</b></small></label>
                    <div class="controls">
                    	<input type="file" id="site_logo" name="site_logo" class="form-control  file-hidden" value="">
                      	@if(!empty($site_logo))
                        <div class="primage setting-preview-img">
                            <img src="{{URL::asset('images/'.$site_logo)}}" alt="Logo" />
                        </div>
                        @endif                       
                    </div>
                  </div>
                </div>
                
            @php
            $site_favicon_logo = get_option('site_favicon_logo');
            @endphp                
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Favicon Icon &nbsp;<small class="dim-msg"><b>(Image Dimensions : 32 * 32)</b></small></label> 
                    <div class="controls">                   
                       <input type="file" id="site_favicon_logo" name="site_favicon_logo" class="form-control  file-hidden" value="">
                       @if(!empty($site_favicon_logo))
                        <div class="primage setting-preview-img">
                            <img src="{{URL::asset('images/'.$site_favicon_logo)}}" alt="Favicon Icon" />
                        </div>
                       @endif               
                    </div>
                  </div>
                </div>
                
           </div>
           
            <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Instagram Account Link</label>
                    <input type="text" class="form-control" name="instagram_link" id="instagram_link" placeholder="Instagram Link" value="{{get_option('instagram_link')}}" />
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Facebook Account Link</label>                    
                    <input type="text" class="form-control" name="facebook_link" id="facebook_link" placeholder="Facebook Link" value="{{get_option('facebook_link')}}" />
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <div class="form-group">
                    <label>Linkedin Account Link</label>                    
                    <input type="text" class="form-control" name="linkedin_link" id="linkedin_link" placeholder="Linkedin Link" value="{{get_option('linkedin_link')}}" />
                  </div>
                </div>
                
              </div>            
            
            
            <div class="row">
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>First Rental Period</label>                    
                        @php
                        $first_period = get_option('first_period');
                        @endphp					   
                       <select name="first_period" id="first_period" class="form-control">
                          @for($i=1;$i<=20;$i++)
                          <option @if($first_period == $i) selected @endif value="{{$i}}">{{$i}} day</option>
                          @endfor
                       </select>                    
                  </div>
                </div>
                
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Second Rental Period</label>                    
                    @php
                    $second_period = get_option('second_period');
                    @endphp					   
                   <select name="second_period" id="second_period" class="form-control">
                      @for($i=1;$i<=20;$i++)
                      <option @if($second_period == $i) selected @endif value="{{$i}}">{{$i}} day</option>
                      @endfor
                   </select>                     
                  </div>
                </div>
                
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Third Rental Period</label>                    
                    @php
                    $third_period = get_option('third_period');
                    @endphp					   
                   <select name="third_period" id="third_period" class="form-control">
                      @for($i=1;$i<=20;$i++)
                      <option @if($third_period == $i) selected @endif value="{{$i}}">{{$i}} day</option>
                      @endfor
                   </select>                     
                  </div>
                </div>
                
                <div class="col-sm-3">
                  <div class="form-group">
                    <label>Blocking Days</label>                    
                    @php
                    $blocking_days = get_option('blocking_days');
                    @endphp					   
                   <select name="blocking_days" id="blocking_days" class="form-control">
                      @for($i=1;$i<=20;$i++)
                      <option @if($blocking_days == $i) selected @endif value="{{$i}}">{{$i}} day</option>
                      @endfor
                   </select>                     
                  </div>
                </div>                
                
              </div>            
 
             <div class="row">
            
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Product Listing Quote</label>
                    <textarea class="form-control" id="productlist_quote" name="productlist_quote" rows="5">{{get_option('productlist_quote')}}</textarea>
                  </div>
                </div>  
                
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Deposit Notice</label>
                    <textarea class="form-control" id="deposit_notice" name="deposit_notice" rows="5">{{get_option('deposit_notice')}}</textarea>
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Related Product Title</label>
                    <textarea class="form-control" id="related_pro_title" name="related_pro_title" rows="5">{{get_option('related_pro_title')}}</textarea>
                  </div>
                </div>                                            
            
            </div>
            
			 <div class="row">
                    @php
                        $visacard = get_option('visacard');
                        $mastercard = get_option('mastercard');
                        $cash = get_option('cash');
                    @endphp	            
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Visa Payment Method</label>
                    <br />
                    <input type="checkbox" name="visacard" value="1" @if(!empty($visacard)) checked @endif data-bootstrap-switch data-off-color="danger" data-on-color="success">
                  </div>
                </div>  
                
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>MasterCard Payment Method</label>
                    <br />
                    <input type="checkbox" name="mastercard" value="1" @if(!empty($mastercard)) checked @endif data-bootstrap-switch data-off-color="danger" data-on-color="success">                    
                  </div>
                </div>
                
                <div class="col-sm-4">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Cash On Delivery</label>
					<br />
                    <input type="checkbox" name="cash" value="1" @if(!empty($cash)) checked @endif data-bootstrap-switch data-off-color="danger" data-on-color="success">                     
                  </div>
                </div>                                            
            
            </div>                        
            
            
				<div class="row">                  
                  <div class="col-md-12">
                    <div class="form-group"> 
                        <br />
                        <br />                       
                        <div class="controls text-center">
                         <input type="hidden" name="setting_option" value="general" />                         
                         <button type="submit" class="btn btn-primary">Save</button>                            
                        </div>
                    </div>
                  </div>                                                                  
                </div>             
                            
        </div>
      </form>  
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
  
  
@include('admin.footer')  
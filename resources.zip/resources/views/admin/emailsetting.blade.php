@include('admin.header')

  <!-- Navbar -->  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Setting</a>
      </li>
    </ul>    
  </nav>  
  <!-- /.navbar -->

<div class='content-wrapper'>
  <section class='content'>
  <section class='content-header'>
    <h1> Setting</h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>
    
    <div class='card card-default color-palette-box'>
        
        <div class='settings-tabs'>
                @if($data['tabs'])
               <ul>
                  <?php
                    
                        //if($tab['id'] == $id){$class='active';}else{$class='';}
                  ?> 
                  @foreach ($data['tabs'] as $tab)
                   <li class="tab-title @if($tab['id'] == $data['id']) active @endif">
                     <a href="{{ $tab['url'] }}">{{ $tab['name'] }}</a>
                   </li>
                  @endforeach
               </ul>
              @endif
        </div>
                   
       <form name="general_setting" id="general_setting" method="post" action="{{route('update_email')}}" enctype="multipart/form-data">
       @csrf
        <div class='card-body'>		
            


            
       @php 
       $success = session()->get('success'); 
       @endphp
                         
	   @if(isset($success))
       <div class="alert alert-success delete_msg pull" style="width: 100%"> <i class="fa fa-check-circle"></i> {{session()->get('success')}} &nbsp;
        	<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
       </div>      	     
       @endif
			<div class="row">
                <div class="col-sm-6">
                  <!-- text input -->
                  <div class="form-group">
                    <label>From Email </label>
                    <input type="text" class="form-control" id="from_email" name="from_email" value="{{get_option('from_email')}}" />                    
                  </div>
                </div>  
                <div class="col-sm-6">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Admin Notification Email</label>
                    <input type="text" class="form-control" id="admin_notification_email" name="admin_notification_email" value="{{get_option('admin_notification_email')}}" />                    
                  </div>
                </div>            
            </div>
            <div class="row">
            
                <div class="col-sm-12">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Order Customer Email Subject</label>
                    <input type="text" class="form-control" id="order_email_subject" name="order_email_subject" value="{{get_option('order_email_subject')}}" />                    
                  </div>
                </div>  
                <div class="col-sm-12">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Order Admin Email Subject</label>
                    <input type="text" class="form-control" id="order_admin_email_subject" name="order_admin_email_subject" value="{{get_option('order_admin_email_subject')}}" />                    
                  </div>
                </div>                 
                <div class="col-sm-12">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Order Email Body</label>
                    <textarea class="form-control" id="order_email_body" name="order_email_body" rows="15">{{get_option('order_email_body')}}</textarea>
                  </div>
                </div>                            
            	<hr />
                <div class="col-sm-12">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Contact Us Email Subject</label>
                    <input type="text" class="form-control" id="contact_email_subject" name="contact_email_subject" value="{{get_option('contact_email_subject')}}" />                    
                  </div>
                </div>                 
                <div class="col-sm-12">
                  <!-- text input -->
                  <div class="form-group">
                    <label>Contact Us Email Body</label>
                    <textarea class="form-control" id="contact_email_body" name="contact_email_body" rows="15">{{get_option('contact_email_body')}}</textarea>
                  </div>
                </div>              
            
            </div>

            
            <div class="row">                  
              <div class="col-md-12">
                <div class="form-group"> 
                    <br />
                    <br />                       
                    <div class="controls text-center">
                     <input type="hidden" name="setting_option" value="general" />                         
                     <button type="submit" class="btn btn-primary">Save</button>                            
                    </div>
                </div>
              </div>                                                                  
            </div>             
                            
        </div>
      </form>  
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
  
  
@include('admin.footer')  
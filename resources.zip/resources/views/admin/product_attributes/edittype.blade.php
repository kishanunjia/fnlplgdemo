@include('admin.header')

    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Edit {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>

  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Edit {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_attribute" method="post" action="{{route('manage_type')}}/update" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
     	
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>{{$data['attrname']}} Name</label>
                <input type="text" class="form-control" name="attr_name" id="attr_name" placeholder="{{$data['attrname']}} Name" value="{{$data['atdata']->attr_name}}" />
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>
                
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="attr_status" value="1" @if($data['atdata']->attr_status == 1) checked @endif>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="attr_status" value="0" @if($data['atdata']->attr_status == 0) checked @endif>
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>                                				  				                                                    
              </div>
            </div>                                
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center">
                 <input type="hidden" name="attr_type" value="{{$data['dbname']}}" />
                 <input type="hidden" name="attr_id" value="{{$data['atdata']->attr_id}}" /> 
                                         
                 <button type="submit" class="btn btn-primary">Save</button>  &nbsp;&nbsp
                 <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>
                                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
<script>
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){
	 
	 var attr_name = jQuery('#attr_name');
		 
	 
	 attr_name.blur(function(){
		required_validate(attr_name);		
	 });	    

	 jQuery('#save_attribute').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;
		
		if(!required_validate(attr_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = attr_name;
		  }
		}		
																
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
  
@include('admin.footer')  
@include('admin.header')


<div class='content-wrapper'>
  <section class='content'>
  <section class='content-header'>
    <h1>Product Attributes</h1>
  </section>
   <div class="container-fluid">
    
    <div class='row'>
        
        <div class='col-sm-6'>
        
          <div class='card card-default color-palette-box'>
            
    
           <div class="card-header d-flex p-0">
            <h3 class="card-title p-3">          
              Color 
            </h3>
            <div class="ml-auto p-2"><a class="btn btn-primary" href="{{route('manage_color')}}">Manage</a></div>
          </div>                  
          <div class='card-body scroll'>		
            
               @if($data['color'])
               
                    @foreach ($data['color'] as $adata)
                        
                     <p class="lead">{{$adata->attr_name}}</p>
                        
                    @endforeach               
                    
               @endif 
            
          </div>
     
        </div>
         
        </div> 
    
    </div>
    
   </div>
  </section>
</div>  
  
  
@include('admin.footer')  
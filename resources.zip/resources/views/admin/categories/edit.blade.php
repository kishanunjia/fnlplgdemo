@include('admin.header')

    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Edit {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>
  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Edit {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_attribute" method="post" action="{{route('categories')}}/update" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		     	
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>{{$data['attrname']}} Name</label>
                <input type="text" class="form-control" name="cname" id="cname" placeholder="{{$data['attrname']}} Name" value="{{$data['cdata']->cname}}" />
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label>Parent Category</label>
                   <select name="pcid" id="pcid" class="form-control">
                      <option value="0">-Select Parent Category-</option>
                      @if(!empty($data['categories'])){
                        @foreach($data['categories'] as $cats)
                      	   	@if($data['cdata']->cid != $cats->cid)
                        		<option @if($data['cdata']->pcid == $cats->cid) selected @endif value="{{$cats->cid}}">{{$cats->cname}}</option>
                        	@endif
                        @endforeach
                      @endif
                   </select>                 
                
              </div>
            </div>             
            
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>
                
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="cstatus" value="1" @if($data['cdata']->cstatus == 1) checked @endif>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="cstatus" value="0" @if($data['cdata']->cstatus == 0) checked @endif>
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>                                				  				                                                    
              </div>
            </div>                                
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group">                        
                <div class="controls text-center">                 
                 <input type="hidden" name="cid" value="{{$data['cdata']->cid}}" />                                          
                 <button type="submit" class="btn btn-primary">Save</button>  &nbsp;&nbsp
                 <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>                                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
<script>
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){
	 
	 var cname = jQuery('#cname');
		 
	 
	 cname.blur(function(){
		required_validate(cname);		
	 });	    

	 jQuery('#save_attribute').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;
		
		if(!required_validate(cname)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = cname;
		  }
		}		
																
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
  
@include('admin.footer')  
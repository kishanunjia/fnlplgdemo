@include('admin.header')


    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-wcidget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:vocid(0);" class="nav-link">Product Category</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>
  
  <!-- Main content -->
  <section class='content'>
	<section class='content-header'>
    <h1>Product Category</h1>
  </section>  
   <div class="container-flucid">
    
    <div class='col-xs-12'>
    
    <div class='card card-default color-palette-box'>
        

                         

    <div class="card-header">
    <h3 class="card-title"><a class="btn btn-primary" href="{{route('categories')}}/add-new">Add New</a> </h3>
    
    <div class="card-tools">        
        <form method="get"  autocomplete="off"  enctype="multipart/form-data" action="{{route('categories')}}/search">
            @csrf      
            <div class="input-group input-group-sm" style="wcidth: 150px;">
            <input type="search" value="{{$data['search']}}" name="search" class="form-control float-right" placeholder="Search">
            
            <div class="input-group-append">
            <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
            </div>
            </div>
        </form>
      
    </div>
    </div>

      <div class='card-body'>
		
       
              		
       @php 
       $success = session()->get('success'); 
       @endphp
                         
	   @if(isset($success))
       <div class="alert alert-success delete_msg pull" style="wcidth: 100%"> <i class="fa fa-check-circle"></i> {{session()->get('success')}} &nbsp;
        	<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hcidden="true">×</span> </button>
       </div>      	     
       @endif                                    
            @php
                $baseurll=URL::to('/');
            @endphp        
         @if($data['categories'])     
        <table class="table table-bordered sortabletb">
          <thead>                  
            <tr>                            
              <th>Name</th>
              <th>Slug</th>
              <th>Parent</th>              
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>            
           
            
              @foreach ($data['categories'] as $adata)
              
                <tr atcid="{{$adata->cid}}">                                    
                  <td>{{$adata->cname}}</td>
                  <td>{{$adata->slug}}</td>
                  <td>{{get_cat_name_by_id($adata->pcid)}}</td>                                   
                  <td>
                    <span class="{{$adata->cstatus?'badge bg-success':'badge bg-danger'}}">{{$adata->cstatus?'Active':'Deactive'}}</span>
                  </td>
                  <td>
                    <a class="btn btn-primary" href="{{route('categories')}}/edit/{{$adata->cid}}">Edit</a>&nbsp;&nbsp;
                    <a class="btn btn-danger" onclick="delete_fun({{$adata->cid}});" href="javascript:vocid(0);">Delete</a>
                  </td>
                </tr>
                
              @endforeach
              
            
            
            
          </tbody>
        </table>        
		  @endif




        
      </div>
      
	  <div class="card-footer clearfix">
      @if($data['categories']->total())
        <div class="showinlineblock float-left">{{$data['categories']->firstItem()}}-{{$data['categories']->lastItem()}} of {{$data['categories']->total()}}</div>
        
        <div class="d-flex p-0 float-right">
         <div class="row-per-page form-group">
         <small>Per Page:</small>
         @if (Request::is('adminpanel/categories'))            
            <select onchange="javascript:window.location.href='{{route('categories')}}?postperpage='+this.value" class="custom-select">              
              <option @if($data['postperpage'] == 5) selected @endif  value="5">5</option>
              <option @if($data['postperpage'] == 10) selected @endif  value="10">10</option>
              <option @if($data['postperpage'] == 20) selected @endif value="20">20</option>
              <option @if($data['postperpage'] == 50) selected @endif value="50">50</option>
              <option @if($data['postperpage'] == 100) selected @endif  value="100">100</option>                  
            </select>
         @else
            <select onchange="javascript:window.location.href='{{route('categories')}}/search?search={{ Request::get('search') }}?postperpage='+this.value" class="custom-select">              
              <option @if($data['postperpage'] == 5) selected @endif  value="5">5</option>
              <option @if($data['postperpage'] == 10) selected @endif  value="10">10</option>
              <option @if($data['postperpage'] == 20) selected @endif value="20">20</option>
              <option @if($data['postperpage'] == 50) selected @endif value="50">50</option> 
              <option @if($data['postperpage'] == 100) selected @endif  value="100">100</option>                 
            </select>         
         @endif   
         </div>        
        
        <ul class="pagination pagination-sm m-0">        
          <li class="page-item"><a class="page-link" href="{{$data['categories']->previousPageUrl()}}">«</a></li>          
          <li class="page-item"><a class="page-link" href="{{$data['categories']->nextPageUrl()}}">»</a></li>
        </ul>
        </div>
       </div>      
 	 @endif
    </div>
     
    </div> 
    
   </div>
  </section>
</div>
<script>
jQuery(document).ready(function(){	
	jQuery(".sortabletb tbody").sortable({		
		update: function( event, ui ) {
			updateOrder();
		}
	});  
}); 
function updateOrder(){
	var item_order = new Array();
	jQuery('.sortabletb tbody tr').each(function() {
		item_order.push(jQuery(this).attr("atcid"));		
	});		
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
	var data = {
		_token : CSRF_TOKEN,
		orderdata : item_order,
		table : 'product_category',
		id : 'cid',
		order : 'corder',
	};	
	jQuery.ajax({
		type: "POST",
		url:  "{{route('update_menu_order')}}",
		data : data,
		dataType: 'JSON',
		cache: false,
		success: function(data){ }
	});		
}
function delete_fun(cid){	
	if(confirm("Are you sure you want to delete this item?")){
		window.location.href="{{route('categories')}}/delete?cid="+cid;
	}
}
</script>  
  
@include('admin.footer')  
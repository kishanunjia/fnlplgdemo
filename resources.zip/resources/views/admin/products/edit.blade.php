@include('admin.header')

    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Edit {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>

  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Edit {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_forms" method="post" action="{{route('products')}}/update" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
  
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>{{$data['attrname']}} Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_name" id="pro_name" placeholder="{{$data['attrname']}} Name" value="{{$data['pdata']->pro_name}}" />
              	<small class="dim-msg"><b>Slug : </b>{{$data['pdata']->pro_slug}}</small>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>{{$data['attrname']}} Detail Page Name <span class="text-danger">(If empty than display main title.)</span></label>
                <input type="text" class="form-control" name="pro_display_name" id="pro_display_name" placeholder="{{$data['attrname']}} Detail Page Name" value="{{$data['pdata']->pro_display_name}}" />
              </div>
            </div>            
        </div>
     	
        <div class="row">
        
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Product Main Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 640 * 778)</b></small></label>
                <div class="controls">
                   	   <input type="file" id="pro_main_image" name="pro_main_image" class="form-control  file-hidden" value="">  
                       @if(!empty($data['pdata']->pro_main_image))
                        <div class="primage setting-preview-img setting-preview-prod-img">
                            <img src="{{URL::asset('products/'.$data['pdata']->pro_main_image)}}" alt="Product Main Image" />
                        </div>
                       @endif  
                       <input type="hidden" name="pro_main_image_old" id="pro_main_image_old" value="{{$data['pdata']->pro_main_image}}" />                                                          
                </div>
              </div>                                          
            </div>
            
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Product Cart Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 450 * 548)</b></small></label>
                <div class="controls">
                   	   <input type="file" id="pro_cart_image" name="pro_cart_image" class="form-control  file-hidden" value="">  
                       @if(!empty($data['pdata']->pro_cart_image))
                        <div class="primage setting-preview-img setting-preview-prod-img">
                            <img src="{{URL::asset('products/'.$data['pdata']->pro_cart_image)}}" alt="Product Cart Image" />
                        </div>
                       @endif  
                       <input type="hidden" name="pro_cart_image_old" id="pro_cart_image_old" value="{{$data['pdata']->pro_cart_image}}" />                                                          
                </div>
              </div>                                          
            </div>
            
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Related Product Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 600 * 729)</b></small></label>
                <div class="controls">
                   	   <input type="file" id="pro_relpro_img" name="pro_relpro_img" class="form-control  file-hidden" value="">  
                       @if(!empty($data['pdata']->pro_relpro_img))
                        <div class="primage setting-preview-img setting-preview-prod-img">
                            <img src="{{URL::asset('products/'.$data['pdata']->pro_relpro_img)}}" alt="Product Cart Image" />
                        </div>
                       @endif  
                       <input type="hidden" name="pro_relpro_img_old" id="pro_relpro_img_old" value="{{$data['pdata']->pro_relpro_img}}" />                                                          
                </div>
              </div>                                          
            </div>            
            
        </div>
        
        <div class="row">
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Price <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_price" id="pro_price" placeholder="Product Price" value="{{$data['pdata']->pro_price}}" />
              </div>
            </div>
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Sale Price</label>
                <input type="text" class="form-control" name="pro_sale_price" id="pro_sale_price" placeholder="Product Sale Price" value="{{$data['pdata']->pro_sale_price}}" />
              </div>
            </div>            
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Deposit <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_deposit" id="pro_deposit" placeholder="Deposit" value="{{$data['pdata']->pro_deposit}}" />
              </div>
            </div>
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Market Value <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_market_value" id="pro_market_value" placeholder="Product Market Value" value="{{$data['pdata']->pro_market_value}}" />
              </div>
            </div>                                    
        </div>    
        
        <div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Color <span class="text-danger">*</span></label>                    				   
                   <select name="pro_color" id="pro_color" class="form-control select2">
                      <option  value="0">Select Color</option>
                      @foreach($data['color'] as $colval)                      
                      <option  @if($data['pdata']->pro_color == $colval->attr_id) selected @endif value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                    
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Brand <span class="text-danger">*</span></label>                    				   
                   <select name="pro_brand" id="pro_brand" class="form-control select2">
                      <option  value="0">Select Brand</option>
                      @foreach($data['brand'] as $colval)                      
                      <option @if($data['pdata']->pro_brand == $colval->attr_id) selected @endif value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                     
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Type <span class="text-danger">*</span></label>                    				   
                   <select name="pro_type" id="pro_type" class="form-control select2">
                      <option  value="0">Select Type</option>
                      @foreach($data['type'] as $colval)                      
                      <option @if($data['pdata']->pro_type == $colval->attr_id) selected @endif value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                    
              </div>
            </div>
        
      </div>
      
        <div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" id="pro_description" name="pro_description" placeholder="Description" rows="5">{{$data['pdata']->pro_description}}</textarea>
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                <label>Size</label>
                <textarea class="form-control" id="pro_size" name="pro_size" placeholder="Size" rows="5">{{$data['pdata']->pro_size}}</textarea>
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                <label>Material</label>
                <textarea class="form-control" id="pro_material" name="pro_material" placeholder="Material" rows="5">{{$data['pdata']->pro_material}}</textarea>
              </div>
            </div>                                    
        </div>        

        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Styling Tips</label>
                <textarea class="form-control editor" id="pro_styling_tips" name="pro_styling_tips" placeholder="Styling Tips" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" rows="5">{{$data['pdata']->pro_styling_tips}}</textarea>                                
              </div>
            </div>
        </div>                     

        <div class="row">
            <div class="col-sm-12">
			  <label>Product Detail Images <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 840 * 724)</b></small></label>
              <div class="form-group row">
                
                 <div class="col-sm-8">
                <div class="controls">
                    <input type="file" id="pro_detail_images" name="pro_detail_images[]" multiple class="form-control  file-hidden" value="">                                         
                    <input type="hidden" value="{{$data['pdata']->pro_detail_images}}" id="pro_detail_images_data" class="form-control  file-hidden" name="pro_detail_images_data" />
                    <input type="hidden" value="{{$data['pdata']->pro_detail_images}}" id="pro_detail_images_data_old" class="form-control  file-hidden" name="pro_detail_images_data_old" />
                </div>
                </div>
                <div class="col-sm-4">
                  <a href="javascript:void(0);" class="btn btn-primary" id="upload_pro_detail">Upload Image</a>
                </div>                
              </div>                                          
            </div>
            @php
            	$pro_detail_images = $data['pdata']->pro_detail_images;
            	$pro_detail_images_arr = array(); 
                if(!empty($pro_detail_images)){
                	$pro_detail_images_arr=explode(",",$pro_detail_images);
                }
                $baseurll=URL::to('/');
            @endphp			
            <div class="col-sm-12 image-display-area">
            	<div class="d-flex dym-res">
                	@if(!empty($pro_detail_images_arr))
                    	@foreach($pro_detail_images_arr as $prodetimg)                        	
                            <div class="sortimg" title="{{$prodetimg}}">
                            	<a class="imdel"><i class="nav-icon fa fa-trash"></i></a>
                                <img class="dgimg" title="{{$prodetimg}}" alt="{{$prodetimg}}" src="<?=$baseurll;?>/products/{{$prodetimg}}">
                            </div>                            
                        @endforeach
                    @endif
                </div>                
            </div>            
        </div>

		@if(!empty($data['productcats']))
        
        <div class="row">
            <div class="col-sm-12">              
              <div class="form-group">                
                <label>Product Category</label>
                @foreach($data['productcats'] as $cats)
                <div class="form-check mr-10">
                  <input id="chl-{{$cats->cid}}" @if(in_array($cats->cid,$data['selcats'])) checked @endif  name="category[]" class="form-check-input" value="{{$cats->cid}}" type="checkbox">
                  <label for="chl-{{$cats->cid}}" class="form-check-label">{{$cats->cname}}</label>
                </div>                
                @endforeach
              </div>              
            </div>
        </div>
        
        @endif
        
		<div class="row">    
                         
            <div class="col-sm-6">
                <div class="form-group">
                  <label>Block Start Date </label>
                    <div class="input-group date" id="dis_start" data-target-input="nearest">                    
                        <input type="text" name="block_start_date" value="@if(!empty($data['pdata']->block_start_date)){{db_to_date($data['pdata']->block_start_date)}}@endif" id="block_start_date" class="form-control datetimepicker-input" data-target="#dis_start"/>
                        <div class="input-group-append" data-target="#dis_start" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            <a class="btn btn-danger" onclick="funclear('block_start_date');" href="javascript:void(0);">Clear</a>
                        </div>
                    </div>
                </div>
            </div>            
            <div class="col-sm-6">
                <div class="form-group">
                  <label>Block End Date </label>
                    <div class="input-group date" id="dis_end" data-target-input="nearest">
                        <input type="text" name="block_end_date"  value="@if(!empty($data['pdata']->block_end_date)) {{db_to_date($data['pdata']->block_end_date)}} @endif" id="block_end_date" class="form-control datetimepicker-input" data-target="#dis_end"/>
                        <div class="input-group-append" data-target="#dis_end" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            <a class="btn btn-danger" onclick="funclear('block_end_date');" href="javascript:void(0);">Clear</a>
                        </div>
                    </div>
                </div>
            </div>            
                                                                                    
        </div>        
        
        <div class="row">            
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>
                
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="pro_status" value="1" @if($data['pdata']->pro_status == 1) checked @endif>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="pro_status" value="0" @if($data['pdata']->pro_status == 0) checked @endif>
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>                                				  				                                                    
              </div>
            </div>                                
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center">                
                 <input type="hidden" id="edt_pro_id" name="pro_id" value="{{$data['pdata']->pro_id}}" />                                          
                 <button type="submit" class="btn btn-primary">Save</button>  &nbsp;&nbsp
                 <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>
                                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
<script>
function manage_image(imgarr){	
	if(imgarr){		
		var htmldata='';
        jQuery.each(imgarr, function(index, value){			
			htmldata+='<div class="sortimg" title="'+value+'"><a class="imdel"><i class="nav-icon fa fa-trash"></i></a><img class="dgimg" title="'+value+'" alt="'+value+'" src="<?=$baseurll;?>/products/'+value+'"></div>';
        });	
		jQuery('.dym-res').html(htmldata);			
		jQuery(".dym-res").sortable({		
			update: function( event, ui ) {
				update_order_img();
			}
		});		
		jQuery('.imdel').click(function(){
			jQuery(this).parent().remove();
			update_order_img();
		}); 				
	}	
}

function update_order_img(){
	var imgstring  = new Array();
	var dymhtml=jQuery('.dym-res').html();
	if(dymhtml != ''){
		jQuery('.dym-res .sortimg').each(function() {
			imgstring.push(jQuery(this).attr("title"));		
		});				
		jQuery('#pro_detail_images_data').val(imgstring.join(','));
	}else{
		jQuery('#pro_detail_images_data').val('');
	}
	jQuery('#pro_detail_images').val('');
}

function funclear(id){
	jQuery('#'+id).val('');
}

jQuery(document).ready(function(){
		
	jQuery(".dym-res").sortable({		
		update: function( event, ui ) {
			update_order_img();
		}
	});		
	jQuery('.imdel').click(function(){
		jQuery(this).parent().remove();
		update_order_img();		
	});
						
	jQuery('#upload_pro_detail').click(function(){		
		var pro_detail_images = jQuery("#pro_detail_images");
		if(parseInt(pro_detail_images.get(0).files.length) != 0){
		  	pro_detail_images.removeClass('error_in_field');						
			var formdata = new FormData(jQuery('#save_forms')[0]);						
			var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
			formdata.append('_token',CSRF_TOKEN);
			formdata.append('screen','edit');			
			var data = jQuery('#save_forms').serialize();        
			jQuery.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('products')}}/productdetailimages",
 				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){										
					if(res.status == 1){
						jQuery('#pro_detail_images_data').val(res.data);
						manage_image(res.adata);
						jQuery('#pro_detail_images').val('');
					}
				}
			});			
		}else{
		  alert('Please Select Image');
		  pro_detail_images.addClass('error_in_field');
		}				
	});
});

function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){

	jQuery('.only-number').keypress(function(event){
	   if(event.which != 8 && isNaN(String.fromCharCode(event.which))){
		   event.preventDefault(); 
	   }
	});
	 

	 	 
	 var pro_name = jQuery('#pro_name');
	 var pro_price = jQuery('#pro_price');
	 var pro_market_value = jQuery('#pro_market_value');
	 var pro_deposit = jQuery('#pro_deposit');	 		 	 	 
	 var pro_color = jQuery('#pro_color');
	 var pro_brand = jQuery('#pro_brand');
	 var pro_type = jQuery('#pro_type');


	 pro_color.blur(function(){
		required_validate(pro_color);		
	 });
	 pro_brand.blur(function(){
		required_validate(pro_brand);		
	 });
	 pro_type.blur(function(){
		required_validate(pro_type);		
	 });	 	 
	 
	 pro_name.blur(function(){
		required_validate(pro_name);		
	 });
	 
	 pro_price.blur(function(){
		required_validate(pro_price);		
	 });
	 
	 pro_market_value.blur(function(){
		required_validate(pro_market_value);		
	 });
	 
	 pro_deposit.blur(function(){
		required_validate(pro_deposit);		
	 });
	 	 	 	 	 	 	    
	 jQuery('#save_forms').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;

				
		
		if(!required_validate(pro_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_name;
		  }
		}
						
		if(!required_validate(pro_price)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_price;
		  }
		}
		
		if(!required_validate(pro_market_value)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_market_value;
		  }
		}
		
		if(!required_validate(pro_deposit)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_deposit;
		  }
		}		

		if(!required_validate(pro_color)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_color;
		  }
		}
		
		if(!required_validate(pro_brand)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_brand;
		  }
		}
		
		if(!required_validate(pro_type)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_type;
		  }
		}
																						
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
@include('admin.footer')  
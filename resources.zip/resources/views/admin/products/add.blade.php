@include('admin.header')

  <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Add {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>

  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Add {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_forms" id="save_forms" method="post" action="{{route('products')}}/create" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
     	
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>{{$data['attrname']}} Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_name" id="pro_name" placeholder="{{$data['attrname']}} Name" value="" />
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>{{$data['attrname']}} Detail Page Name <span class="text-danger">(If empty than display main title.)</span></label>
                <input type="text" class="form-control" name="pro_display_name" id="pro_display_name" placeholder="{{$data['attrname']}} Detail Page Name" value="" />
              </div>
            </div>            
        </div>

        <div class="row">
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Product Main Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 640 * 778)</b></small></label>
                <div class="controls">
                    <input type="file" id="pro_main_image" name="pro_main_image" class="form-control  file-hidden" value="">                                         
                </div>
              </div>                                          
            </div>
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Product Cart Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 450 * 548)</b></small></label>
                <div class="controls">
                    <input type="file" id="pro_cart_image" name="pro_cart_image" class="form-control  file-hidden" value="">                                         
                </div>
              </div>                                          
            </div>
            
            <div class="col-sm-4">
			  <div class="form-group">
                <label>Related Product Image <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 600 * 729)</b></small></label>
                <div class="controls">
                   	   <input type="file" id="pro_relpro_img" name="pro_relpro_img" class="form-control  file-hidden" value="">                                                  
                </div>
              </div>                                          
            </div>             
            
        </div>
                
        <div class="row">
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Price <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_price" id="pro_price" placeholder="Product Price" value="" />
              </div>
            </div>
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Sale Price </label>
                <input type="text" class="form-control" name="pro_sale_price" id="pro_sale_price" placeholder="Product Sale Price" value="" />
              </div>
            </div>            
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Deposit <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_deposit" id="pro_deposit" placeholder="Deposit" value="" />
              </div>
            </div>
            
            <div class="col-sm-3">
              <div class="form-group">
                <label>Product Market Value <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="pro_market_value" id="pro_market_value" placeholder="Product Market Value" value="" />
              </div>
            </div>                                    
        </div>        
        
		<div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Color <span class="text-danger">*</span></label>                    				   
                   <select name="pro_color" id="pro_color" class="form-control select2">
                      <option  value="0">Select Color</option>
                      @foreach($data['color'] as $colval)                      
                      <option  value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                    
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Brand <span class="text-danger">*</span></label>                    				   
                   <select name="pro_brand" id="pro_brand" class="form-control select2">
                      <option  value="0">Select Brand</option>
                      @foreach($data['brand'] as $colval)                      
                      <option  value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                     
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Type <span class="text-danger">*</span></label>                    				   
                   <select name="pro_type" id="pro_type" class="form-control select2">
                      <option  value="0">Select Type</option>
                      @foreach($data['type'] as $colval)                      
                      <option  value="{{$colval->attr_id}}">{{$colval->attr_name}}</option>
                      @endforeach
                   </select>                    
              </div>
            </div>
        
      </div>        
        
        <div class="row">
            <div class="col-sm-4">
              <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" id="pro_description" name="pro_description" placeholder="Description" rows="5"></textarea>
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                <label>Size</label>
                <textarea class="form-control" id="pro_size" name="pro_size" placeholder="Size" rows="5"></textarea>
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                <label>Material</label>
                <textarea class="form-control" id="pro_material" name="pro_material" placeholder="Material" rows="5"></textarea>
              </div>
            </div>                                    
        </div>        

        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Styling Tips</label>
                <textarea class="form-control editor" id="pro_styling_tips" name="pro_styling_tips" placeholder="Styling Tips" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" rows="5"></textarea>                                
              </div>
            </div>
        </div>        



        <div class="row">
            <div class="col-sm-12">
			  <label>Product Detail Images <span class="text-danger">*</span> &nbsp;<small class="dim-msg"><b>(Image Dimensions : 840 * 724)</b></small></label>
              <div class="form-group row">
                
                 <div class="col-sm-8">
                <div class="controls">
                    <input type="file" id="pro_detail_images" name="pro_detail_images[]" multiple class="form-control  file-hidden" value="">                                         
                    <input type="hidden" id="pro_detail_images_data" class="form-control  file-hidden" name="pro_detail_images_data" />
                    <small class="dim-msg"><b>Select multiple image & click on "Upload Image" button.</b></small>
                </div>
                </div>
                <div class="col-sm-4">
                  <a href="javascript:void(0);" class="btn btn-primary" id="upload_pro_detail">Upload Image</a>
                </div>                
              </div>                                          
            </div>			
            <div class="col-sm-12 image-display-area">
            	<div class="d-flex dym-res">
                
                </div>
                
            </div>            
        </div>

		@if(!empty($data['productcats']))
        
        <div class="row">
            <div class="col-sm-12">              
              <div class="form-group">                
                <label>Product Category</label>
                @foreach($data['productcats'] as $cats)
                <div class="form-check mr-10">
                  <input id="chl-{{$cats->cid}}" name="category[]" class="form-check-input" value="{{$cats->cid}}" type="checkbox">
                  <label for="chl-{{$cats->cid}}" class="form-check-label">{{$cats->cname}}</label>
                </div>                
                @endforeach
              </div>              
            </div>
        </div>
        
        @endif
        
        <div class="row">    
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>
				  
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="pro_status" value="1" checked="checked">
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="pro_status" value="0">
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>
                
                                                                    
              </div>
            </div>                        
        
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center">                                         
                 <button type="submit" class="btn btn-primary">Save</button> &nbsp;&nbsp;                 
                  <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
@php 
$baseurll=URL::to('/');
@endphp
<script>

function manage_image(imgarr){	
	if(imgarr){		
		var htmldata='';
        jQuery.each(imgarr, function(index, value){			
			htmldata+='<div class="sortimg" title="'+value+'"><a class="imdel"><i class="nav-icon fa fa-trash"></i></a><img class="dgimg" title="'+value+'" alt="'+value+'" src="<?=$baseurll;?>/tempimg/'+value+'"></div>';
        });	
		jQuery('.dym-res').html(htmldata);			
		jQuery(".dym-res").sortable({		
			update: function( event, ui ) {
				update_order_img();
			}
		});		
		jQuery('.imdel').click(function(){
			jQuery(this).parent().remove();
			update_order_img();
		}); 				
	}	
}
function update_order_img(){
	var imgstring  = new Array();
	var dymhtml=jQuery('.dym-res').html();
	if(dymhtml != ''){
		jQuery('.dym-res .sortimg').each(function() {
			imgstring.push(jQuery(this).attr("title"));		
		});				
		jQuery('#pro_detail_images_data').val(imgstring.join(','));
	}else{
		jQuery('#pro_detail_images_data').val('');
	}
	jQuery('#pro_detail_images').val('');
}
jQuery(document).ready(function(){		
	jQuery('#upload_pro_detail').click(function(){		
		var pro_detail_images = jQuery("#pro_detail_images");
		if(parseInt(pro_detail_images.get(0).files.length) != 0){
		  	pro_detail_images.removeClass('error_in_field');						
			var formdata = new FormData(jQuery('#save_forms')[0]);						
			var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
			formdata.append('_token',CSRF_TOKEN);
			formdata.append('screen','add');			
			var data = jQuery('#save_forms').serialize();        
			jQuery.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('products')}}/productdetailimages",
 				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){										
					if(res.status == 1){
						jQuery('#pro_detail_images_data').val(res.data);
						manage_image(res.adata);
						jQuery('#pro_detail_images').val('');
					}
				}
			});			
		}else{
		  alert('Please Select Image');
		  pro_detail_images.addClass('error_in_field');
		}				
	});
});

function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){

	jQuery('.only-number').keypress(function(event){
	   if(event.which != 8 && isNaN(String.fromCharCode(event.which))){
		   event.preventDefault(); 
	   }
	});
	 
	 var pro_main_image = jQuery("#pro_main_image");	 
	 
	 var pro_cart_image = jQuery("#pro_cart_image");
	 	 	 
	 var pro_detail_images = jQuery("#pro_detail_images");
	 var pro_detail_images_data = jQuery("#pro_detail_images_data");
	 
	 var pro_name = jQuery('#pro_name');
	 var pro_price = jQuery('#pro_price');
	 var pro_market_value = jQuery('#pro_market_value');
	 var pro_deposit = jQuery('#pro_deposit');	 		 	 
	 
	 var pro_color = jQuery('#pro_color');
	 var pro_brand = jQuery('#pro_brand');
	 var pro_type = jQuery('#pro_type');




	 pro_color.blur(function(){
		required_validate(pro_color);		
	 });
	 pro_brand.blur(function(){
		required_validate(pro_brand);		
	 });
	 pro_type.blur(function(){
		required_validate(pro_type);		
	 });	 	 
	 
	 pro_name.blur(function(){
		required_validate(pro_name);		
	 });
	 
	 pro_price.blur(function(){
		required_validate(pro_price);		
	 });
	 
	 pro_market_value.blur(function(){
		required_validate(pro_market_value);		
	 });
	 
	 pro_deposit.blur(function(){
		required_validate(pro_deposit);		
	 });
	 	 	 	 	 	 	    
	 jQuery('#save_forms').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;

				
		
		if(!required_validate(pro_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_name;
		  }
		}
		
		
	    var dymhtml=pro_detail_images_data.val();
	    if(dymhtml == ''){
			pro_detail_images.addClass('error_in_field');
			alert('Upload at list one Product Detail Images.');			  		  
			flag = false; 		   
		}else{
		  pro_detail_images.removeClass('error_in_field');	
		}
		
		
		if(parseInt(pro_cart_image.get(0).files.length) == 0){
		  pro_cart_image.addClass('error_in_field');			  		  
		  flag = false; 	
		}else{
		  pro_cart_image.removeClass('error_in_field');	
		}
				
		if(parseInt(pro_main_image.get(0).files.length) == 0){
		  pro_main_image.addClass('error_in_field');			  		  
		  flag = false; 	
		}else{
		  pro_main_image.removeClass('error_in_field');	
		}
				
		if(!required_validate(pro_price)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_price;
		  }
		}
		
		if(!required_validate(pro_market_value)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_market_value;
		  }
		}
		
		if(!required_validate(pro_deposit)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_deposit;
		  }
		}		

		if(!required_validate(pro_color)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_color;
		  }
		}
		
		if(!required_validate(pro_brand)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_brand;
		  }
		}
		
		if(!required_validate(pro_type)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = pro_type;
		  }
		}
																						
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
  
@include('admin.footer')  
@include('admin.header')

    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Edit {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>

  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Edit {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_forms" method="post" action="{{route('cmspage')}}/update" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
  
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>{{$data['attrname']}} Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="page_name" id="page_name" placeholder="{{$data['attrname']}} Name" value="{{$data['pdata']->page_name}}" />
                <small class="dim-msg"><b>Slug : </b>@if($data['pdata']->page_slug == 'home') {{'/'}} @else {{$data['pdata']->page_slug}} @endif </small>
              </div>
            </div>
		</div>
        
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Meta Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="meta_title" id="meta_title" placeholder="Meta Title" value="{{$data['pdata']->meta_title}}" />                
              </div>
            </div>
		</div>
        
        <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label>Meta Description</label>                
                <textarea class="form-control" id="meta_desc" name="meta_desc" placeholder="Meta Description" rows="5">{{$data['pdata']->meta_desc}}</textarea>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group">
                <label>Meta Keyword &nbsp;&nbsp;<small class="dim-msg"><b> (Add comma separator meta keyword) </b></small></label>                
                <textarea class="form-control" id="meta_keyword" name="meta_keyword" placeholder="Meta Keyword" rows="5">{{$data['pdata']->meta_keyword}}</textarea>
              </div>
            </div>            
		</div>
                           
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Detail Page Display Name &nbsp;&nbsp;<small class="dim-msg"><b> (If empty then use page name.) </b></small></label>
                <input type="text" class="form-control" name="display_name" id="display_name" placeholder="Display Name" value="{{$data['pdata']->display_name}}" />
              </div>
            </div>
		</div>        
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Page Content</label>
                <textarea class="form-control editor" id="page_content" name="page_content" placeholder="Page Content" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" rows="5">{{$data['pdata']->page_content}}</textarea>                                
              </div>
            </div>
        </div>         
     	        
        @if($data['pdata']->page_key != 'home')
        <div class="row">            
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>
                
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="page_status" value="1" @if($data['pdata']->page_status == 1) checked @endif>
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="page_status" value="0" @if($data['pdata']->page_status == 0) checked @endif>
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>                                				  				                                                    
              </div>
            </div>                                
        </div>
        @else
         <input type="hidden" name="page_status" id="page_status" value="1" />
        @endif

        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center">                
                 <input type="hidden" id="id" name="id" value="{{$data['pdata']->id}}" />                                          
                 <button type="submit" class="btn btn-primary">Save</button>  &nbsp;&nbsp
                 <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>
                                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
   
   @if(!empty($data['custom_field']))    
    @php
      $all_product = get_all_products_list();
      $baseurll=URL::to('/');
    @endphp
   <div class="custom-fields-container">
      <section class='content-header'>
        <h3>Custom Fields</h3>
      </section>
       @php 
        $success = session()->get('success_custom');
        $meta_key = session()->get('meta_key'); 
       @endphp
                         
	   @if(isset($success))
       <div id="add_metas" class="alert alert-success delete_msg pull" style="width: 100%"> <i class="fa fa-check-circle"></i> {{session()->get('success_custom')}} &nbsp;
        	<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
       </div>
       <script>
	   jQuery(document).ready(function(e) {
			jQuery('html, body').animate({
				scrollTop: jQuery("#my-{{$meta_key}}").offset().top
			}, 2000);        
       });	   
	   </script>     	     
       @endif      
       <div class="container-fluid">
            <div class='col-xs-12'>    
                     
                  <div class='card card-default color-palette-box'>
                  <div class='card-body'>
                  @foreach($data['custom_field'] as $fieldval)
                  
                   @if($fieldval == '3box')
                   <br />
                   <h5><b>Three Pink Boxes</b></h5>
                   <br />  
                   <div id="my-{{$fieldval}}" class='card card-default color-palette-box'> 
                   	  <div class='card-body'>  
                     <h5><b>Add Field</b></h5>                                      
                     <div class="custom-fields">                      
                  	@if(isset($data['custom_field_val'][$fieldval]))
                      @if(!empty($data['custom_field_val'][$fieldval]))  
                      	  
                          @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                          
                          
                          
                          @php
                            $meta_value=$fielddval->meta_value;
                            
                            $meta_value_arr = explode(',,',$meta_value);
                            $fullarr = array();
                            foreach($meta_value_arr as $mmval){
                            	
                                $meta_val_arr = explode(':::@@',$mmval);
                                $fullarr[]=array('icon'=>$meta_val_arr[0],'text'=>$meta_val_arr[1]);
                                
                            }
                            
                            $icon1=(isset($fullarr[0]['icon']))?$fullarr[0]['icon']:'';
                            $txt1=(isset($fullarr[0]['text']))?$fullarr[0]['text']:'';
                            $icon2=(isset($fullarr[1]['icon']))?$fullarr[1]['icon']:'';
                            $txt2=(isset($fullarr[1]['text']))?$fullarr[1]['text']:'';
                            $icon3=(isset($fullarr[2]['icon']))?$fullarr[2]['icon']:'';
                            $txt3=(isset($fullarr[2]['text']))?$fullarr[2]['text']:'';                                                        
                            
                            
                            
                          @endphp                                                      
                         <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                         @csrf 
                           <div class="custom-fields-header">                                                        
                                                         
                                <div class="row">
                                    <div class="col-sm-4">
                                      <div class="form-group">
                                        <label>Text One</label>                
                                        <input type="text" id="txt1" name="txt1" value="{{$txt1}}" class="form-control">
                                      </div>                                      
                                      <div class="form-group">
                                        <label>Icon Image One <small class="dim-msg"><b>(Image Dimensions : 122 * 77)</b></small></label>                
                                        <input type="file" id="ico1" name="ico1" class="form-control file-hidden">
                                       @if(!empty($icon1))
                                        <div class="primage setting-preview-img bg-png">
                                            <img class="ico1" src="{{$baseurll}}/images/{{$icon1}}" alt="Slider Image" />
                                        </div>                                        
                                       @endif                                         
                                        <input type="hidden" name="oldico1" class="oldico1" value="{{$icon1}}" />
                                      </div>
									   
                                                                        
                                    </div>
                                    <div class="col-sm-4">
									   
                                      <div class="form-group">
                                        <label>Text Two</label>                
                                        <input type="text" id="txt2" value="{{$txt2}}" name="txt2" class="form-control">                                        
                                      </div>                                     
                                      <div class="form-group">
                                        <label>Icon Image Two <small class="dim-msg"><b>(Image Dimensions : 122 * 77)</b></small></label>                
                                        <input type="file" id="ico2" name="ico2" class="form-control file-hidden">
                                       @if(!empty($icon2))
                                        <div class="primage setting-preview-img bg-png">
                                            <img class="ico2" src="{{$baseurll}}/images/{{$icon2}}" alt="Slider Image" />
                                        </div>                                        
                                       @endif                                          
                                        <input type="hidden" name="oldico2" class="oldico2" value="{{$icon2}}" />
                                      </div>
                                                                        
                                    </div>
                                    <div class="col-sm-4">
                                      <div class="form-group">
                                        <label>Text Three</label>                
                                        <input type="text" id="txt3" value="{{$txt3}}" name="txt3" class="form-control">
                                      </div>                                     
                                      <div class="form-group">
                                        <label>Icon Image Three <small class="dim-msg"><b>(Image Dimensions : 122 * 77)</b></small></label>                
                                        <input type="file" id="ico3" name="ico3" class="form-control file-hidden">
                                       @if(!empty($icon3))
                                        <div class="primage setting-preview-img bg-png">
                                            <img class="ico3" src="{{$baseurll}}/images/{{$icon3}}" alt="Slider Image" />
                                        </div>                                        
                                       @endif                                         
                                        <input type="hidden" name="oldico3" class="oldico3" value="{{$icon3}}" />
                                      </div>
									   
                                                                        
                                    </div>
                                                
                                </div>
                              
                                <div class="row">                  
                                  <div class="col-md-12">
                                    <div class="form-group">                      
                                        <div class="controls text-center">                
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="normal" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>                                                                                                  
                                        </div>
                                    </div>
                                  </div>                                                                  
                               </div>                            
                                
                                
                                
                           </div> 
                         </form>
                         
                         @endforeach
                      @endif   
                     @endif                                          
                     </div> 
                         	  
                    </div>	
                   
                   </div>                 	
                   
                   @endif
                   
                   @if($fieldval == 'brand_product')
                   <br />
                   <h5><b>Brand Product</b></h5>
                   <br />                    		
                   <div id="my-{{$fieldval}}" class='card card-default color-palette-box'>                                            
                      <div class='card-body'>  
                     <h5><b>Add Field</b></h5>                                      
                     <div class="custom-fields">                      
                         <form name="save_attribute" method="post" action="{{route('cmspage')}}/addmeta" enctype="multipart/form-data">
                         @csrf 
                           <div class="custom-fields-header">                                                        
                                                         
                                <div class="row">
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Product Custom Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 553 * 605)</b></small></label>                
                                        <input type="file" required="required" id="img" name="img" class="form-control file-hidden">
                                      </div>
									   
                                      <div class="form-group">
                                        <label>Button Text</label>                
                                        <input type="text" id="bttxt" name="bttxt" class="form-control">
                                      </div>                                                                         
                                    </div>
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Content</label>
                                        <textarea class="form-control editor" required="required"  name="caption" placeholder="Content" rows="3"></textarea>                                        
                                      </div>
                                      <div class="form-group">
                                        <label>Select Brand</label>                
                                        <select class="form-control tagbrand" name="tagcat">
                                        @php
                                            $i=1;
                                            $firbarnd = '';
                                            $allbrand=get_all_brand();
                                        @endphp                                          
                                        @if(!empty($allbrand)) 
                                          @foreach($allbrand as $brand)
                                          	<option value="{{$brand->attr_id}}">{{$brand->attr_name}}</option>
                                          @php
                                            if($i == 1){
                                              $firbarnd = $brand->attr_id;
                                            }
                                            $i++;                                            
                                          @endphp                                            
                                          @endforeach
                                        @endif  
                                        </select>
                                      </div>
                                    
                                      
                                    </div>            
                                </div>
                              
                                <div class="row">                  
                                  <div class="col-md-12">
                                    <div class="form-group">                      
                                        <div class="controls text-center"> 
                                         <input type="hidden"  name="tagpro" value="0" />               
                                         <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                         <input type="hidden"  name="field_type" value="repeater" />
                                         <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                         <button type="submit" class="btn btn-primary">Add</button>                                                                                                   
                                        </div>
                                    </div>
                                  </div>                                                                  
                               </div>                            
                                
                                
                                
                           </div> 
                          </form>
                                                                
                     </div> 
                         	  
                    </div>
                      <div class="field-value">
                     <div class="card-body dynamic-field-{{$fieldval}}">
                  	  @if(isset($data['custom_field_val'][$fieldval]))
                        @if(!empty($data['custom_field_val'][$fieldval]))                     	
                             @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                               @php
                                 $title = $fielddval->meta_value;
                                 if(!empty($title)){
                                 	$title = strip_tags($title);
                                    $title = (strlen($title) > 35) ? substr($title,0,35).'...' : $title;
                                 }
                               @endphp                               
                           <div mid="{{$fielddval->mid}}" class="card collapsed-card meta-{{$fielddval->mid}} {{$fieldval}}">
                           <div class="card-header">
                              <span class="handle"><i class="nav-icon fas fa-th"></i></span>
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <h5 class="card-title custom-navtt">{{$title}}</h5>
                              </button>      
                                                        
                            
                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-plus"></i>
                              </button>      
                              <button type="button" onclick="delete_meta({{$fielddval->mid}});" class="btn btn-tool">
                                <i class="fas fa-times"></i>
                              </button>
                            </div>
                          </div>
                          <div class="card-body" style="display: none;">                                                                                              
                            <div class="custom-fields">                      
                             <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                             @csrf 

                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Product Custom Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 553 * 605)</b></small></label>                
                                            <input type="file"  name="img" class="form-control file-hidden">
                                               @if(!empty($fielddval->img))
                                                <div class="primage setting-preview-img">
                                                    <img class="img" src="{{$baseurll}}/products/{{$fielddval->img}}" alt="Slider Image" />
                                                </div>
                                                <input type="hidden" class="imgold" name="imgold"  value="{{$fielddval->img}}" />
                                               @endif                                            
                                          </div>
                                        </div>
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Content</label>
                                            <textarea class="form-control editor"  name="caption" placeholder="Content" rows="3">{{$fielddval->meta_value}}</textarea>                                            
                                          </div>
                                          

                                        
                                      <div class="form-group">
                                        <label>Select Brand</label>                
                                        <select class="form-control tagbrand" name="tagcat">
                                        @php
                                            $i=1;
                                            $firbarnd = '';
                                            $allbrand=get_all_brand();
                                        @endphp                                          
                                        @if(!empty($allbrand)) 
                                          @foreach($allbrand as $brand)
                                          	<option @if($fielddval->cid == $brand->attr_id){{'selected'}}@endif value="{{$brand->attr_id}}">{{$brand->attr_name}}</option>
                                          @php
                                            if($i == 1){
                                              $firbarnd = $brand->attr_id;
                                            }
                                            $i++;                                            
                                          @endphp                                            
                                          @endforeach
                                        @endif  
                                        </select>
                                      </div>                                          
                                           
                                          <div class="form-group">
                                            <label>Button Text</label>                
                                            <input type="text"  value="{{$fielddval->btxt}}" name="bttxt" class="form-control">
                                          </div>                                          
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="tagpro" value="0" />
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>  
                                                                                                                                                                                           
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                              </form>
                               
                               <div class="custom-fields-body">
                               
                               </div>
                                                                    
                            </div> 
                                      
                          </div>
                        </div>
                         
                         	 @endforeach
                        @endif
                      @endif       	
                     </div>
                    </div>
                    <script>
					jQuery(document).ready(function(){	
						jQuery(".dynamic-field-{{$fieldval}}").sortable({		
							handle: '.handle',
							update: function( event, ui ) {
								updateOrdermybrand();
							}
						});  
					}); 
					function updateOrdermybrand(){
						var item_order = new Array();
						jQuery('.dynamic-field-{{$fieldval}} .{{$fieldval}}').each(function() {
							item_order.push(jQuery(this).attr("mid"));		
						});
								
						var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
						var data = {
							_token : CSRF_TOKEN,
							orderdata : item_order,
							table : 'page_meta',
							id : 'mid',
							order : 'field_order',
						};	
						jQuery.ajax({
							type: "POST",
							url:  "{{route('update_menu_order')}}",
							data : data,
							dataType: 'JSON',
							cache: false,
							success: function(data){ }
						});		
					}   
                   </script>                    
                   </div>     
                   @endif
                   
                   @if($fieldval == 'cat_product')
                   
                   @php
                     $allcats = get_all_category_list();
                   @endphp
                   
                   <br />
                   <h5><b>Category Product</b></h5>
                   <br /> 
                   <div id="my-{{$fieldval}}" class='card card-default color-palette-box'>
                   
                    <div class='card-body'>  
                     <h5><b>Add Field</b></h5>                                      
                     <div class="custom-fields">                      
                         <form name="save_attribute"  method="post" action="{{route('cmspage')}}/addmeta" enctype="multipart/form-data">
                         @csrf 
                           <div class="custom-fields-header">                                                        
                                                         
                                <div class="row">
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Product Custom Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 553 * 605)</b></small></label>                
                                        <input required="required" type="file" id="img" name="img" class="form-control file-hidden">
                                      </div>
									   
                                      <div class="form-group">
                                        <label>Button Text</label>                
                                        <input type="text" id="bttxt" name="bttxt" class="form-control">
                                      </div>                                                                         
                                    </div>
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Main Title</label>
                                        <input required="required" type="text" name="caption" class="form-control" placeholder="Main Title" />                                        
                                      </div>
                                      <div class="form-group">
                                        <label>Select Product Category</label>                
                                        <select class="form-control tagcat" name="tagcat">
                                        @php
                                            $i=1;
                                            $fircat = '';
                                        @endphp                                          
                                        @if(!empty($allcats)) 
                                          @foreach($allcats as $alcat)
                                          	<option value="{{$alcat->cid}}">{{$alcat->cname}}</option>
                                          @php
                                            if($i == 1){
                                              $fircat = $alcat->cid;
                                            }
                                            $i++;                                            
                                          @endphp                                            
                                          @endforeach
                                        @endif  
                                        </select>
                                      </div>                                   
                                      
                                    </div>            
                                </div>
                              
                                <div class="row">                  
                                  <div class="col-md-12">
                                    <div class="form-group">                      
                                        <div class="controls text-center">                
                                         <input type="hidden"  name="tagpro" value="0" /> 
                                         
                                         <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                         <input type="hidden"  name="field_type" value="repeater" />
                                         <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                         <button type="submit" class="btn btn-primary">Add</button>                                                                                                   
                                        </div>
                                    </div>
                                  </div>                                                                  
                               </div>                            
                                
                                
                                
                           </div> 
                          </form>
                                                                
                     </div> 
                         	  
                    </div>
                    
                    <div class="field-value">
                     <div class="card-body dynamic-field-{{$fieldval}}">
                  	  @if(isset($data['custom_field_val'][$fieldval]))
                        @if(!empty($data['custom_field_val'][$fieldval]))                     	
                             @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                               @php
                                 $title = $fielddval->meta_value;
                                 if(!empty($title)){
                                 	$title = strip_tags($title);
                                    $title = (strlen($title) > 35) ? substr($title,0,35).'...' : $title;
                                 }
                               @endphp                               
                           <div mid="{{$fielddval->mid}}" class="card collapsed-card meta-{{$fielddval->mid}} {{$fieldval}}">
                           <div class="card-header">
                              <span class="handle"><i class="nav-icon fas fa-th"></i></span>
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <h5 class="card-title custom-navtt">{{$title}}</h5>
                              </button>      
                                                        
                            
                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-plus"></i>
                              </button>      
                              <button type="button" onclick="delete_meta({{$fielddval->mid}});" class="btn btn-tool">
                                <i class="fas fa-times"></i>
                              </button>
                            </div>
                          </div>
                          <div class="card-body" style="display: none;">                                                                                              
                            <div class="custom-fields">                      
                             <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                             @csrf 

                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Product Custom Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 553 * 605)</b></small></label>                
                                            <input type="file"  name="img" class="form-control file-hidden">
                                               @if(!empty($fielddval->img))
                                                <div class="primage setting-preview-img">
                                                    <img class="img" src="{{$baseurll}}/products/{{$fielddval->img}}" alt="Slider Image" />
                                                </div>
                                                <input type="hidden" class="imgold" name="imgold"  value="{{$fielddval->img}}" />
                                               @endif                                            
                                          </div>
                                        </div>
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Main Title</label>
                                            <textarea class="form-control"  name="caption" placeholder="Slider Caption" rows="3">{{$fielddval->meta_value}}</textarea>                                            
                                          </div>
                                          
                                          
                                      <div class="form-group">
                                        <label>Select Product Category</label>                
                                        <select class="form-control" name="tagcat">
                                        @php
                                            $i=1;
                                            $fircat = '';
                                        @endphp                                          
                                        @if(!empty($allcats)) 
                                          @foreach($allcats as $alcat)
                                          	<option @if($fielddval->cid == $alcat->cid){{'selected'}}@endif value="{{$alcat->cid}}">{{$alcat->cname}}</option>
                                          @php
                                            if($i == 1){
                                              $fircat = $alcat->cid;
                                            }
                                            $i++;                                            
                                          @endphp                                            
                                          @endforeach
                                        @endif  
                                        </select>
                                      </div>                                        
                                          
                                           
                                          <div class="form-group">
                                            <label>Button Text</label>                
                                            <input type="text"  value="{{$fielddval->btxt}}" name="bttxt" class="form-control">
                                          </div>                                          
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="tagpro" value="0" />
                                             
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>  
                                                                                                                                                                                           
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                              </form>
                               
                               <div class="custom-fields-body">
                               
                               </div>
                                                                    
                            </div> 
                                      
                          </div>
                        </div>
                         
                         	 @endforeach
                        @endif
                      @endif       	
                     </div>
                    </div>                    
                    <script>
					jQuery(document).ready(function(){	
						jQuery(".dynamic-field-{{$fieldval}}").sortable({		
							handle: '.handle',
							update: function( event, ui ) {
								updateOrdermycat();
							}
						});  
					}); 
					function updateOrdermycat(){
						var item_order = new Array();
						jQuery('.dynamic-field-{{$fieldval}} .{{$fieldval}}').each(function() {
							item_order.push(jQuery(this).attr("mid"));		
						});
								
						var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
						var data = {
							_token : CSRF_TOKEN,
							orderdata : item_order,
							table : 'page_meta',
							id : 'mid',
							order : 'field_order',
						};	
						jQuery.ajax({
							type: "POST",
							url:  "{{route('update_menu_order')}}",
							data : data,
							dataType: 'JSON',
							cache: false,
							success: function(data){ }
						});		
					}   
                   </script>
                   
                   </div>                    
                   @endif
                   
                   @if($fieldval == 'new_prod')
                   <br />
                   <h5><b>New Arrival</b></h5>
                   <br />                    	
                   <div id="my-{{$fieldval}}" class='card card-default color-palette-box'>
                     <div class='card-body'>  
                        <h5><b>Add Field</b></h5> 
                        <div class="custom-fields">                      
                           <form name="save_attribute"  method="post" action="{{route('cmspage')}}/addmeta" enctype="multipart/form-data">
                               @csrf 
                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>New Arrival Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 452 * 548)</b></small></label>                
                                            <input required="required" type="file" id="img" name="img" class="form-control file-hidden">
                                          </div>
                                                                        
                                        </div>
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Select Target Product</label>                
                                            <select class="form-control" name="tagpro" id="tagpro">
                                            @if(!empty($all_product))   
                                              @foreach($all_product as $alpro)
                                                <option value="{{$alpro->pro_id}}">{{$alpro->pro_name}}</option>
                                              @endforeach
                                            @endif  
                                            </select>
                                          </div>                                                                                                                                
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <button type="submit" class="btn btn-primary">Add</button>                                                                                                   
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                           </form>                                                                    
                        </div> 
                        
                     </div> 
                     
                    <div class="field-value">
                     <div class="card-body dynamic-field-{{$fieldval}}">
                  	  @if(isset($data['custom_field_val'][$fieldval]))
                        @if(!empty($data['custom_field_val'][$fieldval]))                     	
                             @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                               @php
                                 $title = $fielddval->meta_value;
                                 
                               @endphp                               
                           <div mid="{{$fielddval->mid}}" class="card collapsed-card meta-{{$fielddval->mid}} {{$fieldval}}">
                           <div class="card-header">
                              <span class="handle"><i class="nav-icon fas fa-th"></i></span>
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <h5 class="card-title custom-navtt">{{get_product_name_by_id($title)}}</h5>
                              </button>      
                                                        
                            
                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-plus"></i>
                              </button>      
                              <button type="button" onclick="delete_meta({{$fielddval->mid}});" class="btn btn-tool">
                                <i class="fas fa-times"></i>
                              </button>
                            </div>
                          </div>
                          <div class="card-body" style="display: none;">                                                                                              
                            <div class="custom-fields">                      
                             <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                             @csrf 

                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Slider Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 590 * 312)</b></small></label>                
                                            <input type="file"  name="img" class="form-control file-hidden">
                                               @if(!empty($fielddval->img))
                                                <div class="primage setting-preview-img">
                                                    <img class="img" src="{{$baseurll}}/products/{{$fielddval->img}}" alt="Slider Image" />
                                                </div>
                                                <input type="hidden" class="imgold" name="imgold"  value="{{$fielddval->img}}" />
                                               @endif                                            
                                          </div>
                                        </div>
                                        <div class="col-sm-6">                                          
                                          <div class="form-group">
                                            <label>Select Target Product</label>                
                                            <select class="form-control" name="tagpro">
                                            @if(!empty($all_product))   
                                              @foreach($all_product as $alpro)
                                                <option @if($fielddval->pro_id == $alpro->pro_id){{'selected'}}@endif value="{{$alpro->pro_id}}">{{$alpro->pro_name}}</option>
                                              @endforeach
                                            @endif  
                                            </select>
                                          </div>                                                                                     
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>  
                                                                                                                                                                                           
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                              </form>
                               
                               <div class="custom-fields-body">
                               
                               </div>
                                                                    
                            </div> 
                                      
                          </div>
                        </div>
                         
                         	 @endforeach
                        @endif
                      @endif       	
                     </div>
                    </div>                      
                     
                   </div>
                   <script>
					jQuery(document).ready(function(){	
						jQuery(".dynamic-field-{{$fieldval}}").sortable({		
							handle: '.handle',
							update: function( event, ui ) {
								updateOrderxy();
							}
						});  
					}); 
					function updateOrderxy(){
						var item_order = new Array();
						jQuery('.dynamic-field-{{$fieldval}} .{{$fieldval}}').each(function() {
							item_order.push(jQuery(this).attr("mid"));		
						});		
						var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
						var data = {
							_token : CSRF_TOKEN,
							orderdata : item_order,
							table : 'page_meta',
							id : 'mid',
							order : 'field_order',
						};	
						jQuery.ajax({
							type: "POST",
							url:  "{{route('update_menu_order')}}",
							data : data,
							dataType: 'JSON',
							cache: false,
							success: function(data){ }
						});		
					}   
                   </script>
                   @endif
                   
                   
                   @if($fieldval == 'home_slider')
                   <h5><b>Page Slider</b></h5>
                   <br />  
                   <div id="my-{{$fieldval}}" class='card card-default color-palette-box'>
                                      
                    <div class='card-body'>  
                     <h5><b>Add Field</b></h5>                                      
                     <div class="custom-fields">                      
                         <form name="save_attribute"  method="post" action="{{route('cmspage')}}/addmeta" enctype="multipart/form-data">
                         @csrf 
                           <div class="custom-fields-header">                                                        
                                                         
                                <div class="row">
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Slider Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 590 * 312)</b></small></label>                
                                        <input required="required" type="file" id="img" name="img" class="form-control file-hidden">
                                      </div>									   
                                      <div class="form-group">
                                        <label>Button Text</label>                
                                        <input required="required" type="text" id="bttxt" name="bttxt" class="form-control">
                                      </div>                                                                         
                                    </div>
                                    <div class="col-sm-6">
                                      <div class="form-group">
                                        <label>Slider Caption</label>
                                        <textarea required="required" class="form-control editor" id="caption" name="caption" placeholder="Slider Caption" rows="3"></textarea>
                                      </div>
                                      
                                    </div>            
                                </div>
                              
                                <div class="row">                  
                                  <div class="col-md-12">
                                    <div class="form-group">                      
                                        <div class="controls text-center">                
                                         
                                         <input type="hidden"  name="tagpro" value="0" />
                                         
                                         <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                         <input type="hidden"  name="field_type" value="repeater" />
                                         <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                         <button type="submit" class="btn btn-primary">Add</button>                                                                                                   
                                        </div>
                                    </div>
                                  </div>                                                                  
                               </div>                            
                                
                                
                                
                           </div> 
                          </form>
                                                                
                     </div> 
                         	  
                    </div>
                    
                    <div class="field-value">
                     <div class="card-body dynamic-field-{{$fieldval}}">
                  	  @if(isset($data['custom_field_val'][$fieldval]))
                        @if(!empty($data['custom_field_val'][$fieldval]))                     	
                             @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                               @php
                                 $title = $fielddval->meta_value;
                                 if(!empty($title)){
                                 	$title = strip_tags($title);
                                    $title = (strlen($title) > 35) ? substr($title,0,35).'...' : $title;
                                 }
                               @endphp                               
                           <div mid="{{$fielddval->mid}}" class="card collapsed-card meta-{{$fielddval->mid}} {{$fieldval}}">
                           <div class="card-header">
                              <span class="handle"><i class="nav-icon fas fa-th"></i></span>
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <h5 class="card-title custom-navtt">{{$title}}</h5>
                              </button>      
                                                        
                            
                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-plus"></i>
                              </button>      
                              <button type="button" onclick="delete_meta({{$fielddval->mid}});" class="btn btn-tool">
                                <i class="fas fa-times"></i>
                              </button>
                            </div>
                          </div>
                          <div class="card-body" style="display: none;">                                                                                              
                            <div class="custom-fields">                      
                             <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                             @csrf 

                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Slider Image&nbsp;<small class="dim-msg"><b>(Image Dimensions : 590 * 312)</b></small></label>                
                                            <input type="file"  name="img" class="form-control file-hidden">
                                               @if(!empty($fielddval->img))
                                                <div class="primage setting-preview-img">
                                                    <img class="img" src="{{$baseurll}}/products/{{$fielddval->img}}" alt="Slider Image" />
                                                </div>
                                                <input type="hidden" class="imgold" name="imgold"  value="{{$fielddval->img}}" />
                                               @endif                                            
                                          </div>
                                        </div>
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Slider Caption</label>
                                            <textarea class="form-control editor"  name="caption" placeholder="Slider Caption" rows="3">{{$fielddval->meta_value}}</textarea>                                            
                                          </div>
                                           
                                          <div class="form-group">
                                            <label>Button Text</label>                
                                            <input type="text"  value="{{$fielddval->btxt}}" name="bttxt" class="form-control">
                                          </div>                                          
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="tagpro" value="0" />
                                             
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>  
                                                                                                                                                                                           
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                              </form>
                               
                               <div class="custom-fields-body">
                               
                               </div>
                                                                    
                            </div> 
                                      
                          </div>
                        </div>
                         
                         	 @endforeach
                        @endif
                      @endif       	
                     </div>
                    </div>                    
                                       
                   <script>
					jQuery(document).ready(function(){	
						jQuery(".dynamic-field-{{$fieldval}}").sortable({		
							handle: '.handle',
							update: function( event, ui ) {
								updateOrdernn();
							}
						});  
					}); 
					function updateOrdernn(){
						var item_order = new Array();
						jQuery('.dynamic-field-{{$fieldval}} .{{$fieldval}}').each(function() {
							item_order.push(jQuery(this).attr("mid"));		
						});		
						var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
						var data = {
							_token : CSRF_TOKEN,
							orderdata : item_order,
							table : 'page_meta',
							id : 'mid',
							order : 'field_order',
						};	
						jQuery.ajax({
							type: "POST",
							url:  "{{route('update_menu_order')}}",
							data : data,
							dataType: 'JSON',
							cache: false,
							success: function(data){ }
						});		
					}   
                   </script>
                   </div> 
                   @endif
                   
                   
                   @if($fieldval == 'how_it_content')
                  <h5><b>How it's work repeater fields</b></h5>
                  <br /> 
                  <div class='card card-default color-palette-box'>
                    
                     
                    <div class='card-body'>  
                     <h5><b>Add Field</b></h5>                                      
                     <div class="custom-fields">                      
                     <form name="save_attribute" method="post" action="{{route('cmspage')}}/addmeta" enctype="multipart/form-data">
                     @csrf 
                       <div class="custom-fields-header">                                                        
                                                     
                            <div class="row">
                                <div class="col-sm-6">
                                  <div class="form-group">
                                    <label>SVG Image Code</label>                
                                    <textarea required="required" class="form-control" id="svg_code" name="svg_code" placeholder="SVG Image Code" rows="7"></textarea>
                                  </div>
                                </div>
                                <div class="col-sm-6">
                                  <div class="form-group">
                                    <label>Field Title</label>
                                    <input required="required" type="text" class="form-control" name="field_title" id="field_title" placeholder="Field Title" value="" />                                                    
                                  </div>
                                  <div class="form-group">
                                    <label>Field Detail</label>                
                                    <textarea required="required" class="form-control" id="field_detail" name="field_detail" placeholder="Field Detail" rows="3"></textarea>
                                  </div>
                                </div>            
                            </div>
                          
						    <div class="row">                  
                              <div class="col-md-12">
                                <div class="form-group">                      
                                    <div class="controls text-center">                
                                     <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                     <input type="hidden"  name="field_type" value="repeater" />
                                     <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                     <button type="submit" class="btn btn-primary">Add</button>                                                                                                   
                                    </div>
                                </div>
                              </div>                                                                  
                           </div>                            
                            
                            
                            
                       </div> 
                      </form>
                                                            
                    </div> 
                         	  
                    </div>
                  
                    <div class="field-value">
                    <div class="card-body dynamic-field-{{$fieldval}}">
                  	@if(isset($data['custom_field_val'][$fieldval]))
                      @if(!empty($data['custom_field_val'][$fieldval]))  
                      	  
                          @foreach($data['custom_field_val'][$fieldval] as $fielddval)
                          
                          
                          
                          @php
                            $meta_value=$fielddval->meta_value;
                            $meta_value_arr = explode(':::@@',$meta_value);
                            
                            $svg_code = (isset($meta_value_arr[0]))?$meta_value_arr[0]:'';
                            $field_title = (isset($meta_value_arr[1]))?$meta_value_arr[1]:'';
                            $field_detail = (isset($meta_value_arr[2]))?$meta_value_arr[2]:'';
                            
                          @endphp
                         
                          
                          <div mid="{{$fielddval->mid}}" class="card collapsed-card meta-{{$fielddval->mid}} {{$fieldval}}">
                          <div class="card-header">
                              <span class="handle"><i class="nav-icon fas fa-th"></i></span>
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <h5 class="card-title custom-navtt">{{$field_title}}</h5>
                              </button>      
                                                        
                            
                            <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-plus"></i>
                              </button>      
                              <button type="button" onclick="delete_meta({{$fielddval->mid}});" class="btn btn-tool">
                                <i class="fas fa-times"></i>
                              </button>
                            </div>
                          </div>
                          <div class="card-body" style="display: none;">                                                                                              
                            <div class="custom-fields">                      
                             <form name="save_attribute" class="edit_meta" method="post" action="{{route('cmspage')}}/editmeta" enctype="multipart/form-data">
                             @csrf 
                               <div class="custom-fields-header">                                                        
                                                             
                                    <div class="row">
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>SVG Image Code</label>                
                                            <textarea class="form-control" id="svg_code" name="svg_code" placeholder="SVG Image Code" rows="7">{{$svg_code}}</textarea>
                                          </div>
                                        </div>
                                        <div class="col-sm-6">
                                          <div class="form-group">
                                            <label>Field Title</label>
                                            <input type="text" class="form-control" name="field_title" id="field_title" placeholder="Field Title" value="{{$field_title}}" />                                                    
                                          </div>
                                          <div class="form-group">
                                            <label>Field Detail</label>                
                                            <textarea class="form-control" id="field_detail" name="field_detail" placeholder="Field Detail" rows="3">{{$field_detail}}</textarea>
                                          </div>
                                        </div>            
                                    </div>
                                  
                                    <div class="row">                  
                                      <div class="col-md-12">
                                        <div class="form-group">                      
                                            <div class="controls text-center">                
                                             <input type="hidden"  name="mid" value="{{$fielddval->mid}}" />
                                             <input type="hidden"  name="pid" value="{{$data['pdata']->id}}" /> 
                                             <input type="hidden"  name="field_type" value="repeater" />
                                             <input type="hidden"  name="meta_key" value="{{$fieldval}}" />                                          
                                             <img class="loader-img" src="{{URL::asset('images/ajax-loader.gif')}}" alt="Ajax Loader" />
                                             <button type="submit" class="btn btn-primary">Edit</button>  
                                                                                                                                                                                           
                                            </div>
                                        </div>
                                      </div>                                                                  
                                   </div>                            
                                    
                                    
                                    
                               </div> 
                              </form>
                               
                               <div class="custom-fields-body">
                               
                               </div>
                                                                    
                            </div> 
                                      
                          </div>
                        </div>
                        
                         
                            
                          @endforeach
                      
                       @endif 
                    @endif
                     </div>
                    </div>
                    
                  </div>
				   <script>
					jQuery(document).ready(function(){	
						jQuery(".dynamic-field-{{$fieldval}}").sortable({		
							handle: '.handle',
							update: function( event, ui ) {
								updateOrder();
							}
						});  
					}); 
					function updateOrder(){
						var item_order = new Array();
						jQuery('.dynamic-field-{{$fieldval}} .{{$fieldval}}').each(function() {
							item_order.push(jQuery(this).attr("mid"));		
						});		
						var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');				
						var data = {
							_token : CSRF_TOKEN,
							orderdata : item_order,
							table : 'page_meta',
							id : 'mid',
							order : 'field_order',
						};	
						jQuery.ajax({
							type: "POST",
							url:  "{{route('update_menu_order')}}",
							data : data,
							dataType: 'JSON',
							cache: false,
							success: function(data){ }
						});		
					}   
                   </script>                      
                   @endif
                   
                  
                  @endforeach
               	  </div>
                  </div>       
           </div>
       </div>
   </div>

   @endif	

   
  </section>
</div>  
<script>
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}

function delete_meta(mid){		
	
	if(confirm("Are you sure you want to delete this item?")){
								
		var formdata = new FormData();
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('mid',mid);
		jQuery.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN
			}
		});							
		jQuery.ajax({
			type: "POST",
			url:  "{{route('cmspage')}}/deletemeta",
			data: formdata,
			processData: false, 
			contentType: false,
			cache: false,
			success: function(res){										
				if(res.status == 1){
					jQuery('.meta-'+mid).remove();					
				}
			}
		});				
		
	}
	
	
}


jQuery(document).ready(function(e){

	//tagbrand

	jQuery('.tagbrand').change(function(){
		var aac = jQuery(this);
		var formdata = new FormData();
		var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('bid',aac.val());
		jQuery.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN
			}
		});							
		jQuery.ajax({
			type: "POST",
			url:  "{{route('cmspage')}}/brandroduct",
			data: formdata,
			processData: false, 
			contentType: false,
			cache: false,
			success: function(res){										
				if(res.status == 1){
					aac.parent().parent().find('.tagcatpro').html(res.data);					
				}
			}
		});									
	});
	
	jQuery('.tagcat').change(function(){
		var aac = jQuery(this);
		var formdata = new FormData();
		var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('cid',aac.val());
		jQuery.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN
			}
		});							
		jQuery.ajax({
			type: "POST",
			url:  "{{route('cmspage')}}/catproduct",
			data: formdata,
			processData: false, 
			contentType: false,
			cache: false,
			success: function(res){										
				if(res.status == 1){
					aac.parent().parent().find('.tagcatpro').html(res.data);					
				}
			}
		});									
	});

	jQuery('.edit_meta').submit(function(e){
		
		e.preventDefault();				
		var formdata = new FormData(jQuery(this)[0]);
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
		formdata.append('_token',CSRF_TOKEN);
				
		var aa = jQuery(this);
		aa.find('.loader-img').show();				      
		jQuery.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': CSRF_TOKEN
			}
		});							
		jQuery.ajax({
			type: "POST",
			url:  "{{route('cmspage')}}/editmeta",
			data: formdata,
			processData: false, 
			contentType: false,
			cache: false,
			success: function(res){										
				if(res.status == 1){
					setTimeout(function(){ 
						aa.find('.loader-img').hide();						
						aa.parent().parent().parent().find('.card-title').html(res.loptitle);						
						if(res.imgsrc != ''){
							aa.find('.img').attr('src',res.imgsrc);
							aa.find('.imgold').val(res.imgid);
						}						
						if(res.ico1 != ''){
							aa.find('.ico1').attr('src','/images/'+res.ico1);
							aa.find('.oldico1').val(res.ico1);
						}
						if(res.ico2 != ''){
							aa.find('.ico2').attr('src','/images/'+res.ico2);
							aa.find('.oldico2').val(res.ico2);
						}
						if(res.ico3 != ''){
							aa.find('.ico3').attr('src','/images/'+res.ico3);
							aa.find('.oldico3').val(res.ico3);
						}																		
						
						jQuery("[type*='file']").val('');
						
					},500);					
				}else{
					alert('Record Not Updated.');	
				}
				
			}
		});			
		
	});
	 
	 var page_name = jQuery('#page_name');
	 var meta_title = jQuery('#meta_title');	 
	 
	 page_name.blur(function(){
		required_validate(attr_name);		
	 });
	 
	 meta_title.blur(function(){
		required_validate(meta_title);		
	 });	 	    

	 jQuery('#save_forms').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;
		
		if(!required_validate(page_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = page_name;
		  }
		}
		
		if(!required_validate(meta_title)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = meta_title;
		  }
		}				
																
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
@include('admin.footer')  
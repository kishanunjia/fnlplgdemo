@include('admin.header')

<!-- Navbar -->  
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Add CMS Page</a>
      </li>
    </ul>    
</nav>  
<!-- /.navbar -->

<div class='content-wrapper'>
  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Add {{$data['attrname']}} </h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_attribute" method="post" action="{{route('cmspage')}}/create" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
     	
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>{{$data['attrname']}} Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="page_name" id="page_name" placeholder="{{$data['attrname']}} Name" value="" />
              </div>
            </div>
		</div>
        
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Detail Page Display Name &nbsp;&nbsp;<small class="dim-msg"><b> (If empty then use page name.) </b></small></label>
                <input type="text" class="form-control" name="display_name" id="display_name" placeholder="Display Name" value="" />
              </div>
            </div>
		</div>        
        
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label>Page Content</label>
                <textarea class="form-control editor" id="page_content" name="page_content" placeholder="Page Content" style="width: 100%; height: 400px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" rows="5"></textarea>                                
              </div>
            </div>
        </div>
          
          <div class="row">  
            <div class="col-sm-12">
              <div class="form-group">
                <label>Page Status</label>
				<div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="page_status" value="1" checked="checked">
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="page_status" value="0">
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
               </div>				  
				                                                    
              </div>
            </div>                        
        
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center">
                 <input type="hidden" name="page_key" value="general" />                         
                 <button type="submit" class="btn btn-primary">Save</button> &nbsp;&nbsp;                 
                  <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
<script>
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){
	 
	 var page_name = jQuery('#page_name');
		 
	 
	 page_name.blur(function(){
		required_validate(attr_name);		
	 });	    

	 jQuery('#save_attribute').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;
		
		if(!required_validate(page_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = page_name;
		  }
		}		
																
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
  
@include('admin.footer')  
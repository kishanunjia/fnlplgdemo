  <footer class="main-footer">
    <strong>Copyright &copy; 2020 BeRightBag.</strong>
    All rights reserved.    
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

  
  <script src="{{URL::asset('admin/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>

<script src="{{URL::asset('admin/plugins/select2/js/select2.full.min.js')}}"></script>

<!-- Bootstrap 4 -->
<script src="{{URL::asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{URL::asset('admin/plugins/chart.js/Chart.min.js')}}"></script>
<!-- Sparkline -->
<script src="{{URL::asset('admin/plugins/sparklines/sparkline.js')}}"></script>
<!-- JQVMap -->
<script src="{{URL::asset('admin/plugins/jqvmap/jquery.vmap.min.js')}}"></script>
<script src="{{URL::asset('admin/plugins/jqvmap/maps/jquery.vmap.usa.js')}}"></script>
<!-- jQuery Knob Chart -->
<script src="{{URL::asset('admin/plugins/jquery-knob/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{URL::asset('admin/plugins/moment/moment.min.js')}}"></script>
<script src="{{URL::asset('admin/plugins/daterangepicker/daterangepicker.js')}}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{URL::asset('admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')}}"></script>
<!-- Summernote -->
<script src="{{URL::asset('admin/plugins/summernote/summernote-bs4.min.js')}}"></script>
<!-- overlayScrollbars -->
<script src="{{URL::asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{URL::asset('admin/dist/js/adminlte.js')}}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{{URL::asset('admin/dist/js/pages/dashboard.js')}}"></script>
<script src="{{URL::asset('admin/dist/js/demo.js')}}"></script>

<script src="{{URL::asset('admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js')}}"></script>

<script src="{{URL::asset('admin/plugins/summernote/summernote-bs4.min.js')}}"></script>

<script>
  jQuery(function () {
    //Initialize Select2 Elements
    jQuery('.select2').select2();
	jQuery('.editor').summernote({
		toolbar: [
		  ['style', ['style']],
		  ['font', ['bold', 'underline', 'clear']],
		  ['fontname', ['fontname']],
		  ['color', ['color']],
		  ['para', ['ul', 'ol', 'paragraph']],
		  ['table', ['table']],
		  ['insert', ['link','video']],
		  ['view', ['fullscreen', 'codeview']]
		]		
		
	});
		
    jQuery('#dis_start').datetimepicker({
		timepicker:false,
		format: 'MM/DD/YYYY',
		minDate: '<?=date("m/d/Y");?>',
    });
	
    jQuery('#dis_end').datetimepicker({
		timepicker:false,
		format: 'MM/DD/YYYY',
		minDate: '<?=date("m/d/Y");?>',
    });	
	
    jQuery("input[data-bootstrap-switch]").each(function(){
      jQuery(this).bootstrapSwitch('state', jQuery(this).prop('checked'));
    });		
	
  });
</script>
</body>
</html>
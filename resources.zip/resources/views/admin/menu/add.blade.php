@include('admin.header')

    <!-- Navbar -->
  
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="javascript:void(0);" class="nav-link">Add {{$data['attrname']}}</a>
      </li>
    </ul>    
  </nav>
  
  <!-- /.navbar -->

<div class='content-wrapper'>

  <!-- Main content -->
  <section class='content'>
  <section class='content-header'>
    <h1>Add {{$data['attrname']}}</h1>
  </section>  
   <div class="container-fluid">
    
    <div class='col-xs-12'>    
    <div class='card card-default color-palette-box'>        
                             
     <form name="save_attribute" id="save_attribute" method="post" action="{{route('menu')}}/create" enctype="multipart/form-data">
     @csrf
      <div class='card-body'>		
     	
        <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                   <label>Menu Name</label>
                   <input type="text" class="form-control" name="m_name" id="m_name" placeholder="Menu Name" value="" />
              </div>
            </div>  
        </div>    
         
         <div class="row">             
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Select Page</label>
                   <select name="pid" id="pid" class="form-control">
                      <option value="0">-Menu Custom URL-</option>
                      @if(!empty($data['pages'])){
                      	@foreach($data['pages'] as $page)
                      	  <option value="{{$page->id}}">{{$page->page_name}}</option>
                      	@endforeach
                      @endif
                   </select>
                   <br />
                   <input type="text" name="m_url" id="m_url" class="form-control" placeholder="Menu Custom URL" />                                      
              </div>                                                                          
            </div>
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Parent Menu</label>
                   <select name="mpid" id="mpid" class="form-control">
                      <option value="0">-Select Parent Menu-</option>
                      @if(!empty($data['menus'])){
                      	@foreach($data['menus'] as $mens)
                      	  <option value="{{$mens->m_id}}">{{$mens->m_name}}</option>
                      	@endforeach
                      @endif
                   </select>                   
              </div>
            </div>
            
            <div class="col-sm-4">
              <div class="form-group">
                   <label>Menu Target</label>
                   <select name="m_target" id="m_target" class="form-control">
                      <option value="">Self</option>                      
                      <option value="blank">New Tab</option>
                   </select>                   
              </div>
            </div>
                        
          </div>
          
          <div class="row"> 
             
              
          </div>
          
          <div class="row">   
            <div class="col-sm-12">
              <div class="form-group">
                <label>Status</label>				  
				  <div class="form-group clearfix">
                      <div class="icheck-primary d-inline">
                        <input type="radio" id="radioPrimary1" name="m_status" value="1" checked="checked">
                        <label for="radioPrimary1">Active
                        </label>
                      </div>&nbsp;&nbsp;
                      <div class="icheck-danger d-inline">
                        <input type="radio" id="radioPrimary2" name="m_status" value="0">
                        <label for="radioPrimary2">Deactive
                        </label>
                      </div>                      
                   </div>                                                                                    
              </div>
            </div>                        
        
        </div>
        
        <div class="row">                  
          <div class="col-md-12">
            <div class="form-group"> 
                <br />
                <br />                       
                <div class="controls text-center"> 
                  <input type="hidden" name="m_type" value="{{$data['dbname']}}" />                                         
                  <button type="submit" class="btn btn-primary">Save</button> &nbsp;&nbsp;                 
                  <a href="{{route($data['back_router'])}}" class="btn btn-default active">Back</a>                           
                </div>
            </div>
          </div>                                                                  
        </div>         
                                   
      </div>
 	 </form>
     
    </div>
     
    </div> 
    
   </div>
  </section>
</div>  
<script>
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field');
	  return true;		
	}
}



jQuery(document).ready(function(e){

	jQuery('#pid').change(function(){		
		var pidss=jQuery(this).val();	
		if(pidss == 0){
			jQuery('#m_url').attr('type','text');	
		}else{
			jQuery('#m_url').attr('type','hidden');
		}
	});
	 
	 var m_name = jQuery('#m_name');
	 var pid    = jQuery('#pid');
	 var m_url    = jQuery('#m_url');
	 		 	 
	 m_name.blur(function(){
		required_validate(m_name);		
	 });
	 	    
	 jQuery('#save_attribute').submit(function(e){
		var flag = true;
		var scroll_flag = false;
		var scroll_obj = false;
		
		if(!required_validate(m_name)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true;
			  scroll_obj = m_name;
		  }
		}
		
		if(pid.val() == 0){
			
			if(!required_validate(m_url)){
			  flag = false;
			  if(!scroll_flag){
				  scroll_flag = true;
				  scroll_obj = m_url;
			  }
			}				
			
		}
		
																				
		if(scroll_flag){			
		    jQuery('html, body').animate({
				'scrollTop' : scroll_obj.offset().top - 90				
			}, 700);			
			scroll_obj.focus();		   	
		}
								
		return flag;  		
	});

});
</script>  
  
@include('admin.footer')  
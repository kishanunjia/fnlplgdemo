@extends('layouts.app')

@section('content')

@if(isset($data['home_slider']) && !empty($data['home_slider']))
<!-- slider start -->
<div class="mainslider">
    <div class="sliderwrap">
     @foreach($data['home_slider'] as $hmslide)  
     	@php        	
            
            $name = 'Home Slider';            
        @endphp        
       <div class="slide-item">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-lg-5 sliderimage"><img src="{{asset('products/').'/'.$hmslide->img}}" alt="{{$name}}" /></div>
            <div class="col-lg-7 slidercaption">{!! $hmslide->meta_value !!}<a href="{{url('/').'/'.get_page_url_by_id(6)}}" class="rentingbtn">{{$hmslide->btxt}}</a></div>
          </div>
        </div>
      </div>
     @endforeach
    </div>
</div>
<!-- slider end -->
@endif

@if(isset($data['boxs']))
@php
    $meta_value=$data['boxs']->meta_value;		    
    $fullarr = array();
    if(!empty($meta_value)){
        $meta_value_arr = explode(',,',$meta_value);
        foreach($meta_value_arr as $mmval){                            	
            $meta_val_arr = explode(':::@@',$mmval);
            $fullarr[]=array('icon'=>$meta_val_arr[0],'text'=>$meta_val_arr[1]);                                
        }                       
    }     
    $icon1=(isset($fullarr[0]['icon']))?$fullarr[0]['icon']:'';
    $txt1=(isset($fullarr[0]['text']))?$fullarr[0]['text']:'';
    $icon2=(isset($fullarr[1]['icon']))?$fullarr[1]['icon']:'';
    $txt2=(isset($fullarr[1]['text']))?$fullarr[1]['text']:'';
    $icon3=(isset($fullarr[2]['icon']))?$fullarr[2]['icon']:'';
    $txt3=(isset($fullarr[2]['text']))?$fullarr[2]['text']:''; 
        
@endphp
<!-- three box-section start -->
  <div class="featureswrapper">
      <div class="container">
          <div class="row">
              <div class="col-md-4">
              <div class="featuresbox">@if(!empty($icon1))<span class="featuresicn"><img src="{{asset('images/').'/'.$icon1}}" alt="{{$txt1}}" /></span>@endif<span class="featurestxt">{{$txt1}}</span>
              </div>
              </div>
              <div class="col-md-4">
                  <div class="featuresbox">@if(!empty($icon2))<span class="featuresicn"><img src="{{asset('images/').'/'.$icon2}}" alt="{{$txt2}}" /></span>@endif<span class="featurestxt">{{$txt2}}</span>                        
                  </div>
              </div>
              <div class="col-md-4">
                  <div class="featuresbox">@if(!empty($icon3))<span class="featuresicn"><img src="{{asset('images/').'/'.$icon3}}" alt="{{$txt3}}" /></span>@endif<span class="featurestxt">{{$txt3}}</span> 
                  </div>
              </div>
          </div>
      </div>
  </div>
<!-- three box-section over -->
@endif
@if(isset($data['cat_product']) && !empty($data['cat_product']))
<!-- tab wrapper -->
<div class="tabwrapper">
    <div class="container">
      <div id="tabs">
        <div class="tab-content">
            @php
              $i=0;
              $first_url = '';
              $urlbycats = array();
            @endphp
          	@foreach($data['cat_product'] as $catpro) 
            @php        	
                $i++;
                $slug = (isset($catpro->pro_slug))?pro_slug_prefix($catpro->pro_slug):'';
                $name = (isset($catpro->pro_name))?$catpro->pro_name:''; 
                if($i == 1){ $first_url = url('/').'/'.$slug; }                        
            @endphp                     
             <div class="tab-pane show @if($i == 1){{'active'}}@endif" id="bag{{$catpro->mid}}" role="tabpanel" aria-labelledby="bag{{$catpro->mid}}-tab">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="tabtitle"><span>{!! $catpro->meta_value !!}</span></div>
                        <div class="renringbtn-wrap d-none d-lg-block">
                            <a href="{{url('/').'/'.get_page_url_by_id(6)}}" class="rentingbtn" tabindex="0">{{$catpro->btxt}}</a>
                        </div>
                    </div>    
                    <div class="col-lg-7">
                      <div class="greybg">
                        <div class="tabbagwrap">
                            <img src="{{asset('products/').'/'.$catpro->img}}" alt="{{$catpro->btxt}}" />
                        </div>
                      </div>    
                    </div>
                </div>
            </div>           
			@endforeach          
        </div>
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
            @php
              $i=0;
            @endphp          
           @foreach($data['cat_product'] as $catpro) 
            @php
              $i++;
              $slug = (isset($catpro->pro_slug))?pro_slug_prefix($catpro->pro_slug):'';
              $cname=strip_tags($catpro->meta_value);
            @endphp             
           <a targurl="{{url('/').'/'.get_page_url_by_id(6)}}" class="nav-item nav-link @if($i == 1){{'active'}}@endif" id="bag{{$catpro->mid}}-tab" data-toggle="tab" href="#bag{{$catpro->mid}}" role="tab" aria-controls="bag{{$catpro->mid}}" aria-selected="true">{{$cname}}</a>          
		   @endforeach                                    
          </div>
        </nav>
        <div class="renringbtn-wrap d-md-block d-lg-none">
          <a href="{{url('/').'/'.get_page_url_by_id(6)}}" class="rentingbtn" tabindex="0">Get Renting</a>
        </div>
      </div>

    </div>
</div>
<!-- tab wrapper end -->
@endif
@if(isset($data['brand_product']) && !empty($data['brand_product']))
<div class="shopbrand-wrapper">
    <div class="container">
      <h2 class="offset-lg-5">Shop by brand</h2>
    </div>
    <div class="shopbrandslider">
    @foreach($data['brand_product'] as $bpro) 
        @php        	
            $slug = (isset($bpro->pro_slug))?pro_slug_prefix($bpro->pro_slug):'';
            $name = (isset($bpro->pro_name))?$bpro->pro_name:'';                                     
        @endphp     
      <div class="slider-item">
        <div class="container"> 
          <div class="row align-items-center">
              <div class="col-lg-5 shobrandimage">
                  <div class="brandimage"><img src="{{asset('products/').'/'.$bpro->img}}" alt="Brand Product" /></div>
              </div>
              <div class="col-lg-7 shopbranddetail">
                  <div class="brandshopdetail">
                      <div class="brandinfocontent">
                        {!! $bpro->meta_value !!}
                        <div class="renringbtn-wrap">
                            <a href="{{url('/').'/'.get_page_url_by_id(6)}}" class="rentingbtn" tabindex="0">{{$bpro->btxt}}</a>
                        </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
      </div>      
	@endforeach  
    </div>
</div>
@endif
@if(isset($data['new_prod']) && !empty($data['new_prod']))
<div class="new-aarival-section">
    <div class="container">
        <h2>NEW ARRIVAL</h2>
        <div class="row">
    @foreach($data['new_prod'] as $bpro) 
        @php        	
            $slug = (isset($bpro->pro_slug))?pro_slug_prefix($bpro->pro_slug):'';
            $name = (isset($bpro->pro_name))?$bpro->pro_name:'';                                     
        @endphp             
            <div class="col-md-4">
                <div class="arrival-wrap">
                    <div class="arrival-image">
                        <a href="{{url('/').'/'.$slug}}">
                          <img src="{{asset('products/').'/'.$bpro->img}}" alt="{{$name}}" />
                        </a>
                    </div>
                    <div class="arrival-info">
                        <h4><a class="uppr" href="{{url('/').'/'.$slug}}">{{$name}}</a></h4>
                        @if(!empty($bpro->pro_sale_price))
                        	<div class="price">Rent Price:<span class="line-through"><i class="fa fa-inr" aria-hidden="true"></i> {{$bpro->pro_price}}</span>&nbsp;<span><i class="fa fa-inr" aria-hidden="true"></i> {{$bpro->pro_sale_price}}</span></div>
                        @else
                            <div class="price">Rent Price:<span><i class="fa fa-inr" aria-hidden="true"></i> {{$bpro->pro_price}}</span></div> 
                        @endif
                        <div class="rentow d-md-none"><a href="{{url('/').'/'.$slug}}">Rent Now</a></div>
                    </div>
                </div>
            </div>
     @endforeach                     
        </div>
    </div>
</div>
@endif
@endsection

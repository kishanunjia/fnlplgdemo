@extends('layouts.app')
@section('content')
@php
    $name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
@endphp    
<div class="sitewrapper contactpage">
  <div class="container-fluid">
    <div class="pageheading">
          <h1>{{$name}}</h1>
          <div class="heading-desc">{{$data['page_content']}}</div>
    </div>
    <div class="contcatdetail">
        <div class="row">
             <div class="col-md-7 order-md-1">
          @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
          @endif             
              <div class="contcatform">
                    <h2>EMAIL US</h2>
                    <form name="contact_us_submit" id="contact_us_submit" class="row" method="post" action="{{route('contact_us_submit')}}">
                    @csrf 
                        <div class="col-sm-6 form-group">
                            <input type="text" class="form-control" name="fname" placeholder="First Name" />
                        </div>
                        <div class="col-sm-6 form-group">
                            <input type="text" class="form-control" name="lname" placeholder="Last Name" />
                        </div>
                        <div class="col-sm-12 form-group">
                            <input type="email" class="form-control" name="email" placeholder="E-mail" />
                        </div>
                        <div class="col-sm-12 form-group">
                            <input type="text" class="form-control"  name="subject" placeholder="Subject" />
                        </div>
                        <div class="col-sm-12 form-group mb-30">
                            <textarea class="form-control" name="message" placeholder="Start typing here...." ></textarea>
                        </div>
                        <div class="col-sm-12 checkbox-row mb-30">
                            <label class="cstm-checkbox">
                              I have read and accepted the <a href="{{url('/').'/'.get_page_url_by_id(5)}}">privacy policy</a>
                              <input name="provacy_policy" type="checkbox">
                              <span class="checkmark"></span>
                            </label> 
                        </div>
                        <div class="col-sm-12 form-group subbtn mb-0">
                            <input type="submit" class="submitbtn" value="Send" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="contcatadress">
                    <h2>Get in touch</h2>
                    @php
                      $site_phone = get_option('site_phone');
                      $site_phone_trim = str_replace(' ', '', get_option('site_phone'));
                      $site_email = get_option('site_email');
                      $store_address = get_option('store_address');
                    @endphp
                    @if(!empty($site_phone))
                    <div class="cntc-number">
                        <a href="tel:{{$site_phone_trim}}">
                          <span class="phoneicon">
                              <svg version="1.1"  fill="#E78F85" id="phoneicn" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                   width="45.897px" height="45.896px" viewBox="0 0 45.897 45.896" enable-background="new 0 0 45.897 45.896" xml:space="preserve">
                                <path d="M35.042,45.896c-1.318-0.064-2.343-0.171-3.353-0.439c-1.183-0.314-2.339-0.697-3.479-1.144
                                  c-0.768-0.298-1.563-0.534-2.323-0.849c-1.098-0.452-2.195-0.912-3.262-1.434c-2.398-1.17-4.532-2.744-6.585-4.433
                                  c-1.739-1.431-3.364-2.979-4.928-4.597c-1.445-1.494-2.811-3.057-4.069-4.713c-1.063-1.398-2.066-2.841-2.881-4.399
                                  c-0.517-0.988-0.975-2.01-1.409-3.038c-0.385-0.915-0.698-1.86-1.044-2.791c-0.287-0.774-0.595-1.54-0.855-2.322
                                  c-0.2-0.604-0.338-1.228-0.506-1.842c-0.316-1.149-0.396-2.326-0.32-3.508C0.07,9.71,0.199,9.032,0.333,8.363
                                  C0.52,7.436,0.87,6.558,1.281,5.708c0.664-1.377,1.454-2.674,2.517-3.786c0.583-0.609,1.287-1.029,2.11-1.235
                                  c0.871-0.215,1.735-0.464,2.617-0.62c0.539-0.094,1.104-0.071,1.654-0.035c0.196,0.014,0.43,0.185,0.557,0.353
                                  c0.333,0.438,0.64,0.9,0.914,1.378c0.492,0.855,0.95,1.73,1.426,2.596c0.428,0.78,0.844,1.567,1.298,2.331
                                  c0.501,0.842,1.049,1.656,1.561,2.493c0.232,0.38,0.452,0.774,0.634,1.18c0.272,0.606,0.093,1.162-0.285,1.662
                                  c-0.584,0.773-1.303,1.415-2.046,2.029c-0.818,0.675-1.643,1.343-2.431,2.05c-0.328,0.296-0.586,0.676-0.847,1.037
                                  c-0.259,0.359-0.172,0.756-0.049,1.145c0.246,0.772,0.705,1.431,1.114,2.116c0.549,0.92,1.086,1.85,1.673,2.745
                                  c1.407,2.149,3.048,4.106,4.944,5.847c1.186,1.088,2.434,2.099,3.786,2.976c1.03,0.664,2.088,1.289,3.137,1.928
                                  c0.415,0.254,0.828,0.516,1.261,0.739c0.31,0.158,0.643,0.284,0.978,0.384c0.436,0.128,0.832,0,1.191-0.268
                                  c0.756-0.562,1.354-1.278,1.935-2.006c0.765-0.955,1.495-1.938,2.41-2.762c0.321-0.288,0.654-0.557,1.062-0.718
                                  c0.361-0.143,0.73-0.11,1.089,0.018c0.634,0.223,1.155,0.641,1.712,0.996c0.719,0.457,1.44,0.91,2.18,1.331
                                  c1.27,0.724,2.552,1.422,3.831,2.13c0.511,0.283,1.03,0.553,1.534,0.85c0.262,0.153,0.504,0.343,0.742,0.534
                                  c0.268,0.215,0.39,0.505,0.402,0.854c0.023,0.662-0.047,1.313-0.201,1.957c-0.133,0.563-0.254,1.13-0.393,1.691
                                  c-0.314,1.268-1.014,2.273-2.055,3.062c-1.089,0.824-2.242,1.527-3.49,2.083c-0.842,0.373-1.706,0.682-2.607,0.854
                                  C36.363,45.773,35.562,45.831,35.042,45.896"/>
                                </svg>
                          </span>
                          {{$site_phone}}
                        </a>
                    </div>
                    @endif
                    @if(!empty($site_email))
                    <div class="cntc-number">
                        <a href="mailto:{{$site_email}}">
                          <span class="phoneicon">
                              <svg fill="#E78F85" version="1.1" id="emailicn" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                 width="45.896px" height="45.896px" viewBox="0 0 45.896 45.896" enable-background="new 0 0 45.896 45.896" xml:space="preserve">
                                  <path d="M44.14,8.425H1.777l21.182,17.447L44.379,8.473C44.301,8.45,44.221,8.434,44.14,8.425z"/>
                                  <path d="M23.987,29.241c-0.601,0.491-1.464,0.491-2.064,0L0.147,11.302v28.081c0,0.899,0.729,1.629,1.629,1.629
                                    H44.14c0.899,0,1.629-0.729,1.629-1.629v-27.84L23.987,29.241z"/>
                              </svg>
                          </span>
                          {{$site_email}}
                        </a>
                    </div>
                    @endif
                    @if(!empty($store_address))
                    <div class="cntc-number">
                          <span class="phoneicon">
                              <svg version="1.1" fill="#E78F85" id="pinicn" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                       width="45.896px" height="45.896px" viewBox="0 0 45.896 45.896" enable-background="new 0 0 45.896 45.896" xml:space="preserve">
                                    <path  d="M22.895,0.1C13.509,0.1,5.87,7.792,5.87,17.248c0,13.437,15.425,27.309,16.081,27.892
                                      c0.271,0.242,0.608,0.361,0.944,0.361c0.336,0,0.673-0.119,0.943-0.359c0.657-0.585,16.081-14.457,16.081-27.894
                                      C39.919,7.792,32.281,0.1,22.895,0.1z M22.895,26.583c-5.215,0-9.458-4.243-9.458-9.458s4.243-9.458,9.458-9.458
                                      c5.215,0,9.458,4.244,9.458,9.458S28.111,26.583,22.895,26.583z"/>
                                    </svg>

                          </span>
                          {!! $store_address !!}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
@endsection

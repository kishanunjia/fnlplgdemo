@extends('layouts.app')

@section('content')
@php
    $hasRegErr=false;
    $regi = old('regi');
    if($regi){
        $hasRegErr=true;
    }                        
@endphp
<div class="sitewrapper loginregister">
    <div class="container">
          <div class="loginbx">

              <div class="lgn-regtab-inner">
                    <h4>Forgot Password</h4>
                    <div class="lgn-reg-form">
                        <form method="POST" action="{{ route('password.update') }}">
                            @csrf
                           
                            <div class="form-group">
                                <label>{{ __('E-Mail Address') }}</label>
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror                                   
                            </div>
                            <div class="form-group">
                                <label>{{ __('Password') }}</label>
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror                                   
                            </div>
                            <div class="form-group">
                              <label>{{ __('Confirm Password') }}</label>
                              <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                            <div class="form-group loginbtm mb-0">
                                <input type="submit" class="form-submit" value="Reset Password" />                                
                            </div>
                        </form>
                    </div>
                </div>  

          </div>
    </div>
</div>
@if($hasRegErr)
<script>
jQuery(document).ready(function(){
	jQuery('.reg-tab').trigger('click');	
});
</script>
@endif
@endsection

@extends('layouts.app')
@section('content')
    @php
    	$name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
    @endphp 
<div class="sitewrapper summarypage pb-0">
    <div class="container">
        <div class="order-stap-wrap">
            <div class="order-stapcontent">
                 <a href="{{url('/').'/'.get_page_url_by_id(8)}}">SHIPPING/BILLING INFO</a>
                <a href="{{url('/').'/'.get_page_url_by_id(9)}}">PAYMENT METHORD</a>
                <a href="javascript:void(0);" class="active">SUMMERY</a>
            </div>
        </div>
        @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
        @endif
          @php 
              $errormsg = session()->get('error');              
          @endphp                  
        @if (!empty($errormsg))
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
               {{$errormsg}} 
             </div>
        @endif          
       <div class="smry-minicntr">
          <div class="pageheading mobilebackarrow">
              <h1>{{$name}}</h1>
              <div class="mobilebackbtn">
                  <a href="{{url('/').'/'.get_page_url_by_id(9)}}">
                    <svg version="1.1" stroke="#414042" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                       width="71.023px" height="32.716px" viewBox="0 0 71.023 32.716" enable-background="new 0 0 71.023 32.716" xml:space="preserve">
                      <line fill="none"  stroke-width="1.99" stroke-miterlimit="10" x1="71.023" y1="16.239" x2="0" y2="16.239"/>
                      <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.62" y1="31.885" x2="0.617" y2="16.102"/>
                      <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.963" y1="0.837" x2="0.841" y2="16.34"/>
                    </svg>
                  </a>
              </div>
          </div>
          <div class="summarydetailwrap mt-20">
            <div class="row">
                <div class="col-md-5 offset-md-2 order-md-1 smr-del">
                  <div class="summary-delivery">
                      
                      
                      @if(!empty($data['cart_products']))
                      <h4>DELIVERY  </h4>
                      <div class="snr-imgwrap">
                          <div class="smr-bg-cnt">{{$data['total_cart_products']}} Bag</div>                      
                      @foreach($data['cart_products'] as $prod)
                      @php        	
                        $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
                        $name = (isset($prod->pro_name))?$prod->pro_name:''; 
                        $alldates = getDatesFromRange($prod->start_date,$prod->end_date); 
                        $totaldays = count($alldates);
                        $logprice=$prod->pro_price;
                        if(!empty($prod->pro_sale_price)){
                            $logprice=$prod->pro_sale_price;
                        }                                   
                      @endphp                       

                          
                          <div class="smr-img">
                              <img src="{{asset('products/').'/'.$prod->pro_cart_image}}" alt="{{$name}}" />
                              <div class="bags-detail">
                                  <h5><a href="{{url('/').'/'.$slug}}"><strong>{{get_brand_name_by_id($prod->pro_brand)}}</strong> - {{$name}}</a></h5>
                                  @if(!empty($prod->pro_sale_price))
                                  <div class="bagrent">RENTAL  PRICE: <span class="line-through">RS. {{$prod->pro_price}}</span> <span>RS. {{$prod->pro_sale_price}}</span></div>
                                  @else
                                  <div class="bagrent">RENTAL  PRICE: RS. {{$prod->pro_price}}</div>
                                  @endif                                  
                                  <div class="cartdepoprice">{{uppercasetext('Delivery Date:')}} {{front_date_formate($prod->start_date)}}</div>
                                  <div class="cartdepoprice">{{uppercasetext('Return Date:')}} {{front_date_formate($prod->end_date)}}</div>
                                  <div class="marketvalue">MARKET  VALUE: RS. {{$prod->pro_market_value}}</div>
                                  <div class="cartrentprice">TOTAL PRICE: RS. {{$logprice*$totaldays}}</div>
                              </div>
                          </div>
                          
                                             
					  @endforeach
                      </div>
                      @endif 	

                  </div>
                </div>
                <div class="col-md-5">
                    <div class="summary-detail">
                        <div class="summarybx-wrap smr-shpp">
                            <div class="smrbx-title">
                                <h4>SHIPPING</h4>
                                
                            </div>
                            <p>Standard Home  Delivery - <a href="">FREE</a></p>
                            
                        </div>
                        @if(!empty($data['shipadd']))
                        @php
                        	$address2 = (!empty($data['shipadd']->address2))?'<br />'.$data['shipadd']->address2:'';
                            
                        @endphp
                        <div class="summarybx-wrap smr-addr">
                            <div class="smrbx-title">
                                <h4>ADDRESS</h4>
                                <a href="{{url('/').'/'.get_page_url_by_id(8)}}" class="smreditbtn">Edit</a>
                            </div>
                            <p>{{$data['shipadd']->address1}} {!! $address2 !!}</p>
                            <p>{{$data['shipadd']->post_code}}</p>
                            <p>{{$data['shipadd']->city}}</p>
                            <p>{{$data['shipadd']->state}}</p>
                        </div>
                        @endif
                        <div class="summarybx-wrap smr-ptm">
                            <div class="smrbx-title">
                                <h4>PAYMENT</h4>
                                <a href="{{url('/').'/'.get_page_url_by_id(9)}}" class="smreditbtn">Edit</a>
                            </div>
                            <div class="payment-type">
                                <div class="ptm-tye">{{$data['cart_single']->paymentmethod}}</div>
                                <span>{{get_payment_method_full_name($data['cart_single']->paymentmethod)}}</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
          </div>
        </div>
    
                                  
    </div>
</div>
<form method="POST" name="create_order" id="create_order" action="{{route('create_order')}}">
@csrf
<input type="hidden" name="crorder" value="create" />
</form>
@php
	$carttotal=get_cart_total(true);
@endphp
<div class="cartbottom">
    <div class="coupon-error"></div>
    @php
    $msg = '';
    $remurl=url('/').'/remove-coupon/'.get_cart_id();    
    if(!empty($data['discount'])){
    	$msg = 'Coupon Code "'.$data['coupon_code'].'" applied succesfully. Your Coupon Discount Is '.$carttotal['dicount'].' RS.';        
        $msg.= '<a class="remove-coupon" href="'.$remurl.'">Remove Coupon</a>';
    }
    @endphp
    <div class="coupon-success">{!!$msg!!}</div>
    
    <form method="POST" name="coupon_apply" id="coupon_apply" action="{{route('apply_coupon')}}">
    @csrf
    <div class="applycoupon">
        <div class="container">
            <input type="text" onkeyup="couponApply()" name="coupon_code" id="coupon_code" class="applycpninput" placeholder="Apply Coupon Code" />
        </div> 
    </div>
    <input type="hidden" name="crtid" id="crtid" value="{{get_cart_id()}}" />    
    </form>
    <div class="carttotalwrap">
        <div class="container">
          <div class="row">
              <div class="col-lg-3">
                  <div class="cartbackbtn"><a href="{{url('/').'/'.get_page_url_by_id(9)}}">GO BACK</a></div>
              </div>
              <div class="col-lg-6">
                  <div class="carttotal">                                            
                      <div class="totalamount">TOTAL: RS  {{$carttotal['total']}}</div>
                      <div class="totaldeposit">DEPOSIT: RS {{get_cart_deposit_total()}}</div>
                  </div>
              </div>
              <div class="col-lg-3">                  
                  <div class="cntnubtn"><a onclick="event.preventDefault();document.getElementById('create_order').submit();" href="javascript:void(0);">Authorise payment</a></div>
              </div>
          </div>
        </div>
    </div>
    <div class="cartinfotext">{{get_option('deposit_notice')}}</div>
</div>
<script>
jQuery(document).ready(function () {
  jQuery(".number-only").keypress(function (e) {
     if(e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)){
         return false;
     }
   });
});
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == ''){
	  obj.addClass('error_in_field_bottom');
	  return false;	
	}else{
	  obj.removeClass('error_in_field_bottom');
	  return true;		
	}
}
function couponApply(){	
	var coupon_code = jQuery('#coupon_code').val();
	if(coupon_code.length > 2){
		var formdata = new FormData(jQuery('#coupon_apply')[0]);							
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('screen','edit');
		
		var suscoup = jQuery('.coupon-success').html();
		if(suscoup == ''){
			jQuery.ajaxSetup({
				headers:{
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('apply_coupon')}}",
				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){			  
				  if(res.status == 'Y'){
					 jQuery('.coupon-error').html('');
					 jQuery('.coupon-success').html('Coupon Code "'+res.coupon_code+'" applied succesfully. Your Coupon Discount Is '+res.discount+' RS. <a class="remove-coupon" href="{{$remurl}}">Remove Coupon</a>'); 			  
					 jQuery('.totalamount').html('TOTAL: RS  '+res.total);
				  }else{				  
					 jQuery('.coupon-error').html(''+res.error);
				  }			  				
				}
			});
				
		}
			
	}
}
</script>
@endsection

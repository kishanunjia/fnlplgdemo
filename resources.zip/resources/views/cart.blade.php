@extends('layouts.app')

@section('content')

<div class="sitewrapper cartpage">
    <div class="container-fluid">
      @php 
          $errormsg = session()->get('error');
          $success  = session()->get('success');              
      @endphp 
      @if(!empty($errormsg))
         <div class="infotex alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>         
         {{$errormsg}}
         </div>
      @endif
      @if(!empty($success))
         <div class="infotex alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>         
           {{$success}}
         </div>
      @endif     
        <div class="pageheading">
            @php
             $name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
            @endphp            
            <h1>{{$name}}</h1>
            <div class="mobilebackbtn">
                <a href="{{url('/').'/'.get_page_url_by_id(6)}}">
                  <svg version="1.1" stroke="#414042" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                     width="71.023px" height="32.716px" viewBox="0 0 71.023 32.716" enable-background="new 0 0 71.023 32.716" xml:space="preserve">
                    <line fill="none"  stroke-width="1.99" stroke-miterlimit="10" x1="71.023" y1="16.239" x2="0" y2="16.239"/>
                    <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.62" y1="31.885" x2="0.617" y2="16.102"/>
                    <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.963" y1="0.837" x2="0.841" y2="16.34"/>
                  </svg>
                </a>
            </div>
        </div>
        <div class="mobilecartcount">
            BAG {{$data['total_cart_products']}}
        </div>
        <div class="row cartlisting">
 		   @if($data['total_cart_products'] == 0)	
            <div class="col-lg-12">
              <div class="infotex alert alert-danger gc-empty-cart">
                  <h4 class="alert-heading">Empty Cart!</h4>
                  <p>Aww yeah, Please click below Get Renting button for more shopping.</p>
                  <hr>
                  <div class="cntnubtn"><a href="{{url('/').'/'.get_page_url_by_id(6)}}">Get Renting</a></div>
             
             </div> 
           	</div>
           @endif 
           @if(!empty($data['cart_products']))              
             @foreach($data['cart_products'] as $prod) 
              @php        	
                $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
                $name = (isset($prod->pro_name))?$prod->pro_name:''; 
                $alldates = getDatesFromRange($prod->start_date,$prod->end_date); 
                $totaldays = count($alldates);
                $logprice=$prod->pro_price;
                if(!empty($prod->pro_sale_price)){
                	$logprice=$prod->pro_sale_price;
                }
                                                   
              @endphp               
             <div class="col-lg-3">
                <div class="cart-item">
                      <div class="cart-image">
                          <a href="{{url('/').'/'.$slug}}"><img src="{{asset('products/').'/'.$prod->pro_cart_image}}" alt="{{$name}}" /></a>
                          <a href="{{url('/').'/remove-product/'.$prod->cpid}}" class="closeicon cartitemclose removecartitem"><img src="/images/close.png" alt="Close Icon" /></a>
                      </div>
                      <div class="cartitem-detail">
                          <h5><a href="{{url('/').'/'.$slug}}"><strong>{{get_brand_name_by_id($prod->pro_brand)}}</strong> - {{$name}}</a></h5>
                          <div class="cartprice">
                              @if(!empty($prod->pro_sale_price))
                                 <div class="cartrentprice">RENTAL PRICE: <span class="line-through">RS. {{$prod->pro_price}}</span>&nbsp;&nbsp;<span>RS. {{$prod->pro_sale_price}}</span></div>
                              @else
                              	 <div class="cartrentprice">RENTAL  PRICE: RS. {{$prod->pro_price}}</div>
                              @endif
                              <div class="cartdepoprice">TOTAL DAYS: {{$totaldays}} </div>
                                  <div class="cartdepoprice">{{uppercasetext('Delivery Date:')}} {{front_date_formate($prod->start_date)}}</div>
                                  <div class="cartdepoprice">{{uppercasetext('Return Date:')}} {{front_date_formate($prod->end_date)}}</div>
                              <div class="cartdepoprice">DEPOSIT: RS. {{$prod->pro_deposit}}</div>
                              <div class="cartrentprice">TOTAL PRICE: RS. {{$logprice*$totaldays}}</div>
                          </div>
                    </div>
                    @php
                     $remv=url('/').'/remove-product/'.$prod->cpid;
                    @endphp
                    <!--<div onclick="window.location.href='{{$remv}}'" class="closeicon cartitemclose">
                        Delete
                    </div>-->
                </div>
            </div>
            @endforeach
           @else           
                     
           @endif                         
        </div>
    </div>
</div>
@php
	$carttotal=get_cart_total(true);
@endphp
<div class="cartbottom">
    <div class="coupon-error"></div>
    @php
    $msg = '';
    $remurl=url('/').'/remove-coupon/'.$data['crtid'];    
    if(!empty($data['discount'])){
    	$msg = 'Coupon Code "'.$data['coupon_code'].'" applied succesfully. Your Coupon Discount Is '.$carttotal['dicount'].' RS.';        
        $msg.= '<a class="remove-coupon" href="'.$remurl.'">Remove Coupon</a>';
    }
    @endphp
    <div class="coupon-success">{!!$msg!!}</div>
    
    <form method="POST" name="coupon_apply" id="coupon_apply" action="{{route('apply_coupon')}}">
    @csrf
    <div class="applycoupon">
        <div class="container">
            <input type="text" onkeyup="couponApply()" name="coupon_code" id="coupon_code" class="applycpninput" placeholder="Apply Coupon Code" />
        </div> 
    </div>
    <input type="hidden" name="crtid" id="crtid" value="{{get_cart_id()}}" />    
    </form>
    <div class="carttotalwrap">
        <div class="container">
          <div class="row">
              <div class="col-lg-3">
                  <div class="cartbackbtn"><a href="{{url('/').'/'.get_page_url_by_id(6)}}">GO BACK</a></div>
              </div>
              <div class="col-lg-6">
                  <div class="carttotal">

                      <!--<div class="totaldeposit">COUPON DISCOUNT: RS 15 (15%)</div>-->                      
                      <div class="totalamount">TOTAL: RS  {{$carttotal['total']}}</div>
                      <div class="totaldeposit">DEPOSIT: RS {{get_cart_deposit_total()}}</div>
                  </div>
              </div>
              <div class="col-lg-3">
                  <div class="cntnubtn"><a href="{{url('/').'/'.get_page_url_by_id(8)}}">CONTINUE</a></div>
              </div>
          </div>
        </div>
    </div>
    <div class="cartinfotext">{{get_option('deposit_notice')}}</div>
</div>
@if($data['total_cart_products'] != 0)
<script>
function couponApply(){	
	var coupon_code = jQuery('#coupon_code').val();
	if(coupon_code.length > 2){
		var formdata = new FormData(jQuery('#coupon_apply')[0]);							
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('screen','edit');
		
		var suscoup = jQuery('.coupon-success').html();
		if(suscoup == ''){
			jQuery.ajaxSetup({
				headers:{
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('apply_coupon')}}",
				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){			  
				  if(res.status == 'Y'){
					 jQuery('.coupon-error').html('');
					 jQuery('.coupon-success').html('Coupon Code "'+res.coupon_code+'" applied succesfully. Your Coupon Discount Is '+res.discount+' RS. <a class="remove-coupon" href="{{$remurl}}">Remove Coupon</a>'); 			  
					 jQuery('.totalamount').html('TOTAL: RS  '+res.total);
				  }else{				  
					 jQuery('.coupon-error').html(''+res.error);
				  }			  				
				}
			});
				
		}
			
	}
}
</script>
@endif
@endsection

@extends('layouts.app')
@section('content')

<div class="sitewrapper paymentpage pb-0">
    <div class="container">
        <div class="order-stap-wrap">
            <div class="order-stapcontent">
                 <a href="{{url('/').'/'.get_page_url_by_id(8)}}">SHIPPING/BILLING INFO</a>
                <a href="javascript:void(0);" class="active">PAYMENT METHORD</a>
                <a href="javascript:void(0);">SUMMERY</a>
            </div>
        </div>
        <div class="payment-mini">
          <div class="pageheading mobilebackarrow">
              <h1>PAYMENT METHORD</h1>
              <div class="mobilebackbtn">
                  <a href="{{url('/').'/'.get_page_url_by_id(8)}}">
                    <svg version="1.1" stroke="#414042" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                       width="71.023px" height="32.716px" viewBox="0 0 71.023 32.716" enable-background="new 0 0 71.023 32.716" xml:space="preserve">
                      <line fill="none"  stroke-width="1.99" stroke-miterlimit="10" x1="71.023" y1="16.239" x2="0" y2="16.239"/>
                      <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.62" y1="31.885" x2="0.617" y2="16.102"/>
                      <line fill="none" stroke-width="1.99" stroke-miterlimit="10" x1="24.963" y1="0.837" x2="0.841" y2="16.34"/>
                    </svg>
                  </a>
              </div>
          </div>
          @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
          @endif           
          <div class="payment-card-listing mt-20">
		  <form name="paymentmethod" id="paymentmethodfrm" method="POST" action="{{route('add_paymentmethod')}}">
          @csrf 
            @php
                $visacard = get_option('visacard');
                $mastercard = get_option('mastercard');
                $cash = get_option('cash');
            @endphp	                     
            <div class="row">
                @if(!empty($visacard))
                <div class="col-6 col-sm-4 col-md-3">
                    <div class="card-box cardradio">
                      <input type="radio" id="visacard" value="visacard" name="paymentmethod">
                      <label for="visacard">

                        <span class="card-image">
                            <img src="{{asset('/images/visa-img.png')}}" alt="Visa" />
                        </span>
                        <span class="cardstitle">VISA</span>
                      </label>
                    </div>
                </div>
                @endif
                @if(!empty($mastercard))
                <div class="col-6 col-sm-4 col-md-3">
                    <div class="card-box cardradio">
                        <input type="radio" id="mastercard" value="mastercard" name="paymentmethod">
                        <label for="mastercard">
                          <span class="card-image">
                              <img src="{{asset('/images/master-card-img.png')}}" alt="Master Card" />
                          </span>
                          <span class="cardstitle">MasterCard</span>
                        </label>
                    </div>
                </div>
                @endif
                @if(!empty($cash))
                <div class="col-6 col-sm-4 col-md-3">
                    <div class="card-box cardradio">
                        <input type="radio" id="cash" checked="checked" value="cash" name="paymentmethod">
                        <label for="cash">
                          <span class="card-image">
                              <img src="{{asset('/images/cash-img.png')}}" alt="Cash On Delivery" />
                          </span>
                          <span class="cardstitle">Cash on delivery</span>
                        </label>
                    </div>
                </div>
                @endif
            </div>
            
          </form>  
          </div>
        </div>
    </div>
</div>

@php
	$carttotal=get_cart_total(true);
@endphp
<div class="cartbottom">
    <div class="coupon-error"></div>
    @php
    $msg = '';
    $remurl=url('/').'/remove-coupon/'.get_cart_id();    
    if(!empty($data['discount'])){
    	$msg = 'Coupon Code "'.$data['coupon_code'].'" applied succesfully. Your Coupon Discount Is '.$carttotal['dicount'].' RS.';        
        $msg.= '<a class="remove-coupon" href="'.$remurl.'">Remove Coupon</a>';
    }
    @endphp
    <div class="coupon-success">{!!$msg!!}</div>
    
    <form method="POST" name="coupon_apply" id="coupon_apply" action="{{route('apply_coupon')}}">
    @csrf
    <div class="applycoupon">
        <div class="container">
            <input type="text" onkeyup="couponApply()" name="coupon_code" id="coupon_code" class="applycpninput" placeholder="Apply Coupon Code" />
        </div> 
    </div>
    <input type="hidden" name="crtid" id="crtid" value="{{get_cart_id()}}" />    
    </form>
    <div class="carttotalwrap">
        <div class="container">
          <div class="row">
              <div class="col-lg-3">
                  <div class="cartbackbtn"><a href="{{url('/').'/'.get_page_url_by_id(8)}}">GO BACK</a></div>
              </div>
              <div class="col-lg-6">
                  <div class="carttotal">

                      <!--<div class="totaldeposit">COUPON DISCOUNT: RS 15 (15%)</div>-->                      
                      <div class="totalamount">TOTAL: RS  {{$carttotal['total']}}</div>
                      <div class="totaldeposit">DEPOSIT: RS {{get_cart_deposit_total()}}</div>
                  </div>
              </div>
              <div class="col-lg-3">                  
                  <div class="cntnubtn"><a onclick="event.preventDefault();
                                         document.getElementById('paymentmethodfrm').submit();" href="javascript:void(0);">CONTINUE</a></div>
              </div>
          </div>
        </div>
    </div>
    <div class="cartinfotext">{{get_option('deposit_notice')}}</div>
</div>
<script>
jQuery(document).ready(function () {
  jQuery(".number-only").keypress(function (e) {
     if(e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)){
         return false;
     }
   });
});
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == ''){
	  obj.addClass('error_in_field_bottom');
	  return false;	
	}else{
	  obj.removeClass('error_in_field_bottom');
	  return true;		
	}
}
function couponApply(){	
	var coupon_code = jQuery('#coupon_code').val();
	if(coupon_code.length > 2){
		var formdata = new FormData(jQuery('#coupon_apply')[0]);							
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('screen','edit');
		
		var suscoup = jQuery('.coupon-success').html();
		if(suscoup == ''){
			jQuery.ajaxSetup({
				headers:{
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('apply_coupon')}}",
				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){			  
				  if(res.status == 'Y'){
					 jQuery('.coupon-error').html('');
					 jQuery('.coupon-success').html('Coupon Code "'+res.coupon_code+'" applied succesfully. Your Coupon Discount Is '+res.discount+' RS. <a class="remove-coupon" href="{{$remurl}}">Remove Coupon</a>'); 			  
					 jQuery('.totalamount').html('TOTAL: RS  '+res.total);
				  }else{				  
					 jQuery('.coupon-error').html(''+res.error);
				  }			  				
				}
			});
				
		}
			
	}
}
</script>
@endsection

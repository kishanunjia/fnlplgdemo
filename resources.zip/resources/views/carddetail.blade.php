@extends('layouts.app')
@section('content')
    @php
    	$name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
    @endphp 
<div class="sitewrapper paymentpage carddetail pb-0">
    <div class="container">
        <div class="order-stap-wrap">
            <div class="order-stapcontent">
                 <a href="{{url('/').'/'.get_page_url_by_id(8)}}">SHIPPING/BILLING INFO</a>
                <a href="javascript:void(0);" class="active">PAYMENT METHORD</a>
                <a href="javascript:void(0);">SUMMERY</a>
            </div>
        </div>
          @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
          @endif         
          <div class="pageheading">
              <h1>{{$name}}</h1>
              {!! $data['page_content'] !!}
          </div>
    <form method="POST" name="card_detail_save" id="card_detail_save" action="{{route('card_detail_save')}}">
    	@csrf          
        <div class="payment-card-listing mt-20">
            <div class="row">
                <div class="col-6 col-sm-4 col-md-3">
                    <div class="card-box cardradio">
                      <input type="radio" @if($data['cart_single']->card_type == 'visacard') checked @endif id="visacard" value="visacard" name="card_type">
                      <label for="visacard">
                        <span class="card-image">
                            <img src="{{asset('/images/visa-img.png')}}" alt="Visa" />
                        </span>
                        <span class="cardstitle">VISA</span>
                      </label>
                    </div>
                </div>
                <div class="col-6 col-sm-4 col-md-3">
                    <div class="card-box cardradio">
                        <input @if($data['cart_single']->card_type == 'mastercard') checked @endif type="radio" id="mastercard" value="mastercard" name="card_type">
                        <label for="mastercard">
                          <span class="card-image">
                              <img src="{{asset('/images/master-card-img.png')}}" alt="Master Card" />
                          </span>
                          <span class="cardstitle">MasterCard</span>
                        </label>
                    </div>
                </div>
            </div>
          </div>
          <div class="card-detail">              
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <input type="text" name="card_number" id="card_number" value="{{$data['cart_single']->card_number}}" class="form-control" placeholder="Card Number">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-sm-6 form-group">
                      <select name="card_exp_month" id="card_exp_month" class="form-control">
                        <option value="">Expiration Month</option>
                        <option @if($data['cart_single']->card_exp_month == '01') selected @endif value="01">January</option>
                        <option  @if($data['cart_single']->card_exp_month == '02') selected @endif value="02">February</option>
                        <option  @if($data['cart_single']->card_exp_month == '03') selected @endif value="03">March</option>
                        <option  @if($data['cart_single']->card_exp_month == '04') selected @endif value="04">April</option>
                        <option  @if($data['cart_single']->card_exp_month == '05') selected @endif value="05">May</option>
                        <option  @if($data['cart_single']->card_exp_month == '06') selected @endif value="06">June</option>
                        <option  @if($data['cart_single']->card_exp_month == '07') selected @endif value="07">July</option>
                        <option  @if($data['cart_single']->card_exp_month == '08') selected @endif value="08">August</option>
                        <option  @if($data['cart_single']->card_exp_month == '09') selected @endif value="09">September</option>
                        <option  @if($data['cart_single']->card_exp_month == '10') selected @endif value="10">October</option>
                        <option  @if($data['cart_single']->card_exp_month == '11') selected @endif value="11">November</option>
                        <option  @if($data['cart_single']->card_exp_month == '12') selected @endif value="12">December</option>
                      </select>
                            </div>
                            <div class="col-sm-6 form-group">
                                <select name="card_exp_year"id="card_exp_year" class="form-control">
                                    <option value="">Expiration Year</option>
                                   @php
                                     $start = 2020;
                                     $end = 2060;
                                   @endphp
                                   @for($i=$start;$i<=$end;$i++) 
                                    <option @if($data['cart_single']->card_exp_year == $i) selected @endif value="{{$i}}">{{$i}}</option>
                                   @endfor 
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <input type="text" name="card_holder" value="{{$data['cart_single']->card_holder}}" id="card_holder" class="form-control" placeholder="Card Holder">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <input type="text" name="card_cvv" id="card_cvv" value="{{$data['cart_single']->card_cvv}}" class="form-control number-only" placeholder="CVV Security Code">
                        </div>
                    </div>
                </div>              
          </div>
    </form>                              
    </div>
</div>

@php
	$carttotal=get_cart_total(true);
@endphp
<div class="cartbottom">
    <div class="coupon-error"></div>
    @php
    $msg = '';
    $remurl=url('/').'/remove-coupon/'.get_cart_id();    
    if(!empty($data['discount'])){
    	$msg = 'Coupon Code "'.$data['coupon_code'].'" applied succesfully. Your Coupon Discount Is '.$carttotal['dicount'].' RS.';        
        $msg.= '<a class="remove-coupon" href="'.$remurl.'">Remove Coupon</a>';
    }
    @endphp
    <div class="coupon-success">{!!$msg!!}</div>
    
    <form method="POST" name="coupon_apply" id="coupon_apply" action="{{route('apply_coupon')}}">
    @csrf
    <div class="applycoupon">
        <div class="container">
            <input type="text" onkeyup="couponApply()" name="coupon_code" id="coupon_code" class="applycpninput" placeholder="Apply Coupon Code" />
        </div> 
    </div>
    <input type="hidden" name="crtid" id="crtid" value="{{get_cart_id()}}" />    
    </form>
    <div class="carttotalwrap">
        <div class="container">
          <div class="row">
              <div class="col-lg-3">
                  <div class="cartbackbtn"><a href="{{url('/').'/'.get_page_url_by_id(9)}}">GO BACK</a></div>
              </div>
              <div class="col-lg-6">
                  <div class="carttotal">
                      <!--<div class="totaldeposit">COUPON DISCOUNT: RS 15 (15%)</div>-->                      
                      <div class="totalamount">TOTAL: RS  {{$carttotal['total']}}</div>
                      <div class="totaldeposit">DEPOSIT: RS {{get_cart_deposit_total()}}</div>
                  </div>
              </div>
              <div class="col-lg-3">                  
                  <div class="cntnubtn"><a onclick="event.preventDefault();document.getElementById('card_detail_save').submit();" href="javascript:void(0);">CONTINUE</a></div>
              </div>
          </div>
        </div>
    </div>
    <div class="cartinfotext">{{get_option('deposit_notice')}}</div>
</div>
<script>
jQuery(document).ready(function () {
  jQuery(".number-only").keypress(function (e) {
     if(e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)){
         return false;
     }
   });
});
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == ''){
	  obj.addClass('error_in_field_bottom');
	  return false;	
	}else{
	  obj.removeClass('error_in_field_bottom');
	  return true;		
	}
}
function couponApply(){	
	var coupon_code = jQuery('#coupon_code').val();
	if(coupon_code.length > 2){
		var formdata = new FormData(jQuery('#coupon_apply')[0]);							
		var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');			
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('screen','edit');
		
		var suscoup = jQuery('.coupon-success').html();
		if(suscoup == ''){
			jQuery.ajaxSetup({
				headers:{
					'X-CSRF-TOKEN': CSRF_TOKEN
				}
			});					
			jQuery.ajax({
				type: "POST",
				url:  "{{route('apply_coupon')}}",
				data: formdata,
				processData: false, 
				contentType: false,
				cache: false,
				success: function(res){			  
				  if(res.status == 'Y'){
					 jQuery('.coupon-error').html('');
					 jQuery('.coupon-success').html('Coupon Code "'+res.coupon_code+'" applied succesfully. Your Coupon Discount Is '+res.discount+' RS. <a class="remove-coupon" href="{{$remurl}}">Remove Coupon</a>'); 			  
					 jQuery('.totalamount').html('TOTAL: RS  '+res.total);
				  }else{				  
					 jQuery('.coupon-error').html(''+res.error);
				  }			  				
				}
			});
				
		}
			
	}
}
</script>
@endsection

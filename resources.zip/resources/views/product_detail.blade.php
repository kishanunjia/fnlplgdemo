@extends('layouts.app')
@section('content')
<div class="sitewrapper singleproduct">
  <div class="container-fluid">
      @php 
          $errormsg = session()->get('error');
          $success  = session()->get('success');              
      @endphp 
      @if(!empty($errormsg))
         <div class="infotex alert alert-danger alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>         
         {{$errormsg}}
         </div>
      @endif
      @if(!empty($success))
         <div class="infotex alert alert-success alert-dismissible fade show">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>         
           Product Successfully added into cart. <div class="addtobagbtn view-cart-btn"><a href="{{url('/').'/'.get_page_url_by_id(7)}}">View Cart</a></div>
         </div>
      @endif   
    <div class="row">
      <div class="col-lg-7">
        <div class="singleproduct-left">
          <div class="singleproductslider-wrap">
            @php
            	$pro_detail_images = $data['product']->pro_detail_images;
            	$pro_detail_images_arr = array(); 
                if(!empty($pro_detail_images)){
                	$pro_detail_images_arr=explode(",",$pro_detail_images);
                }
                $baseurll=URL::to('/');
            @endphp            
            <div class="singalproduct-thumb">
            @if(!empty($pro_detail_images_arr))
              @foreach($pro_detail_images_arr as $prodetimg)
              	<div class="singlepro-thumb-item"><img src="{{$baseurll}}/products/{{$prodetimg}}" alt="{{$data['product']->pro_name}}" /></div>
              @endforeach
            @endif
            </div>
            
            <div class="singalproduct-slider">
            @if(!empty($pro_detail_images_arr))
              @foreach($pro_detail_images_arr as $prodetimg)  
              <div class="siglepro-item"><img src="{{$baseurll}}/products/{{$prodetimg}}" alt="{{$data['product']->pro_name}}" /></div>
              @endforeach
            @endif            
            </div>
            
          </div>
          <div class="prduct-detail">
            <div class="org-price"> ORIGNAL PRICE: Rs.{{$data['product']->pro_market_value}} </div>
            <div class="pro-tab">
              <div class="accordion" id="pro-tabnav">
                @if(!empty($data['product']->pro_description) || !empty($data['product']->pro_size) || !empty($data['product']->pro_material)) 
                <div class="accordion-group">
                  <div class="accordion-heading"> <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#pro-tabnav" href="#prodetail">DETAIL</a> </div>
                  <div id="prodetail" class="accordion-body collapse">
                    <div class="accordion-inner">
                      @if(!empty($data['product']->pro_description))<p><strong>DESCRIPTION:</strong> {{$data['product']->pro_description}}</p>@endif
                      @if(!empty($data['product']->pro_size))<p><strong>SIZE:</strong> {{$data['product']->pro_size}} </p>@endif
                      @if(!empty($data['product']->pro_material))<p><strong>MATERIAL:</strong> {{$data['product']->pro_material}} </p>@endif
                    </div>
                  </div>
                </div>
                @endif
                @if(!empty($data['product']->pro_styling_tips))
                <div class="accordion-group">
                  <div class="accordion-heading"> <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#pro-tabnav" href="#prostyletips">STYLING  TIPS</a> </div>
                  <div id="prostyletips" class="accordion-body collapse">
                    <div class="accordion-inner">{!! $data['product']->pro_styling_tips !!}</div>
                  </div>
                </div>
                @endif
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <form method="POST" name="add_to_cart" id="add_to_cart" action="{{route('add_to_cart')}}">
        @csrf
        <div class="singleproduct-right">
          <div class="pageheading">
            @php
            	$pronm = $data['product']->pro_display_name;
                if(empty($pronm)){
                   $pronm = $data['product']->pro_name;
                }
            @endphp
            <h1>{!! $pronm !!}</h1>
          </div>
          <div class="pro-pricewrap">
            <div class="proprice rntprice"> RENTAL PRICE 
            @if(!empty($data['product']->pro_sale_price))
            	<span class="line-through"><i class="fa fa-inr"></i>{{$data['product']->pro_price}}</span>
                <span><i class="fa fa-inr"></i>{{$data['product']->pro_sale_price}}</span> 
            @else
            	<span><i class="fa fa-inr"></i>{{$data['product']->pro_price}}</span> 
            @endif
           </div>
            <div class="proprice deposit-price"> DEPOSIT <span><i class="fa fa-inr"></i>{{$data['product']->pro_deposit}}</span> </div>
          </div>
          <div class="infotex">{{get_option('deposit_notice')}}</div>
          <div class="select-rentalprive">
            <h4>Rental period</h4>
            @php
            	$first_period  = get_option('first_period');
                $second_period = get_option('second_period');
                $third_period  = get_option('third_period');
            @endphp	            
            <div class="selectrent-price">
              <div class="rnt-customradio">
                <input type="radio" id="twodays" value="{{$first_period}}" name="rntperiod" checked>
                <label for="twodays">{{$first_period}} days</label>
              </div>
              <div class="rnt-customradio">
                <input type="radio" id="sevandays" value="{{$second_period}}" name="rntperiod">
                <label for="sevandays">{{$second_period}} days</label>
              </div>
              <div class="rnt-customradio">
                <input type="radio" id="fifteendays" value="{{$third_period}}" name="rntperiod">
                <label for="fifteendays">{{$third_period}} days</label>
              </div>
            </div>
          </div>
          <div class="delvry-date">
            <h4>Delivery Date</h4>
            <input type="text" autocomplete="off" required="required" name="start_date" id="start_date" class="datetimepicker calender-icon" placeholder="Select Delivery date" />
            <input type="hidden" name="pro_id" id="pro_id" value="{{$data['product']->pro_id}}" />            
          </div>
         
          <div class="addtobagbtn">
             <a href="javascript:void(0);" onclick="add_to_cart_pro();">ADD TO BAG</a>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
  <div class="mobiledetailtabsection"> 
    
    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
     @if(!empty($data['product']->pro_description) || !empty($data['product']->pro_size) || !empty($data['product']->pro_material)) 
      <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#detailtab" role="tab">Detail</a> </li>
     @endif
     @if(!empty($data['product']->pro_styling_tips)) 
     <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#stylingtipstab" role="tab">Styling tips</a> </li>
     @endif
    </ul>
    
    <!-- Tab panes -->
    <div class="tab-content">
      <div class="tab-pane fade show active" id="detailtab" role="tabpanel">
        <div class="detailtab-inner">
          @if(!empty($data['product']->pro_description))<p><strong>DESCRIPTION:</strong> {{$data['product']->pro_description}}</p>@endif
          @if(!empty($data['product']->pro_size))<p><strong>SIZE:</strong> {{$data['product']->pro_size}} </p>@endif
          @if(!empty($data['product']->pro_material))<p><strong>MATERIAL:</strong> {{$data['product']->pro_material}} </p>@endif
        </div>
      </div>
      @if(!empty($data['product']->pro_styling_tips))
      <div class="tab-pane" id="stylingtipstab" role="tabpanel">{!! $data['product']->pro_styling_tips !!}</div>
      @endif
    </div>
  </div>
  @php
  	$i=0;
    $rel_prod = array($data['product']->pro_id);
  @endphp
  @if(isset($data['rel_prod']) && !empty($data['rel_prod']))
  <div class="likebagwrapper">
    <div class="container">
      <h2>{{get_option('related_pro_title')}}</h2>
      <div class="likebagslider">
    @foreach($data['rel_prod'] as $prod)
        @php 
            $rel_prod[] = $prod->pro_id;       	
            $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
            $name = (isset($prod->pro_name))?$prod->pro_name:'';                                     
        @endphp         
        <div class="likebag-slide">
          <div class="likebagbx">
            <div class="likebagimage"> <a href="{{url('/').'/'.$slug}}"><img src="{{asset('products/').'/'.$prod->pro_relpro_img}}" alt="{{$prod->pro_name}}" /></a> </div>
            <div class="likebag-detail">
              <h4><a href="{{url('/').'/'.$slug}}">{{$prod->pro_name}}</a></h4>
              <div class="bagprice"> Rent Price: <span><i class="fa fa-inr"></i>{{$prod->pro_price}}</span> </div>
              <div class="rentow d-md-none"><a href="{{url('/').'/'.$slug}}">Rent Now</a></div>
            </div>
          </div>
        </div>
        @php
        	$i++;
        @endphp        
    @endforeach  
    @php
    	$res = '';
        if($i < 4){
          $limit = 4 - $i; 
          $res = get_extra_prod($rel_prod,$limit);
    @endphp                          
		@if(!empty($res))

            @foreach($res as $prod)
                @php 
                    $rel_prod[] = $prod->pro_id;       	
                    $slug = (isset($prod->pro_slug))?pro_slug_prefix($prod->pro_slug):'';
                    $name = (isset($prod->pro_name))?$prod->pro_name:'';                                     
                @endphp         
                <div class="likebag-slide">
                  <div class="likebagbx">
                    <div class="likebagimage"> <a href="{{url('/').'/'.$slug}}"><img src="{{asset('products/').'/'.$prod->pro_relpro_img}}" alt="{{$prod->pro_name}}" /></a> </div>
                    <div class="likebag-detail">
                      <h4><a href="{{url('/').'/'.$slug}}">{{$prod->pro_name}}</a></h4>
                      <div class="bagprice"> Rent Price: <span><i class="fa fa-inr"></i>{{$prod->pro_price}}</span> </div>
                      <div class="rentow d-md-none"><a href="{{url('/').'/'.$slug}}">Rent Now</a></div>
                    </div>
                  </div>
                </div>       
            @endforeach 

		@endif
    @php
    	}
    @endphp                          
      </div>
    </div>
  </div>
  @endif
</div>
<script>
function add_to_cart_pro(){		
	var start_date = jQuery('#start_date').val();	
	if(start_date == ''){
		jQuery('#start_date').addClass('error_in_field');
		
	}else{
		jQuery('#start_date').removeClass('error_in_field');
		document.getElementById('add_to_cart').submit();
	}
}
</script>
@php
$datearrstr = '';
if(isset($data['blockdates']) && !empty($data['blockdates'])){
	$datearr = js_array($data['blockdates']);
        
    $datearrstr = '[';
    $total=count($data['blockdates']);
    foreach($data['blockdates'] as $ind=>$val){
       $datearrstr.= '"'.$val.'"';
       if($ind+1 < $total){
       		$datearrstr.= ',';
       }
    }
    $datearrstr.= ']';
}
@endphp
<script src="{{URL::asset('js/jquery-ui.min.js')}}"></script> 
 <script>
   @if(isset($data['blockdates']) && !empty($data['blockdates']))
    var disabledDates = {!!$datearr!!};	
   @endif	
    jQuery(function () {
        jQuery('.datetimepicker').datepicker({
			minDate: 0,
			@if(isset($data['blockdates']) && !empty($data['blockdates']))
			beforeShowDay: function(date){
				var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
				return [ disabledDates.indexOf(string) == -1 ]
			}
			@endif			  
		});
    });
</script>
<script>
$(document).ready(function() {
    $('.sliderwrap').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 2500,
  });
  $('.shopbrandslider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    fade:true,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 2000,
    pauseOnHover: false,
    pauseOnFocus: false,
    responsive: [
     
      {
        breakpoint: 992,
        settings: {
            dots: false,
        }
      }
      ]
  });

  /*-- thumbnal slider --*/
  $('.singalproduct-slider').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      fade:true,
      asNavFor: '.singalproduct-thumb',
      responsive: [
      {
        breakpoint: 992,
        settings: {
            dots:true,
        }
      },
      ]
  
  });
  $('.singalproduct-thumb').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      asNavFor: '.singalproduct-slider',
      dots: false,
      arrows: true,
      focusOnSelect: true,
       vertical: true,
  });

  $('.likebagslider').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: true,
    autoplay: false,
    autoplaySpeed: 2000,
    pauseOnHover: false,
    pauseOnFocus: false,
    responsive: [
      {
        breakpoint: 1025,
        settings: {
            slidesToShow: 3,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        }
      }
      ]
  });



   
});
</script>


@endsection
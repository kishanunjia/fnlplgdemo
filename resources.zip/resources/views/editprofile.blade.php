@extends('layouts.app')
@section('content')
@php
    $name = (!empty($data['display_name']))?$data['display_name']:$data['page_name'];
@endphp
<div class="sitewrapper shippingpage editprofile pb-0">
    <div class="container">
         <div class="pageheading">
              <h1>{{$name}}</h1>
              <p>Your primary email address cannot be changed: {{$data['user']->email}}</p>
          </div>
          @php 
              $errormsg = session()->get('error');
              $success  = session()->get('success');
              $tmpid  = session()->get('tmpid');              
          @endphp 
          @if(!empty($success))
             <div class="infotex alert alert-success alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>         
               {{$success}}
             </div>
          @endif  
          @if (count($errors) > 0)
             <div class="infotex alert alert-danger alert-dismissible fade show">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>              
                <ul>
                   @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                   @endforeach
                </ul>
             </div>
          @endif                       
          <div class="profileform">
              <form method="POST" name="update_profile" id="update_profile" action="{{route('update_profile')}}">
              @csrf
              <div class="row">
              
                  <div class="col-md-6 form-group">
                      <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name" value="{{$data['user']->fname}}" />
                  </div>
                  <div class="col-md-6 form-group">
                      <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name" value="{{$data['user']->lname}}" />
                  </div>
                  <div class="col-md-6 form-group">
                      <input type="tel" class="form-control number-only" id="phone_no" name="phone_no" value="{{$data['user']->phone_no}}" placeholder="Phone No." />
                  </div>
                  <div class="col-md-12 form-group align-centr">                    
                  	<input type="submit" name="save" value="SAVE" />
                  </div>
              </div>
              </form> 
          </div>
          <div id="adrswrapper" class="editpro-adresses">
            <form name="shippingbillingadd" id="shippingbillingadd" method="post" action="{{route('shipping_billing')}}">
            @csrf
            <div id="addadresnew_1" class="row editprofileadrs">
              <div class="col-md-6">  
                <div class="shippingform">
                    <div class="pageheading mobilebackarrow">
                      <h1>SHIPPING</h1>
                    </div>
                    
                      <div class="row">
                          <div class="col-md-12 form-group">
                              <input type="text" name="sp_address1"  class="form-control" placeholder="Street Address" />
                              <input type="text" name="sp_address2"  class="form-control mt-20" />
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" class="form-control" name="sp_city"  placeholder="City" />
                          </div>
                          <div class="col-md-12 form-group">
                              <select name="sp_state"  class="form-control">                                  
                                  <option value="Gujarat">Gujarat</option>
                                  <option value="Maharashtra">Maharashtra</option>
                                  <option value="Punjab">Punjab</option>
                                  <option value="Rajasthan">Rajasthan</option>
                              </select>
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" name="sp_post_code" class="form-control number-only" placeholder="Postal Code" />
                          </div>
                          <div class="col-md-12 form-group checkbox-row">
                              <label class="cstm-checkbox">
                                  Keep billing same as shipping
                                  <input name="sameadd" onchange="addshippingbil('shippingbillingadd')" type="checkbox" value="1">
                                  <span class="checkmark"></span>
                                </label>
                          </div>
                          <input type="hidden" name="sp_id" value="0" />
                      </div>
                    
                </div>
              </div>
              <div class="col-md-6">  
                <div class="shippingform billingform">
                    <div class="pageheading">
                      <h1>Billing</h1>
                    </div>
                    
                      <div class="row">
                          <div class="col-md-12 form-group">
                              <input type="text" name="bl_address1"  class="form-control" placeholder="Street Address" />
                              <input type="text" name="bl_address2"  class="form-control mt-20" />
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" class="form-control" name="bl_city"  placeholder="City" />
                          </div>
                          <div class="col-md-12 form-group">
                              <select name="bl_state"  class="form-control">                                  
                                  <option value="Gujarat">Gujarat</option>
                                  <option value="Maharashtra">Maharashtra</option>
                                  <option value="Punjab">Punjab</option>
                                  <option value="Rajasthan">Rajasthan</option>
                              </select>
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" name="bl_post_code" class="form-control number-only" placeholder="Postal Code" />
                          </div>
                          <input type="hidden" name="bl_id" value="0" />
                      </div>                     
                    
                </div>
              </div>
            </div>
            </form>

        <div class="container">
            <div class="adnewbtn" onclick="add_shipping_billing('shippingbillingadd')"><span class="adaadrssbtn">ADD NEW ADDRESS</span></div>
        </div>
           
       @if(!empty($data['ship_bill_arr']))
        @foreach($data['ship_bill_arr'] as $key=>$bsdata)
          @php
          	 $sp_address1=(isset($bsdata['shipping']->address1))?$bsdata['shipping']->address1:'';
             $sp_address2=(isset($bsdata['shipping']->address2))?$bsdata['shipping']->address2:'';             
             $sp_city=(isset($bsdata['shipping']->city))?$bsdata['shipping']->city:'';             
             $sp_post_code=(isset($bsdata['shipping']->post_code))?$bsdata['shipping']->post_code:'';             
             $sp_state=(isset($bsdata['shipping']->state))?$bsdata['shipping']->state:'';             
             $sp_id=(isset($bsdata['shipping']->id))?$bsdata['shipping']->id:'';
             
          	 $bl_address1=(isset($bsdata['billing']->address1))?$bsdata['billing']->address1:'';
             $bl_address2=(isset($bsdata['billing']->address2))?$bsdata['billing']->address2:'';             
             $bl_city=(isset($bsdata['billing']->city))?$bsdata['billing']->city:'';             
             $bl_post_code=(isset($bsdata['billing']->post_code))?$bsdata['billing']->post_code:'';             
             $bl_state=(isset($bsdata['billing']->state))?$bsdata['billing']->state:'';             
             $bl_id=(isset($bsdata['billing']->id))?$bsdata['billing']->id:'';             
             
          @endphp
          <form name="shippingbillingadd{{$key}}" id="shippingbillingadd{{$key}}" method="post" action="{{route('shipping_billing')}}">
          @csrf
            <div id="addadres_new_{{$key}}" class="row editprofileadrs neweditproadrs">
              <div class="col-md-6 shipping{{$sp_id}}">
                <div class="shippingform">
                  <div class="pageheading mobilebackarrow">
                    <h1>SHIPPING</h1>
                  </div>                  
                    <div class="row">
                          <div class="col-md-12 form-group">
                              <input type="text" name="sp_address1" value="{{$sp_address1}}"  class="form-control" placeholder="Street Address" />
                              <input type="text" name="sp_address2" value="{{$sp_address2}}"  class="form-control mt-20" />
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" class="form-control" value="{{$sp_city}}" name="sp_city"  placeholder="City" />
                          </div>
                          <div class="col-md-12 form-group">
                              <select name="sp_state"  class="form-control">                                  
                                  <option @if($sp_state == 'Gujarat') selected @endif value="Gujarat">Gujarat</option>
                                  <option @if($sp_state == 'Maharashtra') selected @endif value="Maharashtra">Maharashtra</option>
                                  <option @if($sp_state == 'Punjab') selected @endif value="Punjab">Punjab</option>
                                  <option @if($sp_state == 'Rajasthan') selected @endif value="Rajasthan">Rajasthan</option>
                              </select>
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" name="sp_post_code" value="{{$sp_post_code}}" class="form-control number-only" placeholder="Postal Code" />
                          </div>
                          <div class="col-md-12 form-group checkbox-row">
                              <label class="cstm-checkbox">
                                  Keep billing same as shipping
                                  <input name="sameadd" onchange="addshippingbil('shippingbillingadd{{$key}}')" type="checkbox" value="1">
                                  <span class="checkmark"></span>
                                </label>
                          </div>
                          <input type="hidden" name="sp_id" value="{{$sp_id}}" />
                      </div>                  
                </div>
              </div>
              <div class="col-md-6 billing{{$bl_id}}">
                <div class="shippingform billingform">
                  <div class="pageheading">
                    <h1>Billing</h1>
                  </div>
                  <div class="row">
                          <div class="col-md-12 form-group">
                              <input type="text" name="bl_address1" value="{{$bl_address1}}"  class="form-control" placeholder="Street Address" />
                              <input type="text" name="bl_address2" value="{{$bl_address2}}"  class="form-control mt-20" />
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" class="form-control" value="{{$bl_city}}" name="bl_city"  placeholder="City" />
                          </div>
                          <div class="col-md-12 form-group">
                              <select name="bl_state"  class="form-control">                                  
                                  <option @if($bl_state == 'Gujarat') selected @endif value="Gujarat">Gujarat</option>
                                  <option @if($bl_state == 'Maharashtra') selected @endif value="Maharashtra">Maharashtra</option>
                                  <option @if($bl_state == 'Punjab') selected @endif value="Punjab">Punjab</option>
                                  <option @if($bl_state == 'Rajasthan') selected @endif value="Rajasthan">Rajasthan</option>
                              </select>
                          </div>
                          <div class="col-md-12 form-group">
                              <input type="text" name="bl_post_code" value="{{$bl_post_code}}" class="form-control number-only" placeholder="Postal Code" />
                          </div>                          
                          <input type="hidden" name="bl_id" value="{{$bl_id}}" />
                      </div>
                </div>
              </div>
              <span id="remove_2" onclick="deleteAddress({{$sp_id}},{{$bl_id}},'shippingbillingadd{{$key}}');" class="adrsdltbtn"><img src="{{asset('/images/close.png')}}" alt="Close Icon"></span>
              <div class="adnewbtn edit-btn" onclick="add_shipping_billing('shippingbillingadd{{$key}}')"><span class="adaadrssbtn">EDIT</span></div>
              </div>              
          </form>    
        @endforeach  
       @endif               
            
          </div>

    </div>
</div>
@if(!empty($tmpid))
<script>
jQuery(document).ready(function(e) {
    jQuery('html, body').animate({ 'scrollTop' : jQuery('.{{$tmpid}}').offset().top - 90}, 700);
});
</script>
@endif
<script>
function deleteAddress(sp_id,bl_id,remvid){
   if(confirm('Are you sure you want to delete ?')){
		var formdata = new FormData();							
		var CSRF_TOKEN = jQuery('meta[name="csrf-token"]').attr('content');			
		formdata.append('_token',CSRF_TOKEN);
		formdata.append('sp_id',sp_id);
		formdata.append('bl_id',bl_id);
		var rindex = jQuery('#rindex').val();
		jQuery.ajaxSetup({
			headers:{
				'X-CSRF-TOKEN': CSRF_TOKEN
			}
		});					
		jQuery.ajax({
			type: "POST",
			url:  "{{route('shipping_billing_delete')}}",
			data: formdata,
			processData: false, 
			contentType: false,
			cache: false,
			success: function(res){
			  if(res.status == 'Y'){			  
				  jQuery('#'+remvid).remove();
			  }
			}
		});						
   }
}
function required_validate(obj){
  	var final_val = obj.val();
	if(final_val == '')
	{
	  obj.addClass('error_in_field_bottom');
	  return false;	
	}
	else
	{
	  obj.removeClass('error_in_field_bottom');
	  return true;		
	}
}

function addshippingbil(frmid){
	var sameadd = jQuery("#"+frmid+" input[name='sameadd']").prop("checked");
	if(sameadd){
		jQuery("#"+frmid+" input[name='bl_address1']").val(jQuery("#"+frmid+" input[name='sp_address1']").val());		
		jQuery("#"+frmid+" input[name='bl_address2']").val(jQuery("#"+frmid+" input[name='sp_address2']").val());		
		jQuery("#"+frmid+" input[name='bl_city']").val(jQuery("#"+frmid+" input[name='sp_city']").val());
		jQuery("#"+frmid+" input[name='bl_post_code']").val(jQuery("#"+frmid+" input[name='sp_post_code']").val());
		jQuery("#"+frmid+" select[name='bl_state']").val(jQuery("#"+frmid+" select[name='sp_state']").val());				
	}else{
		jQuery("#"+frmid+" input[name='bl_address1']").val('');
		jQuery("#"+frmid+" input[name='bl_address2']").val('');
		jQuery("#"+frmid+" input[name='bl_city']").val('');
		jQuery("#"+frmid+" input[name='bl_post_code']").val('');
		jQuery("#"+frmid+" input[name='bl_state']").val('');		
	}
}

function add_shipping_billing(frmid){
	var flag = true;
	var scroll_flag = false;
	var scroll_obj = false;

	var fname = jQuery("#fname");
	var lname = jQuery("#lname");
	var phone_no = jQuery("#phone_no");
		
	//sp_id
	var sp_id = jQuery("#"+frmid+" input[name='sp_id']").val();	
	if(sp_id == 0){		
		if(!required_validate(fname)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true; scroll_obj = fname;
		  }
		}
		
		if(!required_validate(lname)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true; scroll_obj = lname;
		  }
		}
		
		if(!required_validate(phone_no)){
		  flag = false;
		  if(!scroll_flag){
			  scroll_flag = true; scroll_obj = phone_no;
		  }
		}					
		
	}
	
	var sp_address1 = jQuery("#"+frmid+" input[name='sp_address1']");
	var sp_city = jQuery("#"+frmid+" input[name='sp_city']");
	var sp_post_code = jQuery("#"+frmid+" input[name='sp_post_code']");
	var sp_state = jQuery("#"+frmid+" input[name='sp_state']");
	
	var bl_address1 = jQuery("#"+frmid+" input[name='bl_address1']");
	var bl_city = jQuery("#"+frmid+" input[name='bl_city']");
	var bl_post_code = jQuery("#"+frmid+" input[name='bl_post_code']");
	var bl_state = jQuery("#"+frmid+" input[name='bl_state']");
				
	if(!required_validate(sp_address1)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = sp_address1;
	  }
	}
	
	if(!required_validate(sp_city)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = sp_city;
	  }
	}
	
	if(!required_validate(sp_state)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = sp_state;
	  }
	}
	
	if(!required_validate(sp_post_code)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = sp_post_code;
	  }
	}
	if(!required_validate(bl_address1)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = bl_address1;
	  }
	}
	
	if(!required_validate(bl_city)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = bl_city;
	  }
	}
	
	if(!required_validate(bl_state)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = bl_state;
	  }
	}
	
	if(!required_validate(bl_post_code)){
	  flag = false;
	  if(!scroll_flag){
		  scroll_flag = true; scroll_obj = bl_post_code;
	  }
	}						
	
	if(scroll_flag){			
		jQuery('html, body').animate({ 'scrollTop' : scroll_obj.offset().top - 90}, 700);			
		scroll_obj.focus();		   	
	}else{		
		 jQuery("#"+frmid).submit();			
	}
	
	
	
	
	
}
jQuery(document).ready(function () {
  jQuery(".number-only").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
         return false;
     }
   });
});
</script>
@endsection

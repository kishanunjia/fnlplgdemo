@extends('layouts.app')

@section('content')
@php
    $hasRegErr=false;
    $regi = old('regi');
    if($regi){
        $hasRegErr=true;
    }                        
@endphp
<div class="sitewrapper loginregister">
    <div class="container">
          <div class="loginbx">
              <div class="logintab-nav">  
                    <ul class="nav nav-tabs" role="tablist">
                      <li class="nav-item">
                          <a class="nav-link active" data-toggle="tab" href="#logintab" role="tab">LOG IN</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link reg-tab" data-toggle="tab" href="#registertab" role="tab">REGISTER</a>
                      </li>
                    </ul>
              </div>
              <div class="tab-content">
                <div class="tab-pane fade show active" id="logintab" role="tabpanel">
                    <div class="lgn-regtab-inner">
                        <h4>Sign In with Email</h4>
                        <div class="lgn-reg-form">
                            <form method="POST" action="{{ route('login') }}">
                            	@csrf
                                <div class="form-group">
                                    <label>E-MAIL  ADDRESS:</label>
                                    <input type="email" class="form-control @error('email') is-invalid @enderror"  name="email" value="{{ old('email') }}" required autocomplete="email" autofocus />
                                    @error('email')
                                      @if(empty($regi))
                                        <span class="invalid-error" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                       @endif 
                                    @enderror                                    
                                </div>
                                <div class="form-group">
                                    <label>PASSWORD:</label>
                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">
                                    @error('password')
                                       @if(empty($regi))
                                        <span class="invalid-error" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                       @endif 
                                    @enderror                                    
                                </div>
                                <div class="form-group loginbtm mb-0">
                                    <input type="submit" class="form-submit" value="SIGN IN" />
                                    <a class="btn btn-link" href="{{ route('password.request') }}">{{ __('Forgot Your Password?') }}</a>                                    
                                    <!--<a href="{{url('/').'/'.get_page_url_by_id(16)}}">Forgot Password?</a>-->
                                </div>
                            </form>
                        </div>
                    </div>  
                </div>
                <div class="tab-pane" id="registertab" role="tabpanel">
					

					                                                          
                    <div class="lgn-regtab-inner">
                        <h4>Join us</h4>
                        <div class="lgn-reg-form">
                            <form method="POST" action="{{ url('register') }}">
                                @csrf
                                <div class="form-group">
                                    <label>First NAME:</label>
                                    <input required="required" name="fname" type="text" class="form-control" />
                                </div>
                                <div class="form-group">
                                    <label>LAST NAME:</label>
                                    <input required="required" name="lname" type="text" class="form-control" />
                                </div>
                                <div class="form-group">
                                    <label>E-MAIL  ADDRESS:</label>
                                    <input name="email" type="email" value="{{ old('email') }}" required autocomplete="email" class="form-control" />
                                    @error('email')                                    
                                       @if(!empty($regi)) 
                                        <span class="invalid-error" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                       @endif 
                                    @enderror                                     
                                </div>
                                <div class="form-group">
                                    <label>PASSWORD:</label>
                                    <input type="password" name="password" required class="form-control" />
                                    @error('password') 
                                       @if(!empty($regi))                                     
                                        <span class="invalid-error" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                       @endif 
                                    @enderror                                     
                                </div>
                                <div class="form-group">
                                    <label>RE TYPE PASSWORD:</label>
                                    <input type="password" name="password_confirmation" required autocomplete="new-password" class="form-control" />
                                </div>
                                <div class="form-group loginbtm mb-0">
                                    <div class="trmstxt">By creating your account, you agree to our Terms and Conditions & Privacy Policy</div>
                                    <input name="regi" type="hidden" value="regi"  />
                                    <input type="submit" class="form-submit" value="REGISTER" />
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
              </div>


              
          </div>
    </div>
</div>
@if($hasRegErr)
<script>
jQuery(document).ready(function(){
	jQuery('.reg-tab').trigger('click');	
});
</script>
@endif
@endsection

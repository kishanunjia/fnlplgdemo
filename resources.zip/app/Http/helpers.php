<?php 
use App\User;
use App\adminpanel\Products;
use App\adminpanel\Productcategory;
use App\adminpanel\Productattributesmodal;
use App\adminpanel\Cmspage;
use App\adminpanel\Menu;
use App\Cart;

//use DB;

//Product Final Block Dates
function get_product_block_dates_final($pro_id){
	$admin_blocks_dates = get_product_block_dates($pro_id);
	$final_blocks_dates=array();
	$order_prod = DB::table('order_product as orpd')->join('order_main as orm', function($join){
							$join->on('orpd.or_id', '=', 'orm.or_id');						 
	})->select('orpd.*')->where([['orm.or_status','<>','Cancel'],['orpd.pro_id','=',$pro_id]])->get();				
	if(!empty($order_prod)){
		$blocking_days = get_option('blocking_days');
		foreach($order_prod as $orpd){			
			$start_date = date_to_minus_day($orpd->start_date,$blocking_days);
			$end_date   = date_to_plus_day($orpd->end_date,$blocking_days);
			
			$books_date_arr = getDatesFromRange($start_date,$end_date);		
			$final_blocks_dates=array_merge($final_blocks_dates,$books_date_arr);
		}
	}
	return $final_blocks_dates=array_merge($final_blocks_dates,$admin_blocks_dates);	
}

//Email

function body_footer(){
	return '</body></html>';
}

function body_header(){
	return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html data-editor-version="2" class="sg-campaigns" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<style type="text/css">
body, p, div {
	font-family: inherit;
	font-size: 14px;
}
body {
	color: #000000;
}
body a {
	color: #1188E6;
	text-decoration: none;
}
p {
	margin: 0;
	padding: 0;
}
table.wrapper {
	width:100% !important;
	table-layout: fixed;
	-webkit-font-smoothing: antialiased;
	-webkit-text-size-adjust: 100%;
	-moz-text-size-adjust: 100%;
	-ms-text-size-adjust: 100%;
}
img.max-width {
	max-width: 100% !important;
}
.column.of-2 {
	width: 50%;
}
.column.of-3 {
	width: 33.333%;
}
.column.of-4 {
	width: 25%;
}
 @media screen and (max-width:480px) {
 .preheader .rightColumnContent,  .footer .rightColumnContent {
 text-align: left !important;
}
 .preheader .rightColumnContent div,  .preheader .rightColumnContent span,  .footer .rightColumnContent div,  .footer .rightColumnContent span {
 text-align: left !important;
}
 .preheader .rightColumnContent,  .preheader .leftColumnContent {
 font-size: 80% !important;
 padding: 5px 0;
}
 table.wrapper-mobile {
 width: 100% !important;
 table-layout: fixed;
}
 img.max-width {
 height: auto !important;
 max-width: 100% !important;
}
 a.bulletproof-button {
 display: block !important;
 width: auto !important;
 font-size: 80%;
 padding-left: 0 !important;
 padding-right: 0 !important;
}
 .columns {
 width: 100% !important;
}
 .column {
 display: block !important;
 width: 100% !important;
 padding-left: 0 !important;
 padding-right: 0 !important;
 margin-left: 0 !important;
 margin-right: 0 !important;
}
}
</style>
<link href="https://fonts.googleapis.com/css?family=Viga&display=swap" rel="stylesheet">
<style>
body {
	font-family: "Viga", sans-serif;
}
</style>
</head>
<body>';	
}

function from_name(){
	return 'BeRightBag';	
}

function from_email(){
	return get_option('from_email');
}

function admin_email(){
	return get_option('admin_notification_email');	
}

function admin_to_name(){
	return 'Admin';	
}

function must_login_front(){
	$user_id = Auth::id();
	$user_id = ($user_id)?$user_id:0;
	return $user_id;	
}

function get_user_name(){
	$user_id = Auth::id();
	$user_id = ($user_id)?$user_id:0;
	$user=DB::table('users')->select('*')->where('id',$user_id)->first();	
	return (isset($user->fname))?$user->fname:'';
}

function get_order_products($or_id){
	return DB::table('order_product')->select('*')->where('or_id',$or_id)->get();
}

function get_payment_method_full_name($short){
	if($short == 'cash'){
		return 'CASH ON DELIVERY';
	}else if($short == 'visacard'){
		return 'VISA';
	}else if($short == 'mastercard'){
		return 'MasterCard';
	}else{
		return '';	
	}
}

function get_cart_id(){
	$user_id = Auth::id();
	$user_id = ($user_id)?$user_id:0; 
	$ip = get_the_user_ip();				
	
	$cart = Cart::where('ip',$ip)->first();
	$crtid = (isset($cart->crtid))?$cart->crtid:0;
	if(isset($cart->crtid) && $cart->user_id == 0){
		if($user_id){
			Cart::where('crtid',$crtid)->first()->update(array('user_id'=>$user_id));	
		}
	}		
	if($user_id){
		$cart = Cart::where('user_id',$user_id)->first();			
	}else{
		$cart = Cart::where('ip',$ip)->first();			
	}

	$crtid = (isset($cart->crtid))?$cart->crtid:0;	
	return $crtid;
}

function get_cart_product(){
		$crtid = get_cart_id();
		
	    $cart_products = DB::table('cart_product as cpro')
		->join('products as pro', function ($join) {
			$join->on('pro.pro_id', '=', 'cpro.pro_id');
		})			 				
		->select(array('cpro.*', 'pro.*'))
		->where('cpro.crtid', '=', $crtid)
		->where('pro.pro_status', '=', 1)												
		->get();
		
		return $cart_products;	
}

function get_cart_deposit_total(){
		$total = 0;
		$crtid = get_cart_id();		
	    
		$cart_products = DB::table('cart_product as cpro')
		->join('products as pro', function ($join) {
			$join->on('pro.pro_id', '=', 'cpro.pro_id');
		})			 				
		->select(array('cpro.*', 'pro.*'))
		->where('cpro.crtid', '=', $crtid)
		->where('pro.pro_status', '=', 1)												
		->get();
		
		if(!empty($cart_products)){
			foreach($cart_products as $cpro){
				$total = $total+$cpro->pro_deposit;
			}
		}		
		return $total;	
}

function get_cart_total($showdesc=false){
		$total = 0;
		$crtid = get_cart_id();		
	    $coupon_dicount = 0;		
		$cart = Cart::where('crtid',$crtid)->first();						
		$cart_products = DB::table('cart_product as cpro')
		->join('products as pro', function ($join) {
			$join->on('pro.pro_id', '=', 'cpro.pro_id');
		})			 				
		->select(array('cpro.*', 'pro.*'))
		->where('cpro.crtid', '=', $crtid)
		->where('pro.pro_status', '=', 1)												
		->get();
		
		if(!empty($cart_products)){
			foreach($cart_products as $cpro){
				$price = (!empty($cpro->pro_sale_price))?$cpro->pro_sale_price:$cpro->pro_price;
				$alldates = getDatesFromRange($cpro->start_date,$cpro->end_date);
				$days = count($alldates);
				$price = $price * $days;
				$total = $total+$price;
			}
		}
		$coup_id = (isset($cart->coup_id))?$cart->coup_id:0;
		if($coup_id){
			
			$coup_type = (isset($cart->coup_type))?$cart->coup_type:0;
			$coup_val  = (isset($cart->coup_val))?$cart->coup_val:0;
		    if($coup_type == 'per'){			 	
			 	$coupon_dicount = round(($total*$coup_val)/100);					 
		    }else{
			 	$coupon_dicount = $coup_val;
		    }			
			
		}
		$finaltotal = $total-$coupon_dicount;
		if($showdesc){				
			return array('total'=>$finaltotal,'dicount'=>$coupon_dicount,'withoutdisc'=>$total);	
		}else{
			return $total;	
		}
}

function uppercasetext($text){
	return strtoupper($text);	
}

function front_date_formate($date){
	if($date){
		$date = date("l, d F", strtotime($date));
	}
	return $date;
}

function indian_date_formate($date){
	if($date){
		$date = date("d/m/Y", strtotime($date));
	}
	return $date;
}


function db_to_date($date){
	if($date){
		$date = date("m/d/Y", strtotime($date));
	}
	return $date;
}

function date_to_db($date){
	if($date){
		$date = date("Y-m-d", strtotime($date));
	}
	return $date;
}

function date_to_minus_day($date,$day){
	if($date && $day != 0){
		$date = date('Y-m-d',strtotime($date . "-".$day." days"));
	}
	return $date;
}
function date_to_plus_day($date,$day){
	if($date && $day != 0){
		$date = date('Y-m-d',strtotime($date . "+".$day." days"));
	}
	return $date;
}

function get_extra_prod($pro_ids,$limit){
	$res = '';
	if(!empty($pro_ids)){
		$res = Products::where('pro_status',1)->whereNotIn('pro_id', $pro_ids)->limit($limit)->get();		
	}
	return $res;	
}

function get_product_all_block_dates($pro_id){
	$blockdates = array();
	if(!empty($pro_id)){
		$products = Products::where('pro_id',$pro_id)->first();	
		$block_start_date = $products->block_start_date;			 
		$block_end_date   = $products->block_end_date;			 
		if(!empty($block_start_date) && !empty($block_end_date)){
		   $blockdates = getDatesFromRange($block_start_date,$block_end_date);   
		}			
	}
	
	return $blockdates;	
}

function get_product_block_dates($pro_id){	
	$blockdates = array();
	if(!empty($pro_id)){
		$products = Products::where('pro_id',$pro_id)->first();	
		$block_start_date = $products->block_start_date;			 
		$block_end_date   = $products->block_end_date;			 
		if(!empty($block_start_date) && !empty($block_end_date)){
		   $blockdates = getDatesFromRange($block_start_date,$block_end_date);   
		}			
	}
	return $blockdates;	
}

function get_the_user_ip() {
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	}else{
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}



function common_data($id=0){
		 $data = array();
		 $cmspage = Cmspage::where('id',$id)->first(); 
		 $commonset = DB::table('setting_master')
                    ->whereIn('meta_key', ['site_name','site_logo','site_favicon_logo','copy_rights','instagram_link','facebook_link','linkedin_link'])
                    ->get();
		 if(!empty($commonset)){
			foreach($commonset as $set){
				$data[$set->meta_key] = $set->meta_value; 			
			}
		 }
		 $data['page_id'] = (isset($cmspage->id))?$cmspage->id:'';
		 $data['page_name'] = (isset($cmspage->page_name))?$cmspage->page_name:'';
		 $data['display_name'] = (isset($cmspage->display_name))?$cmspage->display_name:'';
		 $data['meta_title'] = (isset($cmspage->meta_title))?$cmspage->meta_title:'';
		 $data['meta_desc'] = (isset($cmspage->meta_desc))?$cmspage->meta_desc:'';
		 $data['meta_keyword'] = (isset($cmspage->meta_keyword))?$cmspage->meta_keyword:'';
		 $data['page_content'] = (isset($cmspage->page_content))?$cmspage->page_content:'';		 		  
		 $data['menutop'] = Menu::orderby('m_order','desc')->where('m_type','top')->get();
		 $data['menubottom'] = Menu::orderby('m_order','desc')->where('m_type','bottom')->get();		 		 
		 return $data;		 	
}


function js_str($s){
    return '"' . addcslashes($s, "\0..\37\"\\") . '"';
}

function js_array($array)
{
    $temp = array_map('js_str', $array);
    return '[' . implode(',', $temp) . ']';
}

function getDatesFromRange($start, $end, $format = 'Y-m-d') { 
      
    // Declare an empty array 
    $array = array(); 
      
    $interval = new DateInterval('P1D'); 
  
    $realEnd = new DateTime($end); 
    $realEnd->add($interval); 
  
    $period = new DatePeriod(new DateTime($start), $interval, $realEnd); 
  
    foreach($period as $date) {                  
        $array[] = $date->format($format);  
    } 
  
    // Return the array elements 
    return $array; 
} 

function get_option($meta_key){
	$settings_master= DB::table('setting_master')->where('meta_key',$meta_key)->first();
	return $settings_master->meta_value;
}

function get_brand_name_by_id($bid){
	$bname = '';
	if(!empty($bid)){
		$attr = Productattributesmodal::where('attr_id',$bid)->first();		
		$bname = (isset($attr->attr_name))?$attr->attr_name:'';
	}
	return $bname;	
}

function get_product_by_id($pro_id){
	$product = '';
	if(!empty($pro_id)){
		$product = Products::where('pro_status',1)->where('pro_id',$pro_id)->first();		
	}
	return $product;	
}

function display_meta_title($site_name='BeRightBag',$meta_title='',$page_title=''){
	$meta_title=(!empty($meta_title))?$meta_title:$page_title;
	return $meta_title.' - '.$site_name;
}

function pro_slug_prefix($slug){
	if(!empty($slug)){
		return 'product/'.$slug;
	}
	return '';
}

function get_pro_url_by_id($pro_id){
	$slug='';
	if(!empty($pro_id) && $pro_id != 1){
		$prord = Products::where('pro_id',$pro_id)->first();
		$slug  = (isset($prord->pro_slug))?'product/'.$prord->pro_slug:'';
	}
	return $slug;
}

function get_page_url_by_id($pid){
	$slug='';
	if(!empty($pid) && $pid != 1){
		$cmsr=Cmspage::where('id',$pid)->first();
		$slug=(isset($cmsr->page_slug))?$cmsr->page_slug:'';
	}
	return $slug;
}

function get_cat_name_by_id($cid){
	if($cid){
		$p_cats = DB::table('product_category')->where('cid',$cid)->first();
		if(isset($p_cats->cname)){
			return $p_cats->cname;	
		}else{
			return '';	
		}
	}
	return '';
}



function product_block_date_display($start,$end){
	$html='';
	if($start && $end){
	   if($end >= date('Y-m-d')){	
			$start = date("m/d/Y", strtotime($start));
			$end = date("m/d/Y", strtotime($end));
			$html='Product block from '.$start.' to '.$end.'.';
	   }
	}	
	return $html;
}

function get_all_category_list(){
	$allcats = Productcategory::where('cstatus',1)->get();
	return $allcats;	
}

function get_all_brand(){
    $allbrand=Productattributesmodal::orderby('attr_order','desc')->where([['attr_type','=','brand'],['attr_status','=',1]])->get();	
    return $allbrand;
}

/*function price_formate($price){
	if(!empty($price)){
		
	}
}*/

function get_category_product($cid=''){
	    $products = '';
		if(!empty($cid)){
		    $products = DB::table('products as pro')
			 ->join('pro_cat_rel as prel', function ($join) {
					$join->on('prel.pro_id', '=', 'pro.pro_id');						 
				})								
			->select(array('pro.*', 'prel.pro_id', 'prel.cid'))
			->where('pro.pro_status', '=', 1)->where('prel.cid', '=', $cid)										
			->orderby('pro.pro_order', 'desc')
			->get();
		}
	return $products;	
}


function get_brand_products($bid){
	$bpro = '';
	if(!empty($bid)){
		$bpro = Products::where([['pro_status','=',1],['pro_brand','=',$bid]])->get();
		return $bpro;	
	}
	return $bpro;
}

function get_all_products_list(){
	$products = Products::where('pro_status',1)->get();
	return $products;	
}

function get_product_name_by_id($pro_id){
	$name = '';
	if(!empty($pro_id)){
		$products = Products::where('pro_status',1)->where('pro_id',$pro_id)->first();
		if(isset($products->pro_name)){
			$name = $products->pro_name;
		}
	}
	return $name;	
}

function assign_rand_value($num) {

    // accepts 1 - 36
    switch($num) {
        case "1"  : $rand_value = "a"; break;
        case "2"  : $rand_value = "b"; break;
        case "3"  : $rand_value = "c"; break;
        case "4"  : $rand_value = "d"; break;
        case "5"  : $rand_value = "e"; break;
        case "6"  : $rand_value = "f"; break;
        case "7"  : $rand_value = "g"; break;
        case "8"  : $rand_value = "h"; break;
        case "9"  : $rand_value = "i"; break;
        case "10" : $rand_value = "j"; break;
        case "11" : $rand_value = "k"; break;
        case "12" : $rand_value = "l"; break;
        case "13" : $rand_value = "m"; break;
        case "14" : $rand_value = "n"; break;
        case "15" : $rand_value = "o"; break;
        case "16" : $rand_value = "p"; break;
        case "17" : $rand_value = "q"; break;
        case "18" : $rand_value = "r"; break;
        case "19" : $rand_value = "s"; break;
        case "20" : $rand_value = "t"; break;
        case "21" : $rand_value = "u"; break;
        case "22" : $rand_value = "v"; break;
        case "23" : $rand_value = "w"; break;
        case "24" : $rand_value = "x"; break;
        case "25" : $rand_value = "y"; break;
        case "26" : $rand_value = "z"; break;
        case "27" : $rand_value = "0"; break;
        case "28" : $rand_value = "1"; break;
        case "29" : $rand_value = "2"; break;
        case "30" : $rand_value = "3"; break;
        case "31" : $rand_value = "4"; break;
        case "32" : $rand_value = "5"; break;
        case "33" : $rand_value = "6"; break;
        case "34" : $rand_value = "7"; break;
        case "35" : $rand_value = "8"; break;
        case "36" : $rand_value = "9"; break;
    }
    return $rand_value;
}

function get_rand_alphanumeric($length) {
    if ($length>0) {
        $rand_id="";
        for ($i=1; $i<=$length; $i++) {
            mt_srand((double)microtime() * 1000000);
            $num = mt_rand(1,36);
            $rand_id .= assign_rand_value($num);
        }
    }
    return $rand_id;
}

function get_rand_numbers($length) {
    if ($length>0) {
        $rand_id="";
        for($i=1; $i<=$length; $i++) {
            mt_srand((double)microtime() * 1000000);
            $num = mt_rand(27,36);
            $rand_id .= assign_rand_value($num);
        }
    }
    return $rand_id;
}

function get_rand_letters($length) {
    if ($length>0) {
        $rand_id="";
        for($i=1; $i<=$length; $i++) {
            mt_srand((double)microtime() * 1000000);
            $num = mt_rand(1,26);
            $rand_id .= assign_rand_value($num);
        }
    }
    return $rand_id;
}


?>
<?php

namespace App\Http\Controllers;

use Session;
use Illuminate\Http\Request;
use App\Authentication;
use Illuminate\Support\Facades\Input;
use Validator,Redirect,Response;

use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class AuthenticationController extends Controller{
    
  public function index(){           
	 return view('admin/login')->with("userData",'tt');	
  }	
  
  public function logincheck(Request $request){
	  
	  $credentials = $request->only('email', 'password');
	  if(Auth::attempt($credentials)){
		 return Redirect::to("adminpanel/dashboard")->withSuccess('Admin Successfully Login.'); 
	  }else{
		 return Redirect::to("adminpanel")->with('errormsg','Oppes! You have entered invalid credentials'); 
	  }
	  	  	  	  	  	  	  
  }	
}

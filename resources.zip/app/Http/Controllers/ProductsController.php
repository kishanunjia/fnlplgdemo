<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use App\adminpanel\Cmspage;
use App\adminpanel\Menu;
use App\adminpanel\Productattributesmodal;
use App\adminpanel\Products;



class ProductsController extends Controller{

     public function __construct(){
        //$this->middleware('auth');
     }
    
	 public function index(Request $request){
	 
		 $page_slug = \Request::segment(2);
		 $data = array();
		 $commonset = DB::table('setting_master')
                    ->whereIn('meta_key', ['site_name','site_logo','site_favicon_logo','copy_rights','instagram_link','facebook_link','linkedin_link'])
                    ->get();
		 if(!empty($commonset)){
			foreach($commonset as $set){
				$data[$set->meta_key] = $set->meta_value; 			
			}
		 }		 		 			 		 		 
		 $products = Products::where([['pro_slug','=',$page_slug],['pro_status','=',1]])->first();
		 		 				 
		 if(!empty($products)){			 
			 $data['page_id'] = 0;
			 $data['page_name'] = (isset($products->pro_name))?$products->pro_name:'';
			 $data['display_name'] = (isset($products->pro_name))?$products->pro_name:'';
			 $data['meta_title'] = (isset($products->pro_name))?$products->pro_name:'';
			 $data['meta_desc'] = (isset($products->pro_name))?$products->pro_name:'';
			 $data['meta_keyword'] = '';
			 $data['page_content'] = (isset($products->pro_description))?$products->pro_description:'';			
			 							  
			 $data['menutop'] = Menu::orderby('m_order','desc')->where('m_type','top')->get();
			 $data['menubottom'] = Menu::orderby('m_order','desc')->where('m_type','bottom')->get();
			 $data['product'] = $products;			 
			 $pro_color = $products->pro_color;
			 
			 $blockdates = array();
			 $block_start_date = $products->block_start_date;			 
			 $block_end_date   = $products->block_end_date;			 
			 		 
			 $data['blockdates'] = get_product_block_dates_final($products->pro_id); 			 			 			 
			 $rel_prod = Products::where([['pro_color','=',$pro_color],['pro_status','=',1],['pro_id','<>',$products->pro_id]])->orderby('pro_order', 'desc')->get();
			 $data['rel_prod'] = $rel_prod; 
			 						 
			 return view('product_detail')->with("data",$data);	 		 		 
		 }
	 }
	 
 
	
}

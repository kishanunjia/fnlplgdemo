<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use App\adminpanel\Cmspage;
use App\adminpanel\Menu;
use App\adminpanel\Productattributesmodal;
use App\adminpanel\Products;
use App\Cart;
use App\adminpanel\Coupon;


class HomeController extends Controller{
    /**
     * Create a new controller instance.
     *
     * @return void
    */	 
    public function __construct(){
        //$this->middleware('auth');
    }	
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
    */	
    public function index(Request $request){		
		$page_slug = \Request::segment(1);
		if(empty($page_slug)){
			$page_slug = 'home';	
		}
		if($page_slug == 'home'){
			return $this->front();
		}
		$cmspage = Cmspage::where('page_slug',$page_slug)->first();
		$page_id = (isset($cmspage->id))?$cmspage->id:0;
		if($page_id == 6){
			return $this->products($page_slug);
		}
		
		if($page_id == 2){
			return $this->how_it_works($page_slug);
		}
		
		if($page_id == 15){
			return $this->login_register($page_slug);
		}
		
		if($page_id == 16){
			return $this->forgot_password($page_slug);
		}
		
		if($page_id == 7){
			return $this->cart($page_slug);
		}
		
		if($page_id == 17){
			return $this->edit_profile($page_slug);
		}
		
		if($page_id == 8){
			return $this->shipping_billing_info($page_slug);
		}
		
		if($page_id == 9){
			return $this->payment_method($page_slug);
		}
		
		if($page_id == 18){
			return $this->card_detail($page_slug);
		}
		
		if($page_id == 19){
			return $this->summery($page_slug);
		}
		
		if($page_id == 20){
			return $this->order_history($page_slug);
		}
		
		if($page_id == 3){
			return $this->contact_us($page_slug);
		}																						
								
		if($page_id != 0){		
			return $this->common_page($page_slug);
		}
		return abort(404);
    }
	
	public function contact_us_submit(Request $request){
						
			$this->validate($request,[
				'fname' => 'required|max:50',
				'lname' => 'required|max:50',
				'email' => 'required|email',				
				'subject' => 'required|max:50',				
				'message' => 'required|max:1500',				
				'provacy_policy' => 'required|max:50',
			], [], 
			[
				'fname' => 'First Name',
				'lname' => 'Last Name',				
				'email' => 'E-mail',				
				'subject' => 'Subject',				
				'message' => 'Message',				
				'provacy_policy' => 'Accept Our Privacy Policy',																
			]);		
		
	}
	
	public function contact_us($page_slug){
						
		$data = $this->common_data($page_slug);				
		return view('contactus')->with("data",$data);
		
	}

	public function common_page($page_slug){
		
		/*$to = "kishanu.gc@gmail.com";
		$subject = "My subject";
		$txt = "Hello world!";
		$headers = "From: info@gujjucoders.com" . "\r\n" .
		"CC: info@gujjucoders.com";		
		if(mail($to,$subject,$txt)){
			echo 'Send Succesfully';
			die;	
		}else{
			echo 'Not Send';
			die;				
		}*/					
		$data = $this->common_data($page_slug);				
		return view('common')->with("data",$data);
		
	}

	public function order_history($page_slug){
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;
				
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}
		$data = $this->common_data($page_slug);	
		$data['order_list'] = DB::table('order_main')->select('*')->where('user_id',$user_id)->orderby('or_id','desc')->get();		
		$data['last_order'] = DB::table('order_main')->select('*')->where('user_id',$user_id)->orderby('or_id','desc')->first();		
		$code = '';
		$valid = '';
		$coup_id = (isset($data['last_order']->feedback_coupon))?$data['last_order']->feedback_coupon:0;
		if($coup_id){
			$coupn=Coupon::where([['coup_id','=',$coup_id],['coup_use','>',0]])->first();
			$code = (isset($coupn->coup_code))?$coupn->coup_code:'';
			$valid = (isset($coupn->coup_end_date))?$coupn->coup_end_date:'';
		}
		$data['code'] =	$code;
		$data['valid'] = $valid;	
		return view('orderhistory')->with("data",$data);		
			
	}

	public function summery($page_slug){
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}			
		$cart_total = get_cart_total();		
		if($cart_total == 0){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);
		}
		$crtid = get_cart_id();
		$cart_single = Cart::where('crtid',$crtid)->first();
		
		$data = $this->common_data($page_slug);	
		$data['cart_single'] = $cart_single;
		//print_r($data['cart_single']->card_number);
				
		$shipadd = (isset($cart_single->shipadd))?$cart_single->shipadd:0;
		$billadd = (isset($cart_single->billadd))?$cart_single->billadd:0;
		
		$has_shipadd=DB::table('customer_address')->where('id', $shipadd)->first();
		$has_billadd=DB::table('customer_address')->where('id', $billadd)->first();		
		if(empty($has_shipadd) || empty($has_billadd)){
			$urls = url('/').'/'.get_page_url_by_id(8);
			return redirect($urls);				
		}		
		$paymentmethod = (isset($cart_single->paymentmethod))?$cart_single->paymentmethod:'';
		if($paymentmethod == 'cash'){
			if(empty($cart_single->card_number)){
				$urls = url('/').'/'.get_page_url_by_id(18);
				return redirect($urls);									
			}
		}
		if(empty($paymentmethod)){
			$urls = url('/').'/'.get_page_url_by_id(9);
			return redirect($urls);								
		}
		

		$data['shipadd'] = DB::table('customer_address')->where('id',$shipadd)->first();
		//$data['has_billadd'] = DB::table('customer_address')->where('id',$user_id)->first();
		
		$cart_products = get_cart_product();
		$data['total_cart_products'] = count($cart_products);
		$data['cart_products'] = $cart_products;
			
		$data['crtid'] = $crtid;
		$data['discount'] = (isset($cart_single->coup_disc))?$cart_single->coup_disc:'';
		$data['coupon_code'] = (isset($cart_single->coupon_code))?$cart_single->coupon_code:'';
		
		return view('summery')->with("data",$data);				
	}

	public function card_detail($page_slug){
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}			
		$cart_total = get_cart_total();		
		if($cart_total == 0){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);
		}
		$crtid = get_cart_id();
		$cart_single = Cart::where('crtid',$crtid)->first();
		
		$data = $this->common_data($page_slug);	
		$data['cart_single'] = $cart_single;
		//print_r($data['cart_single']->card_number);
				
		$shipadd = (isset($cart_single->shipadd))?$cart_single->shipadd:0;
		$billadd = (isset($cart_single->billadd))?$cart_single->billadd:0;
		
		$has_shipadd=DB::table('customer_address')->where('id', $shipadd)->first();
		$has_billadd=DB::table('customer_address')->where('id', $billadd)->first();		
		if(empty($has_shipadd) || empty($has_billadd)){
			$urls = url('/').'/'.get_page_url_by_id(8);
			return redirect($urls);				
		}		
		$paymentmethod = (isset($cart_single->paymentmethod))?$cart_single->paymentmethod:'';
		if($paymentmethod == 'cash'){
			//$urls = url('/').'/'.get_page_url_by_id(9);
			//return redirect($urls);					
		}
		
			
		$data['crtid'] = $crtid;
		$data['discount'] = (isset($cart_single->coup_disc))?$cart_single->coup_disc:'';
		$data['coupon_code'] = (isset($cart_single->coupon_code))?$cart_single->coupon_code:'';
		
		return view('carddetail')->with("data",$data);				
	}

	public function edit_address($id){
		$urls = url('/').'/'.get_page_url_by_id(17);
		return redirect($urls)->with(['tmpid'=>$id]);
	}
	
	public function delete_address($id){
		
		DB::table('customer_address')->where('id',$id)->delete();
		return redirect()->back();				
	}	

	public function payment_method($page_slug){
										
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}			
		$cart_total = get_cart_total();		
		if($cart_total == 0){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);			
		}
		$data = $this->common_data($page_slug);	

		$crtid = get_cart_id();			
		$cart_single = Cart::where('crtid',$crtid)->first();
		
		$shipadd = (isset($cart_single->shipadd))?$cart_single->shipadd:0;
		$billadd = (isset($cart_single->billadd))?$cart_single->billadd:0;
		
		$has_shipadd=DB::table('customer_address')->where('id', $shipadd)->first();
		$has_billadd=DB::table('customer_address')->where('id', $billadd)->first();		
		if(empty($has_shipadd) || empty($has_billadd)){
			$urls = url('/').'/'.get_page_url_by_id(8);
			return redirect($urls);				
		}
		
		
							
		$data['crtid'] = $crtid;
		$data['discount'] = (isset($cart_single->coup_disc))?$cart_single->coup_disc:'';
		$data['coupon_code'] = (isset($cart_single->coupon_code))?$cart_single->coupon_code:'';
				 												
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;						
		$data['user'] = DB::table('users')->select('*')->where('id',$user_id)->first();
												
		return view('paymentmethod')->with("data",$data);
	}


	public function shipping_billing_info($page_slug){
										
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}			
		$cart_total = get_cart_total();		
		if($cart_total == 0){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);			
		}
		$data = $this->common_data($page_slug);	

		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;						
		$data['user'] = DB::table('users')->select('*')->where('id',$user_id)->first();
		
		$crtid = get_cart_id();			
		$cart_single = Cart::where('crtid',$crtid)->first();							
		$data['crtid'] = $crtid;
		$data['discount'] = (isset($cart_single->coup_disc))?$cart_single->coup_disc:'';
		$data['coupon_code'] = (isset($cart_single->coupon_code))?$cart_single->coupon_code:'';

			
		$shipadd = (isset($cart_single->shipadd))?$cart_single->shipadd:'';
		$billadd = (isset($cart_single->billadd))?$cart_single->billadd:'';		

		$data['shipadd'] = $shipadd;
		$data['billadd'] = $billadd;
		
		$data['all_shipping'] = DB::table('customer_address')->where([['user_id','=',$user_id],['type','=','shipping']])->get();
		$data['all_billing'] = DB::table('customer_address')->where([['user_id','=',$user_id],['type','=','billing']])->get();

		//print_r($data['all_shipping']);

		
		$data['has_shipadd'] = DB::table('customer_address')->where([['user_id','=',$user_id],['type','=','shipping']])->first();
		$data['has_billadd'] = DB::table('customer_address')->where([['user_id','=',$user_id],['type','=','billing']])->first();
					
	/*
		if(!empty($has_shipadd) && !empty($has_billadd)){
			$data['shipadd'] = $shipadd;
			$data['billadd'] = $billadd;
							
		}*/				 																								
		return view('shippingbilling')->with("data",$data);
	}

	public function shipping_billing_cart_update(Request $request){
			
			$this->validate($request,[
				'shipadd' => 'required|max:250',
				'billadd' => 'required|max:250',
			], [], 
			[
				'shipadd' => 'Shipping Address',
				'billadd' => 'Billing Address',				
			]);
			
			$crtid = get_cart_id();
			Cart::where('crtid',$crtid)->first()->update(array('shipadd'=>$request->shipadd,'billadd'=>$request->billadd));			
			$urls = url('/').'/'.get_page_url_by_id(9);
			return redirect($urls);						
				
	}

	public function shipping_billing_delete(Request $request){
		  $sp_id = $request->sp_id;		
		  DB::table('customer_address')->where('id', $sp_id)->delete();		
		  $bl_id = $request->bl_id;		
		  DB::table('customer_address')->where('id', $bl_id)->delete();				  			  
		  $response = array(
			  'status' => 'Y',
		  );
		  return response()->json($response);		
	}

	public function shipping_billing_cart_add(Request $request){

		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;		
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}

		$this->validate($request, [
			'sp_fname' => 'required|max:250',
			'sp_lname' => 'required|max:250',
			'sp_phone_no' => 'required|digits:10',
			'sp_email' => 'required|email|max:250',
			'sp_address1' => 'required|max:250',
			'sp_city' => 'required|max:250',
			'sp_post_code' => 'required|max:250',
			'sp_state' => 'required|max:250',
			
			'bl_fname' => 'required|max:250',
			'bl_lname' => 'required|max:250',
			'bl_phone_no' => 'required|digits:10',
			'bl_email' => 'required|email|max:250',
			'bl_address1' => 'required|max:250',
			'bl_city' => 'required|max:250',
			'bl_post_code' => 'required|max:250',
			'bl_state' => 'required|max:250',			
		], [], 
		[
			'sp_fname' => 'First Name',
			'sp_lname' => 'Last Name',
			'sp_phone_no' => 'Phone No',
			'sp_email' => 'Email',
			'sp_address1' => 'Street Address',
			'sp_city' => 'City',
			'sp_post_code' => 'Post Code',
			'sp_state' => 'State',
			
			'bl_fname' => 'First Name',
			'bl_lname' => 'Last Name',
			'bl_phone_no' => 'Phone No',
			'bl_email' => 'Email',
			'bl_address1' => 'Street Address',
			'bl_city' => 'City',
			'bl_post_code' => 'Post Code',
			'bl_state' => 'State',						
		]);		

		$sp_fname = $request->sp_fname;
		$sp_lname = $request->sp_lname;
		$sp_email = $request->sp_email;
		$sp_phone_no = $request->sp_phone_no;
				
		$sp_address1 = $request->sp_address1;
		$sp_address2 = $request->sp_address2;
		$sp_city = $request->sp_city;
		$sp_post_code = $request->sp_post_code;		
		$sp_state = $request->sp_state;		
				
		$data = array('user_id'=>$user_id,'fname'=>$sp_fname,'lname'=>$sp_lname,'email'=>$sp_email
			,"phone_no"=>$sp_phone_no,"address1"=>$sp_address1,"address2"=>$sp_address2,
			"city"=>$sp_city,"state"=>$sp_state,"post_code"=>$sp_post_code,"type"=>'shipping');

		$insid = DB::table('customer_address')->insert($data);
		$sp_id = DB::getPdo()->lastInsertId();

		$bl_fname = $request->bl_fname;
		$bl_lname = $request->bl_lname;
		$bl_email = $request->bl_email;
		$bl_phone_no = $request->bl_phone_no;
		$bl_address1 = $request->bl_address1;
		$bl_address2 = $request->bl_address2;
		$bl_city = $request->bl_city;
		$bl_post_code = $request->bl_post_code;		
		$bl_state = $request->bl_state;

		$data = array('user_id'=>$user_id,'fname'=>$bl_fname,'lname'=>$bl_lname,'email'=>$bl_email
			,"phone_no"=>$bl_phone_no,"address1"=>$bl_address1,"address2"=>$bl_address2,"city"=>$bl_city,
			"state"=>$bl_state,"post_code"=>$bl_post_code,"type"=>'billing');			
		
		$insid = DB::table('customer_address')->insert($data);
		$bl_id = DB::getPdo()->lastInsertId();		
		
		$crtid = get_cart_id();
		
		Cart::where('crtid',$crtid)->first()->update(array('shipadd'=>$sp_id,'billadd'=>$bl_id));
		
		$urls = url('/').'/'.get_page_url_by_id(9);
		return redirect($urls);		
		
	}

	public function shipping_billing(Request $request){
		
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;		
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}		
		$user=DB::table('users')->select('*')->where('id',$user_id)->first();
		
		$sp_address1 = $request->sp_address1;
		$sp_address2 = $request->sp_address2;
		$sp_city = $request->sp_city;
		$sp_post_code = $request->sp_post_code;		
		$sp_state = $request->sp_state;		
		$sp_id = $request->sp_id;		
		$data = array('user_id'=>$user_id,'fname'=>$user->fname,'lname'=>$user->lname,'email'=>$user->email
			,"phone_no"=>$user->phone_no,"address1"=>$sp_address1,"address2"=>$sp_address2,"city"=>$sp_city,"state"=>$sp_state,"post_code"=>$sp_post_code,"type"=>'shipping');
		if($sp_id == 0){												
			$insid = DB::table('customer_address')->insert($data);
			$sp_id = DB::getPdo()->lastInsertId();	
		}else{
			DB::table('customer_address')->where('id',$sp_id)->update($data);
		}
				
		$bl_address1 = $request->bl_address1;
		$bl_address2 = $request->bl_address2;
		$bl_city = $request->bl_city;
		$bl_post_code = $request->bl_post_code;		
		$bl_state = $request->bl_state;		
		$bl_id = $request->bl_id;		
		$data = array('user_id'=>$user_id,'fname'=>$user->fname,'lname'=>$user->lname,'email'=>$user->email
			,"phone_no"=>$user->phone_no,"address1"=>$bl_address1,"address2"=>$bl_address2,"city"=>$bl_city,"state"=>$bl_state,"post_code"=>$bl_post_code,"type"=>'billing');			
		if($bl_id == 0){						
			$insid = DB::table('customer_address')->insert($data);
			$bl_id = DB::getPdo()->lastInsertId();	
		}else{
			DB::table('customer_address')->where('id',$bl_id)->update($data);
		}
						
		$id = (!empty($sp_id))?'shipping'.$sp_id:'billing'.$bl_id;
		return redirect()->back()->with(['tmpid'=>$id]);		
	}
	

	
	public function update_profile(Request $request){
		

		$this->validate($request, [
			'fname' => 'required|max:250',
			'lname' => 'required|max:250',
			'phone_no' => 'required|digits:10',
		], [], 
		[
			'fname' => 'First Name',
			'lname' => 'Last Name',
			'phone_no' => 'Phone No.',
		]);				
				
		
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;
		
		if($user_id){		
			$fname = $request->fname;
			$lname = $request->lname;
			$phone_no = $request->phone_no;			
			DB::table('users')->where('id',$user_id)->update(['fname' => $fname,'lname' => $lname,'phone_no' => $phone_no]);
		}
		
		return redirect()->back()->with(['success'=>'Your profile data successfully updated.']);
		
	}

	public function edit_profile($page_slug){
		
		
		$has_allow = must_login_front();
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}		
		$data = $this->common_data($page_slug);				
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;
		
		$all_shipping = DB::table('customer_address')->select('*')->where([['user_id','=',$user_id],['type','=','shipping']])->get();		
		$all_billing = DB::table('customer_address')->select('*')->where([['user_id','=',$user_id],['type','=','billing']])->get();
		
		$ship_bill_arr = array();		
		$all_shipping_cnt = count($all_shipping);
		$all_billing_cnt = count($all_billing);		
		$maxloop = ($all_shipping_cnt >= $all_billing_cnt)?$all_shipping:$all_billing;
				
		if(!empty($maxloop)){
		   foreach($maxloop as $key=>$ddt){
			   if($ddt->type == 'shipping'){
					$shp = $ddt; 
					$blp = (isset($all_billing[$key]))?$all_billing[$key]:'';  
			   }else{
					$blp = $ddt; 
					$shp = (isset($all_shipping[$key]))?$all_shipping[$key]:''; 				   
			   }
			   $ship_bill_arr[] = array('shipping'=>$shp,'billing'=>$blp);
		   }
		}		
		$data['ship_bill_arr']=$ship_bill_arr;		
		//print_r($ship_bill_arr);		
		$data['user'] = DB::table('users')->select('*')->where('id',$user_id)->first();								
		return view('editprofile')->with("data",$data);
	}

	public function cart($page_slug){
		$data = $this->common_data($page_slug);								
		
		$crtid = get_cart_id();
				
		/*$user_id = Auth::id();
		$user_id = ($user_id)?$user_id:0; 
		$ip = get_the_user_ip();				
		if($user_id){
			$cart = Cart::where('user_id',$user_id)->first();			
		}else{
			$cart = Cart::where('ip',$ip)->first();
		}
		$crtid = (isset($cart->crtid))?$cart->crtid:0;*/	
		
		$cart_single = Cart::where('crtid',$crtid)->first();					
		
		$data['crtid'] = $crtid;
		$data['discount'] = (isset($cart_single->coup_disc))?$cart_single->coup_disc:'';
		$data['coupon_code'] = (isset($cart_single->coupon_code))?$cart_single->coupon_code:'';
		 
		$cart_products = get_cart_product();	
			
		$data['total_cart_products'] = count($cart_products);
		$data['cart_products'] = $cart_products;		
				
		return view('cart')->with("data",$data);				
	}
	
	
	public function forgot_password($page_slug){
		$data = $this->common_data($page_slug);								
		return view('forgotpass')->with("data",$data);		
	}

	public function login_register($page_slug){
		$data = $this->common_data($page_slug);								
		return view('loginreg')->with("data",$data);
		
	}
	
	public function how_it_works($page_slug){
		$data = $this->common_data($page_slug);
		
		$data['how_it_content'] = DB::table('page_meta') 						          
						->select('*') 
						->where([['meta_key','=','how_it_content'],['pid','=',2]])           		            
						->orderby('field_order', 'desc')->get();		
		
		return view('howitworks')->with("data",$data);
		
	}
	
	public function products($page_slug){
		
		$limit = 4;		
		$data = $this->common_data($page_slug);		
		$data['color']    = Productattributesmodal::orderby('attr_order','desc')->where([['attr_type','=','color'],['attr_status','=',1]])->get();
		$data['brand']    = Productattributesmodal::orderby('attr_order','desc')->where([['attr_type','=','brand'],['attr_status','=',1]])->get();
		$data['type']     = Productattributesmodal::orderby('attr_order','desc')->where([['attr_type','=','type'],['attr_status','=',1]])->get();		
		
		$data['products'] = Products::where('pro_status',1)->orderby('pro_order','desc')->limit($limit)->get();
		
		$data['limit'] = $limit;
		
		/*$data['products'] = DB::table('products as pro')->select(array('d1.title AS level1', 'd2.title AS level2'))
    ->leftJoin('product_attributes AS pat', function($join) {
        $join->on('pat.attr_id', '=', 'pro.pro_brand');
        $join->where('t1.parent_type', '=', 'Destination');
    })where('pro_status',1)->orderby('pro_order','desc')->limit(6)->get();*/	
		
		//$products = $data['products'];			
		//$proddata = view('bags-list', compact('products'));
		
		//print_r($proddata);					
						
		return view('bags')->with("data",$data);
		
	}
	
	public function front($pageid=1){
		
		$data = $this->common_data();		
		$home_slider = DB::table('page_meta as pm')            
						->select('*') 
						->where([['pm.meta_key','=','home_slider'],['pm.pid','=',1]])           		            
						->orderby('field_order', 'desc')->get();
													
		$data['home_slider'] = $home_slider;
		$boxs = DB::table('page_meta')            
						->select('*') 
						->where([['meta_key','=','3box'],['pid','=',1]])           		            
						->orderby('field_order', 'desc')->first();							
		$data['boxs']=$boxs;		
		$cat_product = DB::table('page_meta as pm')          
						->select('*') 
						->where([['pm.meta_key','=','cat_product'],['pm.pid','=',1]])           		            
						->orderby('field_order', 'desc')->get();									
		$data['cat_product'] = $cat_product;		
		$brand_product = DB::table('page_meta as pm')            
						->select('*') 
						->where([['pm.meta_key','=','brand_product'],['pm.pid','=',1]])           		            
						->orderby('field_order', 'desc')->get();									
		$data['brand_product'] = $brand_product;
		$new_prod = DB::table('page_meta as pm') 
						 ->join('products as pro', function ($join) {
								$join->on('pm.pro_id', '=', 'pro.pro_id');						 
						})           
						->select('*') 
						->where([['pm.meta_key','=','new_prod'],['pm.pid','=',1]])           		            
						->orderby('field_order', 'desc')->get();									
		$data['new_prod'] = $new_prod;		
		
		
		
		return view('home')->with("data",$data);
	}
	
	public function common_data($pageslug=''){
		 $data = array();
		 if(!empty($pageslug)){
		 	$cmspage = Cmspage::where('page_slug',$pageslug)->first();
		 }else{
			$cmspage = Cmspage::where('id',1)->first(); 
		 }
		 $commonset = DB::table('setting_master')
                    ->whereIn('meta_key', ['site_name','site_logo','site_favicon_logo','copy_rights','instagram_link','facebook_link','linkedin_link'])
                    ->get();
		 if(!empty($commonset)){
			foreach($commonset as $set){
				$data[$set->meta_key] = $set->meta_value; 			
			}
		 }
		 $data['page_id'] = (isset($cmspage->id))?$cmspage->id:'';
		 $data['page_name'] = (isset($cmspage->page_name))?$cmspage->page_name:'';
		 $data['display_name'] = (isset($cmspage->display_name))?$cmspage->display_name:'';
		 $data['meta_title'] = (isset($cmspage->meta_title))?$cmspage->meta_title:'';
		 $data['meta_desc'] = (isset($cmspage->meta_desc))?$cmspage->meta_desc:'';
		 $data['meta_keyword'] = (isset($cmspage->meta_keyword))?$cmspage->meta_keyword:'';
		 $data['page_content'] = (isset($cmspage->page_content))?$cmspage->page_content:'';		 		  
		 $data['menutop'] = Menu::orderby('m_order','desc')->where('m_type','top')->get();
		 $data['menubottom'] = Menu::orderby('m_order','desc')->where('m_type','bottom')->get();		 		 
		 return $data;		 	
	}
	
}

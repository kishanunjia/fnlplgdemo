<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use File;
use App\adminpanel\Coupon;

class CouponController extends Controller{
    
	private $post_per_page=10;

	public function __construct(){
		$this->middleware('auth');
	}
	
	public function index(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Coupon';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$coupon=Coupon::orderby('coup_generate','desc')->paginate($postperpage, ['*'], 'page');
			$coupon->appends(request()->query())->links(); 											        		 		
			$data['coupon'] = $coupon;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		  return view('admin/coupon/list')->with("data",$data);						
	}		 

	public function search(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search=$request->search;	 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Coupon';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$coupon=Coupon::where('coup_code','LIKE','%'.$search.'%')->orWhere('coup_start_date','LIKE','%'.$search.'%')->orWhere('coup_end_date','LIKE','%'.$search.'%')->orderby('coup_generate','desc')->paginate($postperpage, ['*'], 'page');
			$coupon->appends(request()->query())->links(); 											        		 		
			$data['coupon'] = $coupon;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		  return view('admin/coupon/list')->with("data",$data);				
	}	


	public function withValidator($validator)
	{
		$validator->after(function ($validator) {
			if ($this->somethingElseIsInvalid()) {
				$validator->errors()->add('coup_val', 'The Coupon Discount field is required.');
			}
		});
	}

	public function delete(Request $request){
	  if($request->id){		  		  		  		  	
		  Coupon::where('coup_id',$request->id)->delete();			
	  }
	  return Redirect::route('coupon')->with('success', "Record Has Been Deleted Successfully.");		  
	}
	
	public function update(Request $request){		
		$coup_id = $request->input('coup_id');
		
        $coupn=Coupon::where([['coup_code','=',$request->coup_code],['coup_id','!=',$request->coup_id]])->first();
        if($coupn){
            return Redirect::back()->with('error', "Coupon Code already exits.");
        }		
		
		if(!empty($coup_id)){			
			$data = array(			  
			  'coup_code'=>$request->coup_code,		  			  
			  'coup_use'=>($request->coup_use)?$request->coup_use:0,
			  'coup_val'=>($request->coup_val)?$request->coup_val:0,
			  'coup_type'=>($request->coup_type)?$request->coup_type:'per',			  
			  'coup_status'=>$request->coup_status,			  			 
			);
			if((!empty($request->coup_start_date))){			
				$coup_start_date = $request->coup_start_date;
				$coup_start_date = date("Y-m-d", strtotime($coup_start_date));
				$data['coup_start_date'] = $coup_start_date;				
			}
			
			if((!empty($request->coup_end_date))){			
				$coup_end_date = $request->coup_end_date;
				$coup_end_date = date("Y-m-d", strtotime($coup_end_date));
				$data['coup_end_date'] = $coup_end_date;
			}											
			Coupon::where('coup_id',$coup_id)->first()->update($data);
			return Redirect::route('coupon')->with('success', "Record Has Been Updated Successfully.");						
		}
					
	}
	
	public function create(Request $request){
		
        $coupn=Coupon::where('coup_code',$request->coup_code)->first();
        if($coupn){
            return Redirect::back()->with('error', "Coupon Code already exits.");
        }	
		
		$coupon = new Coupon();
		
		$coupon->coup_code = $request->coup_code;
		
		$coupon->coup_use = $request->coup_use;
		
		$coupon->coup_val  = $request->coup_val;
		$coupon->coup_type = $request->coup_type;		
		if((!empty($request->coup_start_date))){			
			$coup_start_date = $request->coup_start_date;
			$coup_start_date = date("Y-m-d", strtotime($coup_start_date));
			$coupon->coup_start_date = $coup_start_date;
		}		
		if((!empty($request->coup_end_date))){			
			$coup_end_date = $request->coup_end_date;
			$coup_end_date = date("Y-m-d", strtotime($coup_end_date));
			$coupon->coup_end_date = $coup_end_date;
		}		
		$coupon->coup_status = $request->coup_status;						
		$coupon->save();		
		return Redirect::route('coupon')->with('success', "Record Has Been Added Successfully."); 		
	}

	public function edit($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Coupon';
		 $data['dbname'] = 'coupon';		 		 		 
		 $data['back_router'] = 'coupon';
		 		 	 		 		 		 		 		 
		 $results=DB::table('coupon')->where('coup_id',$id)->first();		 
		 $data['atdata'] = $results;
		 		 		 		 		 		 		 		 		 	 		 		 
		 return view('admin/coupon/edit')->with("data",$data);
		 
	}
	
	public function add(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Coupon';
		 $data['dbname'] = 'coupon';		 		 		 
		 $data['back_router'] = 'coupon';		 				 		 	 		 		 		 
		 return view('admin/coupon/add')->with("data",$data);		 		  
	}
	 
	
}

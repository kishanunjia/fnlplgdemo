<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use File;
use App\adminpanel\Menu;
use App\adminpanel\Cmspage;

class MenuController extends Controller
{
    private $post_per_page = 10;
			
	public function __construct(){
		$this->middleware('auth');
	}

	public function index(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Menu';		 
			$data['edit_link'] = '';					 			 		 		 		 			 			
			
			$menutop=Menu::orderby('m_order','desc')->where('m_type','top')->paginate($postperpage, ['*'], 'page');
			$menutop->appends(request()->query())->links();
						 											        		 		
			$data['menutop'] = $menutop;									
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;
							 		 		 	 		 		 		
		  return view('admin/menu/list')->with("data",$data);						
	}
	
	public function bottommenu(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Menu';		 
			$data['edit_link'] = '';					 			 		 		 		 			 			
			
			$menutop=Menu::orderby('m_order','desc')->where('m_type','bottom')->paginate($postperpage, ['*'], 'page');
			$menutop->appends(request()->query())->links();
						 											        		 		
			$data['menutop'] = $menutop;									
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;
							 		 		 	 		 		 		
		  return view('admin/menu/bottomlist')->with("data",$data);						
	}	

	public function addbottommenu(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Bottom Menu';
		 $data['dbname'] = 'bottom';		 		 		 
		 $data['back_router'] = 'bottommenu';		 		 
		 $menus = Menu::where('m_type','bottom')->orderby('m_order','desc')->get();		 
		 $pages = Cmspage::where('page_status',1)->orderby('page_order','desc')->get();		 		 		 
		 $data['pages'] = $pages;
		 $data['menus'] = $menus;		 
		 return view('admin/menu/bottomadd')->with("data",$data);		 		  
	}

	public function editbottommenu($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Bottom Menu';
		 $data['dbname'] = 'bottom';		 		 		 
		 $data['back_router'] = 'bottommenu';
		 		 		 	 		 		 		 		 		 
		 $results=DB::table('menu_manage')->where('m_id',$id)->first();		 
		 $data['mdata'] = $results;

		 $menus = Menu::where('m_type','bottom')->orderby('m_order','desc')->get();		 
		 $pages = Cmspage::where('page_status',1)->orderby('page_order','desc')->get();		 		 		 
		 $data['pages'] = $pages;
		 $data['menus'] = $menus;		 
		 		 		 		 		 		 		 		 		 	 		 		 
		 return view('admin/menu/bottomedit')->with("data",$data);
		 
	}


	public function update(Request $request){		
		$m_id = $request->input('m_id');
		if(!empty($m_id)){						
			$data = array(			  
			  'm_name'=>$request->m_name,
			  'pid'=>$request->pid,			  		  			  			  		  
			  'mpid'=>$request->mpid,
			  'm_url'=>(!empty($request->m_url))?$request->m_url:'',			  			  
			  'm_target'=>(!empty($request->m_target))?$request->m_target:'',			  
			  'm_status'=>$request->m_status,			  
			  'm_type'=>$request->m_type,			  			 
			);									
			Menu::where('m_id',$m_id)->first()->update($data);	
			if($request->m_type == 'bottom'){
				return Redirect::route('bottommenu')->with('success', "Record Has Been Updated Successfully."); 		
			}else{
				return Redirect::route('menu')->with('success', "Record Has Been Updated Successfully.");	 		
			}					
								
		}					
	}

	public function bottomdelete(Request $request){
	  if($request->id){		  		  		  		  	
		  Menu::where('m_id',$request->id)->delete();			
	  }
	  return Redirect::route('bottommenu')->with('success', "Record Has Been Deleted Successfully.");		  
	}

	public function delete(Request $request){
	  if($request->id){		  		  		  		  	
		  Menu::where('m_id',$request->id)->delete();			
	  }
	  return Redirect::route('menu')->with('success', "Record Has Been Deleted Successfully.");		  
	}
	
	public function create(Request $request){		
		$menu = new Menu();		
		$menu->m_name = $request->m_name;					    
		$m_order = 0;		
		$first_rec = DB::table('menu_manage')            
		->select('*')            		           
		->orderby('m_order', 'desc')->first();						
		if(!empty($first_rec)){
			$m_order = $first_rec->m_order;	
		}
								
		$m_order = $m_order + 1;				
		$menu->pid = $request->pid;				
		$menu->m_url = (!empty($request->m_url))?$request->m_url:'';		
		$menu->m_target = (!empty($request->m_target))?$request->m_target:'';						
		$menu->mpid = $request->mpid;				
		$menu->m_order = $m_order;										
		$menu->m_type = $request->m_type;				
		$menu->m_status = $request->m_status;								
		$menu->save();
		if($menu->m_type == 'bottom'){
			return Redirect::route('bottommenu')->with('success', "Record Has Been Added Successfully."); 		
		}else{
			return Redirect::route('menu')->with('success', "Record Has Been Added Successfully."); 		
		}
	}	

	public function edit($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Top Menu';
		 $data['dbname'] = 'top';		 		 		 
		 $data['back_router'] = 'menu';
		 		 		 	 		 		 		 		 		 
		 $results=DB::table('menu_manage')->where('m_id',$id)->first();		 
		 $data['mdata'] = $results;

		 $menus = Menu::where('m_type','top')->orderby('m_order','desc')->get();		 
		 $pages = Cmspage::where('page_status',1)->orderby('page_order','desc')->get();		 		 		 
		 $data['pages'] = $pages;
		 $data['menus'] = $menus;		 
		 		 		 		 		 		 		 		 		 	 		 		 
		 return view('admin/menu/edit')->with("data",$data);
		 
	}
	
	public function add(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Top Menu';
		 $data['dbname'] = 'top';		 		 		 
		 $data['back_router'] = 'menu';		 		 
		 $menus = Menu::where('m_type','top')->orderby('m_order','desc')->get();		 
		 $pages = Cmspage::where('page_status',1)->orderby('page_order','desc')->get();		 		 		 
		 $data['pages'] = $pages;
		 $data['menus'] = $menus;		 
		 return view('admin/menu/add')->with("data",$data);		 		  
	}		
	
}

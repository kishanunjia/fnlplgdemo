<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use App\adminpanel\Productattributes;
use Auth;
use DB;
use File;


class AjaxController extends Controller{
    
	  public function __construct(){
		 $this->middleware('auth');
	  }
	  
	  public function update_menu_order(Request $request){
		  
		  	  $table = $request->table;
			  $order = $request->order;
			  $id = $request->id;
			  
			  $orderdata = $request->orderdata;			  	  
			  if(!empty($orderdata)){
				 
				 $menu_order_arr = array();
				 foreach($orderdata as $davl){ 				  				  
				  $results=DB::table($table)->where($id,$davl)->first();
				  if(isset($results->$order)){
					 $menu_order_arr[] = $results->$order;
				  }
				 }				  
				 sort($menu_order_arr);
				 $menu_order_arr = array_reverse($menu_order_arr);
				 				   
				 foreach($orderdata as $position=>$davl){ 				  				  				 											
					DB::table($table)->where($id,$davl)->limit(1)->update([$order => $menu_order_arr[$position]]);
				 }
				  
			  }
			  
				
			  $response = array(
				  'status' => 'success',
				  'msg' => $request->table,
			  );
			  return response()->json($response); 		  
		  
	  }
	
	
}

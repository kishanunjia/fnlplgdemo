<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use File;
use App\adminpanel\Productcategory;

class ProductcategoryController extends Controller{
	
    private $post_per_page = 10;
			
	public function __construct(){
		$this->middleware('auth');
	}
	
	public function index(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Categories';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$categories=Productcategory::orderby('corder','desc')->paginate($postperpage, ['*'], 'page');
			$categories->appends(request()->query())->links(); 											        		 		
			$data['categories'] = $categories;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		  return view('admin/categories/list')->with("data",$data);						
	}


	public function search(Request $request){		
		 
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search=$request->search;		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Categories';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			
			$categories=Productcategory::orderby('corder','desc')->where('cname','LIKE','%'.$search.'%')->paginate($postperpage, ['*'], 'page');
			$categories->appends(request()->query())->links();
											        		 		
			$data['categories'] = $categories;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		 return view('admin/categories/list')->with("data",$data);
		  						
	}

	public function edit($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Categories';
		 $data['dbname'] = 'categories';		 		 		 
		 $data['back_router'] = 'categories';		 		 	 		 		 		 		 		 
		 $results=DB::table('product_category')->where('cid',$id)->first();		 
		 $data['cdata'] = $results;
		 $categories = Productcategory::orderby('corder','desc')->get();
		 //print_r($categories);
		 //die;
		 
		 $data['categories'] = $categories; 		 		 		 		 		 		 		 		 	 		 		 
		 return view('admin/categories/edit')->with("data",$data);
		 
	}


	public function update(Request $request){		
		$id = $request->input('cid');
		if(!empty($id)){						
			$data = array(			  
			  'cname'=>$request->cname,
			  'pcid'=>$request->pcid,		  			  			  		  
			  'cstatus'=>$request->cstatus,			  			 
			);									
			productcategory::where('cid',$id)->first()->update($data);			
			return Redirect::route('categories')->with('success', "Record Has Been Updated Successfully.");						
		}					
	}
	
	public function add(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Categories';
		 $data['dbname'] = 'categories';		 		 		 
		 $data['back_router'] = 'categories';
		 $categories = Productcategory::orderby('corder','desc')->get();
		 //print_r($categories);
		 //die;
		 
		 $data['categories'] = $categories; 	 				 		 	 		 		 		 
		 return view('admin/categories/add')->with("data",$data);		 		  
	}
	
	public function create(Request $request){
		
		$productcategory = new Productcategory();
		$productcategory->cname = $request->cname;		
	    $corder = 0;		
		$first_rec = DB::table('product_category')            
		->select('*')            		           
		->orderby('corder', 'desc')->first();						
		if(!empty($first_rec)){
			$corder = $first_rec->corder;	
		}		
		$corder = $corder + 1;
		$productcategory->corder = $corder;		
		$productcategory->cstatus = $request->cstatus;
		
		$productcategory->pcid = $request->pcid;
				
		$productcategory->save();
		
		return Redirect::route('categories')->with('success', "Record Has Been Added Successfully."); 
		
	}
	
	public function delete(Request $request){
	  if($request->cid){		  		  		  		  	
		  Productcategory::where('cid',$request->cid)->delete();			
	  }
	  return Redirect::route('categories')->with('success', "Record Has Been Deleted Successfully.");		  
	}				
   
}

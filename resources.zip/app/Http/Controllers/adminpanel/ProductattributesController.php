<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use App\adminpanel\Productattributes;
use Auth;
use DB;
use File;

use App\adminpanel\Productattributesmodal;

class ProductattributesController extends Controller
{
	 private $post_per_page=5;

	  public function __construct(){
		 $this->middleware('auth');
	  }
	  
	  public function index(){		       		 	 
		 $data = array();			 
		 $data['color'] = Productattributesmodal::get_attribute('color');		 		 	 		 		 
		 return view('admin/product_attributes/productattributes')->with("data",$data);		 
	  }
	 

	  public function manage_type(Request $request){		  
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Type';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$manaedata=Productattributesmodal::orderby('attr_order','desc')->where('attr_type','type')->paginate($postperpage, ['*'], 'page');
			$manaedata->appends(request()->query())->links(); 								        		 		
			$data['branddata'] = $manaedata;			
			$data['search'] = $search;
			$data['postperpage'] = $postperpage;		 		 		 	 		 		 		
		    return view('admin/product_attributes/typemanage')->with("data",$data);			 		 	 		  
	  }


	  public function search_type(Request $request){	
	         $data = array();			
			 $postperpage=$this->post_per_page;
			 $search=$request->search;
			 if($request->postperpage){$postperpage=$request->postperpage;}		  
			 $manaedata = Productattributesmodal::where('attr_name','LIKE','%'.$search.'%')->orderby('attr_id','desc')->where('attr_type','type')->paginate($postperpage, ['*'], 'page');
			 $manaedata->appends(request()->query())->links();						
			 $data['attrname'] = 'Type';		 
			 $data['edit_link'] = '';		 			 		 		 		 
			 	 
			 $data['branddata'] = $manaedata;
			 $data['search'] = $search;
			 $data['postperpage'] = $postperpage;			
			 						
			 return view('admin/product_attributes/typemanage')->with("data",$data);	
									
	  }
	  
	  public function add_type(){	  
		 		  
		 $data = array();			 
		 $data['attrname'] = 'Type';
		 $data['dbname'] = 'type';		 
		 $data['add_router'] = 'save_attribute';		 
		 $data['back_router'] = 'manage_type';		 				 		 	 		 		 
		 return view('admin/product_attributes/addtype')->with("data",$data);		 		  
	  }	
	  
	  public function create_type(Request $request){	
	   		
			
        $attr_name = $request->input('attr_name');
        $attr_status = $request->input('attr_status');
		$attr_type = $request->input('attr_type');

	    $attr_order = 0;		
		$first_rec = DB::table('product_attributes')            
		->select('*')            
		->where('attr_type',$attr_type)            
		->orderby('attr_order', 'desc')->first();
				
		if(!empty($first_rec)){
			$attr_order = $first_rec->attr_order;	
		}
				
		$attr_order=$attr_order+1;								
		$data = array('attr_name'=>$attr_name,"attr_type"=>$attr_type,"attr_status"=>$attr_status,"attr_order"=>$attr_order);					
		DB::table('product_attributes')->insert($data);
	  	
		return Redirect::route('manage_type')->with('success', "Record Has Been Added Successfully."); 
			  
	  }	
	  
	  
	  public function edit_type($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Type';
		 $data['dbname'] = 'type';		 		 
		 $data['back_router'] = 'manage_type';
		 		 		 		 
		 $results=DB::table('product_attributes')->where('attr_id',$id)->first();		 
		 $data['atdata'] = $results;		 
		 		 		 	 		 		 
		 return view('admin/product_attributes/edittype')->with("data",$data);
		 		 		  		  
	  }	     

	  public function update_type(Request $request){				
		 $attr_id = $request->input('attr_id');
		 if(!empty($attr_id)){						
			DB::table('product_attributes')->where('attr_id',$attr_id)->update(['attr_name' => $request->attr_name,'attr_status' => $request->attr_status]);	
			return Redirect::route('manage_type')->with('success', "Record Has Been Updated Successfully."); 			
		 }
								  
	  }

	  public function type_delete(Request $request){
		  if($request->attr_id){		  		  	
			  Productattributesmodal::orderby('attr_order','desc')->where('attr_id',$request->attr_id)->delete();			
		  }
		  return Redirect::route('manage_type')->with('success', "Record Has Been Deleted Successfully.");		  
	  }
	  

	  public function manage_brand(Request $request){		  
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Brand';		 
			$data['edit_link'] = '';
					 			 		 		 		 			 
			$manaedata=Productattributesmodal::orderby('attr_order','desc')->where('attr_type','brand')->paginate($postperpage, ['*'], 'page');
			$manaedata->appends(request()->query())->links(); 
			
			//print_r($manaedata);
					        		 		
			$data['branddata'] = $manaedata;
			
			$data['search'] = $search;
			$data['postperpage'] = $postperpage;		 		 		 	 		 		 
		
		return view('admin/product_attributes/brandmanage')->with("data",$data);	
		 
		 	 		  
	  }

	  public function search_brand(Request $request){	
	         $data = array();			
			 $postperpage=$this->post_per_page;
			 $search=$request->search;
			 if($request->postperpage){$postperpage=$request->postperpage;}		  
			 $manaedata = Productattributesmodal::where('attr_name','LIKE','%'.$search.'%')->orderby('attr_id','desc')->where('attr_type','brand')->paginate($postperpage, ['*'], 'page');
			 $manaedata->appends(request()->query())->links();						
			 $data['attrname'] = 'Brand';		 
			 $data['edit_link'] = '';		 			 		 		 		 
			 	 
			 $data['branddata'] = $manaedata;
			 $data['search'] = $search;
			 $data['postperpage'] = $postperpage;			
			 						
			 return view('admin/product_attributes/brandmanage')->with("data",$data);	
									
	  }
	  
	  public function add_brand(){	  
		 		  
		 $data = array();			 
		 $data['attrname'] = 'Brand';
		 $data['dbname'] = 'brand';
		 
		 $data['add_router'] = 'save_attribute';		 
		 $data['back_router'] = 'manage_brand';
		 
		 $data['color'] = Productattributesmodal::get_attribute('color');		 		 	 		 		 
		 return view('admin/product_attributes/addbrand')->with("data",$data);		 		  
	  }	  

	  public function create_brand(Request $request){	
	   		
			
        $attr_name = $request->input('attr_name');
        $attr_status = $request->input('attr_status');
		$attr_type = $request->input('attr_type');

	    $attr_order = 0;		
		$first_rec = DB::table('product_attributes')            
		->select('*')            
		->where('attr_type',$attr_type)            
		->orderby('attr_order', 'desc')->first();
				
		if(!empty($first_rec)){
			$attr_order = $first_rec->attr_order;	
		}
		
		$attr_order=$attr_order+1;
								
		$data = array('attr_name'=>$attr_name,"attr_type"=>$attr_type,"attr_status"=>$attr_status,"attr_order"=>$attr_order);					
		DB::table('product_attributes')->insert($data);
	  	
		return Redirect::route('manage_brand')->with('success', "Record Has Been Added Successfully."); 
	  
	  }

	  public function edit_brand($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Brand';
		 $data['dbname'] = 'brand';		 		 
		 $data['back_router'] = 'manage_brand';
		 
		 
		 		 
		 $results=DB::table('product_attributes')->where('attr_id',$id)->first();		 
		 $data['atdata'] = $results;		 
		 $data['color'] = Productattributesmodal::get_attribute('color');		 		 	 		 		 
		 return view('admin/product_attributes/editbrand')->with("data",$data);
		 		 
		  		  
	  }	
	  
	  public function update_brand(Request $request){				
		 $attr_id = $request->input('attr_id');
		 if(!empty($attr_id)){			
			
			DB::table('product_attributes')->where('attr_id',$attr_id)->update(['attr_name' => $request->attr_name,'attr_status' => $request->attr_status]);	
			return Redirect::route('manage_brand')->with('success', "Record Has Been Updated Successfully."); 
			
		 }
								  
	  }	  

	  public function brand_delete(Request $request){
		  if($request->attr_id){		  		  	
			  Productattributesmodal::orderby('attr_order','desc')->where('attr_id',$request->attr_id)->delete();			
		  }
		  return Redirect::route('manage_brand')->with('success', "Record Has Been Deleted Successfully.");		  
	  }
	   
 	   
	    
	  
	  public function manage_color(Request $request){		  
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}
		 //$architechs=Architech::orderby('id','desc')->paginate($postperpage, ['*'], 'page');
		 
		$data['attrname'] = 'Color';		 
		$data['edit_link'] = '/adminpanel/edit-color/';		 			 		 		 		 
		//$data['color'] = Productattributesmodal::get_attribute('color',$postperpage);		 
		$manaedata=Productattributesmodal::orderby('attr_order','desc')->where('attr_type','color')->paginate($postperpage, ['*'], 'page');
        $manaedata->appends(request()->query())->links(); 		        		 		
		$data['architechs'] = $manaedata;
		$data['search'] = $search;
		$data['postperpage'] = $postperpage;		 		 		 	 		 		 
		return view('admin/product_attributes/manage')->with("data",$data);	
		 
		 	 		  
	  }
	  
	  public function delete(Request $request){
		  if($request->attr_id){		  		  	
			Productattributesmodal::orderby('attr_order','desc')->where('attr_id',$request->attr_id)->delete();			
		  }
		  return Redirect::route('manage_color')->with('success', "Record Has Been Deleted Successfully."); 
		  
	  }
	  
	  public function search(Request $request){	
	         $data = array();			
			 $postperpage=$this->post_per_page;
			 $search=$request->search;
			 if($request->postperpage){$postperpage=$request->postperpage;}		  
			 $manaedata = Productattributesmodal::where('attr_name','LIKE','%'.$search.'%')->orderby('attr_id','desc')->where('attr_type','color')->paginate($postperpage, ['*'], 'page');
			 $manaedata->appends(request()->query())->links();						
			 $data['attrname'] = 'Color';		 
			 $data['edit_link'] = '/adminpanel/edit-color/';		 			 		 		 		 
			 //$data['color'] = Productattributesmodal::get_attribute('color',$postperpage);		 
			 $data['architechs'] = $manaedata;
			 $data['search'] = $search;
			 $data['postperpage'] = $postperpage;			
			 						
			 return view('admin/product_attributes/manage')->with("data",$data);
									
	  } 	  
	  
	  public function add_color(){	  
		 		  
		 $data = array();			 
		 $data['attrname'] = 'Color';
		 $data['dbname'] = 'color';
		 
		 $data['add_router'] = 'save_attribute';
		 
		 $data['back_router'] = 'manage_color';
		 
		 $data['color'] = Productattributesmodal::get_attribute('color');		 		 	 		 		 
		 return view('admin/product_attributes/addcolor')->with("data",$data);		 		  
	  }	  

	  public function edit_color($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Color';
		 $data['dbname'] = 'color';
		 
		 $data['edit_router'] = 'edit_attribute';
		 $data['back_router'] = 'manage_color';
		 
		 
		 
		 $results=DB::table('product_attributes')->where('attr_id',$id)->first();
		 
		 $data['atdata'] = $results;
		 
		 $data['color'] = Productattributesmodal::get_attribute('color');		 		 	 		 		 
		 return view('admin/product_attributes/editcolor')->with("data",$data);
		 		 
		  		  
	  }
	  

	  
	  public function edit_attribute(Request $request){				
		$attr_id = $request->input('attr_id');
		if(!empty($attr_id)){
			
			DB::table('product_attributes')->where('attr_id',$attr_id)->update(['attr_name' => $request->attr_name,'attr_status' => $request->attr_status,'attr_type' => $request->attr_type]);	
			return Redirect::route('manage_color')->with('success', "Record Has Been Updated Successfully."); 
		}
		
		
				  
	  }

	  
	  public function save_attribute(Request $request){	
	   		
			
        $attr_name = $request->input('attr_name');
        $attr_status = $request->input('attr_status');
		$attr_type = $request->input('attr_type');

	    $attr_order = 0;		
		$first_rec = DB::table('product_attributes')            
		->select('*')            
		->where('attr_type',$attr_type)            
		->orderby('attr_order', 'desc')->first();
				
		if(!empty($first_rec)){
			$attr_order = $first_rec->attr_order;	
		}
		
		$attr_order=$attr_order+1;
								
		$data = array('attr_name'=>$attr_name,"attr_type"=>$attr_type,"attr_status"=>$attr_status,"attr_order"=>$attr_order);					
		DB::table('product_attributes')->insert($data);
	  	
		return Redirect::route('manage_color')->with('success', "Record Has Been Added Successfully."); 
	  
	  }
	  
	  
	  
}

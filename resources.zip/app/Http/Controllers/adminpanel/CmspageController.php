<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use Validator,Redirect,Response;
use Auth;
use DB;
use File;
use App\adminpanel\Cmspage;
use App\adminpanel\Products;

class CmspageController extends Controller
{
    private $post_per_page = 20;
			
	public function __construct(){
		$this->middleware('auth');
	}
	
	public function index(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search='';		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Page';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$cmspage=Cmspage::orderby('page_order','desc')->paginate($postperpage, ['*'], 'page');
			$cmspage->appends(request()->query())->links(); 											        		 		
			$data['cmspage'] = $cmspage;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		  return view('admin/cmspage/list')->with("data",$data);						
	}


	public function delete(Request $request){
	  if($request->id){		  		  		  		  	
		  Cmspage::where('id',$request->id)->delete();			
	  }
	  return Redirect::route('cmspage')->with('success', "Record Has Been Deleted Successfully.");		  
	}
	
	public function search(Request $request){		
		 $data = array();			 
		 $postperpage=$this->post_per_page; $search=$request->search;		 
		 if($request->postperpage){$postperpage=$request->postperpage;}		 
			$data['attrname'] = 'Page';		 
			$data['edit_link'] = '';					 			 		 		 		 			 
			$cmspage = Cmspage::orderby('page_order','desc')->paginate($postperpage, ['*'], 'page');						
			$cmspage = Cmspage::where('page_name','LIKE','%'.$search.'%')->orderby('page_order','desc')->paginate($postperpage, ['*'], 'page');
			$cmspage->appends(request()->query())->links(); 											        		 		
			$data['cmspage'] = $cmspage;						
			$data['search'] = $search;			
			$data['postperpage'] = $postperpage;				 		 		 	 		 		 		
		  return view('admin/cmspage/list')->with("data",$data);						
	}	

	public function get_brand_prod(Request $request){
		
		$bid = $request->bid;
		$data = '';		
		if(!empty($bid)){
		     $products = Products::where([['pro_status','=',1],['pro_brand','=',$bid]])->get();
			if(!empty($products)){
				foreach($products as $pro){
					$data.= '<option value="'.$pro->pro_id.'">'.$pro->pro_name.'</option>';	
				}
			}
		}
		$response = array(
			  'status' => 1,
			  'data' => $data,			 
		);
		return response()->json($response);		
		
	}

	public function get_cat_prod(Request $request){
		
		$cid = $request->cid;
		$data = '';		
		if(!empty($cid)){
		     $products = DB::table('products as pro')
			 ->join('pro_cat_rel as prel', function ($join) {
					$join->on('prel.pro_id', '=', 'pro.pro_id');						 
				})								
			->select(array('pro.*', 'prel.pro_id', 'prel.cid'))
			->where('pro.pro_status', '=', 1)->where('prel.cid', '=', $cid)										
			->orderby('pro.pro_order', 'desc')
			->get();
			if(!empty($products)){
				foreach($products as $pro){
					$data.= '<option value="'.$pro->pro_id.'">'.$pro->pro_name.'</option>';	
				}
			}
		}
		$response = array(
			  'status' => 1,
			  'data' => $data,			 
		);
		return response()->json($response);		
		
	}
	
	public function deletemeta(Request $request){
		
		$mid = $request->mid;		
		DB::table('page_meta')->where('mid', $mid)->delete();
		$response = array(
			  'status' => 1,
			  'data' => 'success',			 
		);
		return response()->json($response);		
		
	}
	
	public function editmeta(Request $request){
		
		$pid = $request->input('pid');
		$field_type = $request->input('field_type');
		$meta_key = $request->input('meta_key');		
		$mid = $request->input('mid');
		$insid = 0;
		$imgid='';
		$imgsrc='';
		$loptitle = '';
		$ico1 = '';
		$ico2 = '';
		$ico3 = '';
		//$baseurll= URL::to('/');
		$baseurll= '';
		if($meta_key == 'how_it_content'){
			$svg_code = $request->input('svg_code');
			$field_title = $request->input('field_title');
			$field_detail = $request->input('field_detail');			
			$meta_value = $svg_code.':::@@'.$field_title.':::@@'.$field_detail;						
			$insid = DB::table('page_meta')->where('mid',$mid)->update(['meta_value' => $meta_value]);	
			$loptitle = $field_title;			
			
		}
		//brand_product
		
		if($meta_key == '3box'){
			$txt1  = $request->input('txt1');
			$txt2  = $request->input('txt2');			
			$txt3  = $request->input('txt3');			
			
			
			
			
			$oldico1  = $request->input('oldico1');
			$ico1     = $oldico1;
			if($request->hasFile('ico1')){
				if($request->file('ico1')->isValid()){																							
					if(!empty($oldico1)){
						File::delete(public_path('images/').$oldico1);
					}										
					$file = $request->file('ico1');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('images/'),$name);
					$ico1 = $name;																								
				}			
			}
			$oldico2  = $request->input('oldico2');
			$ico2     = $oldico2;
			if($request->hasFile('ico2')){
				if($request->file('ico2')->isValid()){																							
					if(!empty($oldico2)){
						File::delete(public_path('images/').$oldico2);
					}										
					$file = $request->file('ico2');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('images/'),$name);
					$ico2 = $name;																								
				}			
			}
			$oldico3  = $request->input('oldico3');
			$ico3     = $oldico3;
			if($request->hasFile('ico3')){
				if($request->file('ico3')->isValid()){																							
					if(!empty($oldico3)){
						File::delete(public_path('images/').$oldico3);
					}										
					$file = $request->file('ico3');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('images/'),$name);
					$ico3 = $name;																								
				}			
			}									
			
			$meta_value = $ico1.':::@@'.$txt1.',,'.$ico2.':::@@'.$txt2.',,'.$ico3.':::@@'.$txt3;
			$insid = DB::table('page_meta')->where('mid',$mid)->update(['meta_value' => $meta_value]);
			
		}
		
		if($meta_key == 'brand_product'){
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');			
			$imgold  = $request->input('imgold');
			
			$tagcat  = $request->input('tagcat');
			
			$updarr=array();
			$updarr['meta_value'] = $caption;
			$updarr['btxt'] = $bttxt;
			$updarr['pro_id'] = $tagpro;
			$updarr['cid'] = $tagcat;
			//tagcat
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
										
					if(!empty($imgold)){
						File::delete(public_path('products/').$imgold);
					}					
					
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;
					$updarr['img'] = $imgs;
					$imgsrc = $baseurll."/products/".$imgs;
					$imgid = $imgs;																					
				}			
			}			
			$meta_value = $caption;
			
			$insid = DB::table('page_meta')->where('mid',$mid)->update($updarr);
			 $loptitle = $caption;
			 if(!empty($loptitle)){
				$loptitle = strip_tags($loptitle);
				$loptitle = (strlen($loptitle) > 35) ? substr($loptitle,0,35).'...' : $loptitle;
			 }					
			
						
		}

		if($meta_key == 'cat_product'){
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');			
			$imgold  = $request->input('imgold');
			
			$tagcat  = $request->input('tagcat');
			
			$updarr=array();
			$updarr['meta_value'] = $caption;
			$updarr['btxt'] = $bttxt;
			$updarr['pro_id'] = $tagpro;
			$updarr['cid'] = $tagcat;
			//tagcat
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
										
					if(!empty($imgold)){
						File::delete(public_path('products/').$imgold);
					}					
					
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;
					$updarr['img'] = $imgs;
					$imgsrc = $baseurll."/products/".$imgs;
					$imgid = $imgs;																					
				}			
			}			
			$meta_value = $caption;
			
			$insid = DB::table('page_meta')->where('mid',$mid)->update($updarr);
			 $loptitle = $caption;
			 if(!empty($loptitle)){
				$loptitle = strip_tags($loptitle);
				$loptitle = (strlen($loptitle) > 35) ? substr($loptitle,0,35).'...' : $loptitle;
			 }					
			
						
		}

		if($meta_key == 'home_slider'){
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');			
			$imgold  = $request->input('imgold');
			
			$updarr=array();
			$updarr['meta_value'] = $caption;
			$updarr['btxt'] = $bttxt;
			$updarr['pro_id'] = $tagpro;
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
										
					if(!empty($imgold)){
						File::delete(public_path('products/').$imgold);
					}					
					
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;
					$updarr['img'] = $imgs;
					$imgsrc = $baseurll."/products/".$imgs;
					$imgid = $imgs;																					
				}			
			}			
			$meta_value = $caption;
			
			$insid = DB::table('page_meta')->where('mid',$mid)->update($updarr);
			 $loptitle = $caption;
			 if(!empty($loptitle)){
				$loptitle = strip_tags($loptitle);
				$loptitle = (strlen($loptitle) > 35) ? substr($loptitle,0,35).'...' : $loptitle;
			 }					
			
						
		}
		if($meta_key == 'new_prod'){
			$tagpro  = $request->input('tagpro');
			$bttxt   = (!empty($tagpro))?get_product_name_by_id($tagpro):'';
			$updarr=array();
			$updarr['meta_value'] = $tagpro;			
			$updarr['pro_id'] = $tagpro;
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){																							
					if(!empty($imgold)){
						File::delete(public_path('products/').$imgold);
					}										
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;
					$updarr['img'] = $imgs;
					$imgsrc = $baseurll."/products/".$imgs;
					$imgid = $imgs;																					
				}			
			}
			$insid = DB::table('page_meta')->where('mid',$mid)->update($updarr);
			$loptitle = (!empty($tagpro))?get_product_name_by_id($tagpro):'';											
			
		}
		$response = array(
			  'status' => 1,
			  'imgsrc' => $imgsrc,
			  'imgid' => $imgid,
			  'loptitle' => $loptitle,
			  
			  'ico1' => $ico1,
			  'ico2' => $ico2,
			  'ico3' => $ico3,
			  
			  'data' => 'success',			 
		);
		return response()->json($response);				
		
		
	}
	
	
	public function addmeta(Request $request){
		
		$pid = $request->input('pid');
		$field_type = $request->input('field_type');
		$meta_key = $request->input('meta_key');
		$insid = 0;
		
		if($meta_key == 'how_it_content'){
			
			$svg_code = $request->input('svg_code');
			$field_title = $request->input('field_title');
			$field_detail = $request->input('field_detail');			
			$field_order = 0;
			
			if($field_type == 'repeater'){													
				$first_rec = DB::table('page_meta')            
				->select('*') 
				->where([['meta_key','=',$meta_key],['pid','=',$pid]])           		            
				->orderby('field_order', 'desc')->first();							
				if(!empty($first_rec)){
					$field_order = $first_rec->field_order;	
				}				
				$field_order=$field_order+1;								
			}						
			$meta_value = $svg_code.':::@@'.$field_title.':::@@'.$field_detail;			
			$data = array('pid'=>$pid,'field_name'=>'',"field_type"=>$field_type,"meta_key"=>$meta_key,"meta_value"=>$meta_value,"field_order"=>$field_order);					
			$insid = DB::table('page_meta')->insert($data);						
			return back()->with('success_custom', "Custom Fields Has Been Added Successfully.");
		}

		if($meta_key == 'brand_product'){
			
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');
			$tagcat  = $request->input('tagcat');
			
												
			$field_order = 0;			
			if($field_type == 'repeater'){													
				$first_rec = DB::table('page_meta')            
				->select('*') 
				->where([['meta_key','=',$meta_key],['pid','=',$pid]])           		            
				->orderby('field_order', 'desc')->first();							
				if(!empty($first_rec)){
					$field_order = $first_rec->field_order;	
				}				
				$field_order=$field_order+1;								
			}
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;																					
				}			
			}			
			$meta_value = $caption;			 
			$data = array('pid'=>$pid,'field_name'=>'',"field_type"=>$field_type,"meta_key"=>$meta_key,"meta_value"=>$meta_value,"img"=>$imgs,"btxt"=>$bttxt,"pro_id"=>$tagpro,"cid"=>$tagcat,"field_order"=>$field_order); 
			$insid = DB::table('page_meta')->insert($data);						
			return back()->with('success_custom', "Custom Fields Has Been Added Successfully.")->with('meta_key', $meta_key);			 			
		}

		if($meta_key == 'cat_product'){
			
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');
			$tagcat  = $request->input('tagcat');
			
												
			$field_order = 0;			
			if($field_type == 'repeater'){													
				$first_rec = DB::table('page_meta')            
				->select('*') 
				->where([['meta_key','=',$meta_key],['pid','=',$pid]])           		            
				->orderby('field_order', 'desc')->first();							
				if(!empty($first_rec)){
					$field_order = $first_rec->field_order;	
				}				
				$field_order=$field_order+1;								
			}
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;																					
				}			
			}			
			$meta_value = $caption;			 
			$data = array('pid'=>$pid,'field_name'=>'',"field_type"=>$field_type,"meta_key"=>$meta_key,"meta_value"=>$meta_value,"img"=>$imgs,"btxt"=>$bttxt,"pro_id"=>$tagpro,"cid"=>$tagcat,"field_order"=>$field_order); 
			$insid = DB::table('page_meta')->insert($data);						
			return back()->with('success_custom', "Custom Fields Has Been Added Successfully.")->with('meta_key', $meta_key);			 			
		}
		
		if($meta_key == 'home_slider'){
			
			$tagpro  = 0;
			$bttxt   = $request->input('bttxt');
			$caption = $request->input('caption');
												
			$field_order = 0;			
			if($field_type == 'repeater'){													
				$first_rec = DB::table('page_meta')            
				->select('*') 
				->where([['meta_key','=',$meta_key],['pid','=',$pid]])           		            
				->orderby('field_order', 'desc')->first();							
				if(!empty($first_rec)){
					$field_order = $first_rec->field_order;	
				}				
				$field_order=$field_order+1;								
			}
			
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;																					
				}			
			}			
			$meta_value = $caption;			 
			$data = array('pid'=>$pid,'field_name'=>'',"field_type"=>$field_type,"meta_key"=>$meta_key,"meta_value"=>$meta_value,"img"=>$imgs,"btxt"=>$bttxt,"pro_id"=>$tagpro,"field_order"=>$field_order); 
			$insid = DB::table('page_meta')->insert($data);						
			return back()->with('success_custom', "Custom Fields Has Been Added Successfully.")->with('meta_key', $meta_key);			 			
		}
		
		if($meta_key == 'new_prod'){
			
			$tagpro  = $request->input('tagpro');
			$bttxt   = (!empty($tagpro))?get_product_name_by_id($tagpro):'';
			$field_order = 0;			
			if($field_type == 'repeater'){													
				$first_rec = DB::table('page_meta')            
				->select('*') 
				->where([['meta_key','=',$meta_key],['pid','=',$pid]])           		            
				->orderby('field_order', 'desc')->first();							
				if(!empty($first_rec)){
					$field_order = $first_rec->field_order;	
				}				
				$field_order=$field_order+1;								
			}
			if($request->hasFile('img')){
				if($request->file('img')->isValid()){													
					$file = $request->file('img');
					$name = time().$file->getClientOriginalName();					
					$file->move(public_path('products/'),$name);
					$imgs = $name;																					
				}			
			}			
			$meta_value = $bttxt;	
			$data = array('pid'=>$pid,'field_name'=>'',"field_type"=>$field_type,"meta_key"=>$meta_key,"meta_value"=>$tagpro,"img"=>$imgs,"pro_id"=>$tagpro,"field_order"=>$field_order); 								
			$insid = DB::table('page_meta')->insert($data);
			return back()->with('success_custom', "Custom Fields Has Been Added Successfully.")->with('meta_key', $meta_key);				
		}
		
	}
	
	public function update(Request $request){
		
		$id = $request->input('id');
		if(!empty($id)){
			
			$data = array(			  
			  'page_name'=>$request->page_name,		  			  
			  'display_name'=>($request->display_name)?$request->display_name:'',
			  'meta_title'=>($request->meta_title)?$request->meta_title:'',
			  'meta_desc'=>($request->meta_desc)?$request->meta_desc:'',
			  'meta_keyword'=>($request->meta_keyword)?$request->meta_keyword:'',			  
			  'page_content'=>($request->page_content)?$request->page_content:'',			  
			  'page_status'=>$request->page_status,			  			 
			);			
			
			Cmspage::where('id',$id)->first()->update($data);
			return Redirect::route('cmspage')->with('success', "Record Has Been Updated Successfully.");			
			
		}
		
			
	}

	public function edit($id){
		 $data = array();			 
		 $data['attrname'] = 'Page';
		 $data['dbname'] = 'page';		 		 
		 $data['back_router'] = 'cmspage';		 	 		 		 		 		 		 
		 $results=DB::table('cms_page')->where('id',$id)->first();		 
		 $data['pdata'] = $results;
		 
		 $final_custom_field=array();
		 
		 $custom_field_val = array();
		 $custom_field = $results->custom_field;
		 if(!empty($custom_field)){
			 			
			$fields = explode(",",$custom_field);	 
			
			foreach($fields as $filed){
				
			    $filed_arr = explode(":",$filed);
				
				
				
				$field_key = $filed_arr[0];
				$repeate = $filed_arr[1];
				
				if(!empty($field_key)){
					$final_custom_field[]=$field_key;
					//if($repeate){					
						$field_val_ff = DB::table('page_meta')            
						->select('*') 
						->where([['meta_key','=',$field_key],['pid','=',$id]])           		            
						->orderby('field_order', 'desc')->get();					
						$custom_field_val[$field_key]=$field_val_ff;					
					/*}else{
						$field_val_ff = DB::table('page_meta')            
						->select('*') 
						->where([['meta_key','=',$field_key],['pid','=',$id]])           		            
						->orderby('field_order', 'desc')->get();					
						$custom_field_val[$field_key]=$field_val_ff;						
					}*/
				}
			}			
			$data['custom_field_val'] = $custom_field_val; 
			
			
			
		 }

		 $data['custom_field'] = $final_custom_field;
		 

		 		 		 		 		 		 		 	 		 		 
		 return view('admin/cmspage/edit')->with("data",$data);
		 
	}
	
	public function add(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Page';
		 $data['dbname'] = 'page';		 		 		 
		 $data['back_router'] = 'cmspage';		 				 		 	 		 		 		 
		 return view('admin/cmspage/add')->with("data",$data);		 		  
	}
	
	public function create(Request $request){
		
		$cmspage = new Cmspage();
		$cmspage->page_name = $request->page_name;
		$cmspage->display_name = (!empty($request->display_name))?$request->display_name:'';
		$cmspage->meta_title = $request->page_name;
		
		$cmspage->page_key = 'general';
		
		$cmspage->page_status = $request->page_status;
		
		$cmspage->page_content = (!empty($request->page_content))?$request->page_content:'';
		$cmspage->save();
		return Redirect::route('cmspage')->with('success', "Record Has Been Added Successfully."); 
		
	}
	
}

<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator,Redirect,Response;
use App\adminpanel\Setting;
use Auth;
use DB;
use File;

class SettingController extends Controller{

	  public function __construct(){
		$this->middleware('auth');
	  }
	      
	  public function index(){     		 	 
		 $data = array(
			'tabs'  => $this->setings_option_tabs(),
			'action'=> url('/').'/adminpanel/setting/update_general',
			'id'    => 'general'
		 );		 		 
		 return view('admin/setting')->with("data",$data);	
	  }	
	  	  
	  public function setings_option_tabs(){
		$data=array();
		$data[]=array('id'=>'general','name'=>'General','url'=>url('/').'/adminpanel/general_option');
		$data[]=array('id'=>'email','name'=>'Email','url'=>url('/').'/adminpanel/email_option');				
		return $data;
	 }
	 
	 public function email_option(){
		 
		 $data = array(
			'tabs'  => $this->setings_option_tabs(),
			'action'=> url('/').'/adminpanel/setting/update_email',
			'id'    => 'email'
		 );		 		 
		 return view('admin/emailsetting')->with("data",$data);
		 		 
	 }

	 public function update_email(Request $request){
       

	   		DB::table('setting_master')->where('meta_key','contact_email_subject')->update(['meta_value' => $request->contact_email_subject]);
	   		DB::table('setting_master')->where('meta_key','contact_email_body')->update(['meta_value' => $request->contact_email_body]);

	   
	   		DB::table('setting_master')->where('meta_key','from_email')->update(['meta_value' => $request->from_email]);
	   		DB::table('setting_master')->where('meta_key','admin_notification_email')->update(['meta_value' => $request->admin_notification_email]);
	   
			DB::table('setting_master')->where('meta_key','order_email_subject')->update(['meta_value' => $request->order_email_subject]);
			DB::table('setting_master')->where('meta_key','order_admin_email_subject')->update(['meta_value' =>$request->order_admin_email_subject]);
			DB::table('setting_master')->where('meta_key','order_email_body')->update(['meta_value' =>$request->order_email_body]);
			
			return Redirect::route('email_option')->with('success', "Email Settings Has Been Updated Successfully.");
		
	 }

	 
	 public function general_option(){		 
		 $data = array(
			'tabs'  => $this->setings_option_tabs(),
			'action'=> url('/').'/adminpanel/setting/update_general',
			'id'    => 'general'
		 );		 		 
		 return view('admin/setting')->with("data",$data);		 
	 }
	 
	 public function update_general(Request $request){

        
		if(isset($request->visacard)){
			DB::table('setting_master')->where('meta_key','visacard')->update(['meta_value' => $request->visacard]);
		}else{
			DB::table('setting_master')->where('meta_key','visacard')->update(['meta_value' =>'']);
		}
		
		if(isset($request->mastercard)){
			DB::table('setting_master')->where('meta_key','mastercard')->update(['meta_value' => $request->mastercard]);
		}else{
			DB::table('setting_master')->where('meta_key','mastercard')->update(['meta_value' =>'']);
		}
				
		if(isset($request->cash)){
			DB::table('setting_master')->where('meta_key','cash')->update(['meta_value' => $request->cash]);
		}else{
			DB::table('setting_master')->where('meta_key','cash')->update(['meta_value' =>'']);
		}       

		 
        DB::table('setting_master')->where('meta_key','site_name')->update(['meta_value' => $request->site_name]);
        DB::table('setting_master')->where('meta_key','site_phone')->update(['meta_value' => $request->site_phone]);
        DB::table('setting_master')->where('meta_key','site_email')->update(['meta_value' => $request->site_email]);
		
		
		DB::table('setting_master')->where('meta_key','instagram_link')->update(['meta_value' => $request->instagram_link]);
		DB::table('setting_master')->where('meta_key','facebook_link')->update(['meta_value' => $request->facebook_link]);
		DB::table('setting_master')->where('meta_key','linkedin_link')->update(['meta_value' => $request->linkedin_link]);
		

		DB::table('setting_master')->where('meta_key','first_period')->update(['meta_value' => $request->first_period]);
		DB::table('setting_master')->where('meta_key','second_period')->update(['meta_value' => $request->second_period]);
		DB::table('setting_master')->where('meta_key','third_period')->update(['meta_value' => $request->third_period]);
		
		DB::table('setting_master')->where('meta_key','store_address')->update(['meta_value' => $request->store_address]);		
		DB::table('setting_master')->where('meta_key','copy_rights')->update(['meta_value' => $request->copy_rights]);
		
		DB::table('setting_master')->where('meta_key','productlist_quote')->update(['meta_value' => $request->productlist_quote]);		
		DB::table('setting_master')->where('meta_key','deposit_notice')->update(['meta_value' => $request->deposit_notice]);
		
		DB::table('setting_master')->where('meta_key','related_pro_title')->update(['meta_value' => $request->related_pro_title]);
		
		DB::table('setting_master')->where('meta_key','blocking_days')->update(['meta_value' => $request->blocking_days]);		
		
		
		if($request->hasFile('site_logo')){
			if($request->file('site_logo')->isValid()){								
				$site_logo = get_option('site_logo');
				if(!empty($site_logo)){
					File::delete(public_path('images/').$site_logo);
				}
                $file = $request->file('site_logo');
				$name = time().$file->getClientOriginalName();
				
				$file->move(public_path('images/'),$name);
								
				DB::table('setting_master')->where('meta_key','site_logo')->update(['meta_value' => $name]);												
			}			
		}
		
		if($request->hasFile('site_favicon_logo')){
			if($request->file('site_favicon_logo')->isValid()){								
				$site_favicon_logo = get_option('site_favicon_logo');
				if(!empty($site_favicon_logo)){
					File::delete(public_path('images/').$site_favicon_logo);
				}
                $file = $request->file('site_favicon_logo');
				$name = time().$file->getClientOriginalName();
				$file->move(public_path('images/'),$name);				
				DB::table('setting_master')->where('meta_key','site_favicon_logo')->update(['meta_value' => $name]);												
			}			
		}						
        return Redirect::route('general_option')->with('success', "General Settings Has Been Updated Successfully.");
				 
		 
		 
		 
	 }
	
}

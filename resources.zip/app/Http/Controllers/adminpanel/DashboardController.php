<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\adminpanel\Dashboard;

use Auth;

class DashboardController extends Controller{

  public function __construct(){
        $this->middleware('auth');
  }	
  public function index(){     
	 /*if(Auth::user()){	 
	 	
		$udata = Auth::user();
		print_r($udata);
		die;
		
	 }*/
	 
	 return view('admin/dashboard')->with("userData",'tt');	
  }	
   
}

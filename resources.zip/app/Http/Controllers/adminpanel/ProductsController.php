<?php

namespace App\Http\Controllers\adminpanel;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use File;
use App\adminpanel\Productattributesmodal;
use App\adminpanel\Products;

use App\adminpanel\Productcategory;

class ProductsController extends Controller{
    
	private $post_per_page=10;
	  
	public function __construct(){
		$this->middleware('auth');
	}
	
	public function index(Request $request){		       		 	 
		
		
		//DB::table('products')->where('pro_id',4)->limit(1)->update(['pro_order' => 2]);
		//DB::table('products')->where('pro_id',5)->limit(1)->update(['pro_order' => 1]);
		
		$data = array();	
		$postperpage=$this->post_per_page; $search='';
		if($request->postperpage){$postperpage=$request->postperpage;}
							 			 		 		 		 			 
		$products=Products::orderby('pro_order','desc')->paginate($postperpage, ['*'], 'page');		
		$products = DB::table('products as pro')
			 ->join('product_attributes as patr1', function ($join) {
					$join->on('patr1.attr_id', '=', 'pro.pro_color')
						 ->where('patr1.attr_type', '=', 'color');
				})
			 ->join('product_attributes as patr2', function ($join) {
					$join->on('patr2.attr_id', '=', 'pro.pro_brand')
						 ->where('patr2.attr_type', '=', 'brand');
				})				
			 ->join('product_attributes as patr3', function ($join) {
					$join->on('patr3.attr_id', '=', 'pro.pro_type')
						 ->where('patr3.attr_type', '=', 'type');
				})				
			->select(array('pro.*', 'patr1.attr_id', 'patr1.attr_name as color', 'patr2.attr_id', 'patr2.attr_name as brand', 'patr3.attr_id', 'patr3.attr_name as type'))									
			->orderby('pro.pro_order', 'desc')
			->paginate($postperpage, ['*'], 'page');								
		$products->appends(request()->query())->links();
		
		
		
								 								        		 		
		$data['products'] = $products;			
		$data['search'] = $search;
		$data['postperpage'] = $postperpage;	
							 		 		 	 		 		 				
		return view('admin/products/list')->with("data",$data);						 						
	}	

	public function search(Request $request){

		$data = array();	
		$postperpage=$this->post_per_page; $search=$request->search;
		if($request->postperpage){$postperpage=$request->postperpage;}
							 			 		 		 		 			 
		$products = Products::orderby('pro_order','desc')->paginate($postperpage, ['*'], 'page');
				
		$products = DB::table('products as pro')
			 ->join('product_attributes as patr1', function ($join) {
					$join->on('patr1.attr_id', '=', 'pro.pro_color')
						 ->where('patr1.attr_type', '=', 'color');
				})
			 ->join('product_attributes as patr2', function ($join) {
					$join->on('patr2.attr_id', '=', 'pro.pro_brand')
						 ->where('patr2.attr_type', '=', 'brand');
				})				
			 ->join('product_attributes as patr3', function ($join) {
					$join->on('patr3.attr_id', '=', 'pro.pro_type')
						 ->where('patr3.attr_type', '=', 'type');
				})				
			->select(array('pro.*', 'patr1.attr_id', 'patr1.attr_name as color', 'patr2.attr_id', 'patr2.attr_name as brand', 'patr3.attr_id', 'patr3.attr_name as type'))									
			
			->where('pro.pro_name','LIKE','%'.$search.'%')->orWhere('patr1.attr_name','LIKE','%'.$search.'%')->orWhere('patr2.attr_name','LIKE','%'.$search.'%')
			->orWhere('patr3.attr_name','LIKE','%'.$search.'%')
			
			->orderby('pro.pro_order', 'desc')
			->paginate($postperpage, ['*'], 'page');
											
		$products->appends(request()->query())->links();
								 								        		 		
		$data['products'] = $products;			
		$data['search'] = $search;
		$data['postperpage'] = $postperpage;	
							 		 		 	 		 		 				
		return view('admin/products/list')->with("data",$data);
		
		
	}

	public function update(Request $request){				
		 $pro_id = $request->input('pro_id');
		 if(!empty($pro_id)){
			
			$pro_name = $request->pro_name;
			$pro_slug = '';		
			
			$pro_detail_images_data = $request->pro_detail_images_data;
			
			$pro_detail_images_data_old = $request->pro_detail_images_data_old;
			if(!empty($pro_detail_images_data) && !empty($pro_detail_images_data_old)){
				$pro_det_arr = explode(",",$pro_detail_images_data);
				$pro_det_arr_old = explode(",",$pro_detail_images_data_old);								
				if(!empty($pro_det_arr_old)){
					foreach($pro_det_arr_old as $delimg){
					  if(!in_array($delimg,$pro_det_arr)){	
						File::delete(public_path('products/').$delimg);
					  }
					}
				}					
			}
													

			$category = $request->category;
			if(!empty($category)){
				DB::table('pro_cat_rel')->where('pro_id',$pro_id)->delete();							
				foreach($category as $cat){				
					$data = array('pro_id'=>$pro_id,"cid"=>$cat);					
					DB::table('pro_cat_rel')->insert($data);																
				}			
			}

			
			$products = new Products();															
			$data = array(			  
			  'pro_name'=>$pro_name,
			  'pro_display_name'=>$request->pro_display_name,			  
			  'pro_slug'=>$pro_slug,		  
			  'pro_price'=>$request->pro_price,
			  'pro_sale_price'=>$request->pro_sale_price,
			  'pro_market_value'=>$request->pro_market_value,
			  'pro_deposit'=>$request->pro_deposit,
			  'pro_description'=>($request->pro_description)?$request->pro_description:'',
			  'pro_size'=>($request->pro_size)?$request->pro_size:'',
			  'pro_material'=>($request->pro_material)?$request->pro_material:'',
			  'pro_styling_tips'=>($request->pro_styling_tips)?$request->pro_styling_tips:'',		  
			  'pro_color'=>($request->pro_color)?$request->pro_color:0,
			  'pro_brand'=>($request->pro_brand)?$request->pro_brand:0,
			  'pro_type'=>($request->pro_type)?$request->pro_type:0,
			  'pro_detail_images'=>$request->pro_detail_images_data,
			  'pro_status'=>$request->pro_status,			  			 
			);						

			if((!empty($request->block_start_date))){			
				$block_start_date = $request->block_start_date;
				$block_start_date = date("Y-m-d", strtotime($block_start_date));
				$data['block_start_date'] = $block_start_date;				
			}else{
				$data['block_start_date'] = NULL;				
			}
			
			if((!empty($request->block_end_date))){			
				$block_end_date = $request->block_end_date;
				$block_end_date = date("Y-m-d", strtotime($block_end_date));
				$data['block_end_date'] = $block_end_date;
			}else{
				$data['block_end_date'] = NULL;	
			}


			if($request->hasFile('pro_relpro_img')){
				if($request->file('pro_relpro_img')->isValid()){																		
					$pro_relpro_img = $request->pro_relpro_img_old;
					if(!empty($pro_relpro_img)){
						File::delete(public_path('products/').$pro_relpro_img);
					}									
					$file = $request->file('pro_relpro_img');
					$name = time().'-'.$file->getClientOriginalName();
					$file->move(public_path('products/'),$name);														
					$data['pro_relpro_img']=$name;																	
				}			
			}

			if($request->hasFile('pro_cart_image')){
				if($request->file('pro_cart_image')->isValid()){																		
					$pro_cart_image = $request->pro_cart_image_old;
					if(!empty($pro_cart_image)){
						File::delete(public_path('products/').$pro_cart_image);
					}									
					$file = $request->file('pro_cart_image');
					$name = time().'-'.$file->getClientOriginalName();
					$file->move(public_path('products/'),$name);														
					$data['pro_cart_image']=$name;																	
				}			
			}
			
			if($request->hasFile('pro_main_image')){
				if($request->file('pro_main_image')->isValid()){																		
					$pro_main_image = $request->pro_main_image_old;
					if(!empty($pro_main_image)){
						File::delete(public_path('products/').$pro_main_image);
					}									
					$file = $request->file('pro_main_image');
					$name = time().'-'.$file->getClientOriginalName();
					$file->move(public_path('products/'),$name);														
					$data['pro_main_image']=$name;																	
				}			
			}												 						
												
			Products::where('pro_id', $pro_id)->first()->update($data);
			return Redirect::route('products')->with('success', "Record Has Been Updated Successfully.");			 			
		 }								  
	}
	
	public function deleteproimg(Request $request){
		
		$imgname = $request->imgname;
		if(!empty($imgname)){
			if($request->screen == 'add'){
				
			}else{
				File::delete(public_path('products/').$imgname);				
			}			
		}
		$response = array(
			  'status' => 1,
			  'data' => $imgname,			 
		);
		return response()->json($response);		
		
	}
	
	public function productdetailimages(Request $request){
		
		$data=array();						
		if($request->hasfile('pro_detail_images')){			
            foreach($request->file('pro_detail_images') as $file){
                $name = time().'-'.$file->getClientOriginalName();                				
				if($request->screen == 'add'){		
					$file->move(public_path('tempimg/'),$name); 
				}else{
					$file->move(public_path('products/'),$name); 
				}
                $data[] = $name;  
            }							
		}		
		if(!empty($request->pro_detail_images_data)){			
			$olddata=explode(",",$request->pro_detail_images_data);
			$data=array_merge($olddata,$data);	
		}		
		$response = array(
			  'status' => (!empty($data))?1:0,
			  'data' => (!empty($data))?implode(",",$data):'',
			  'adata' => (!empty($data))?$data:'',
		);
		return response()->json($response); 				
		
	}

	public function create(Request $request){	
	   		
			
        $pro_name = $request->pro_name;
        $pro_slug = '';
		$pro_main_image='';
		
		$pro_cart_image='';
			    
		if($request->hasFile('pro_main_image')){
			if($request->file('pro_main_image')->isValid()){								
				
                $file = $request->file('pro_main_image');
				$name = time().'-'.$file->getClientOriginalName();
				$file->move(public_path('products/'),$name);				
				$pro_main_image=$name;												
			}			
		}
		
		if($request->hasFile('pro_cart_image')){
			if($request->file('pro_cart_image')->isValid()){								
				
                $file = $request->file('pro_cart_image');
				$name = time().'-'.$file->getClientOriginalName();
				$file->move(public_path('products/'),$name);				
				$pro_cart_image=$name;												
			}			
		}
		
		$pro_relpro_img='';
		if($request->hasFile('pro_relpro_img')){
			if($request->file('pro_relpro_img')->isValid()){				
                $file = $request->file('pro_relpro_img');
				$name = time().'-'.$file->getClientOriginalName();
				$file->move(public_path('products/'),$name);				
				$pro_relpro_img=$name;												
			}			
		}						
		
		$pro_order = 0;					
		$first_rec = DB::table('products')            
		->select('*')            		            
		->orderby('pro_order', 'desc')->first();							
		if(!empty($first_rec)){
			$pro_order = $first_rec->pro_order;	
		}				
		$pro_order=$pro_order+1;
						
		if(!empty($request->pro_detail_images_data)){			
			$iimdata=explode(",",$request->pro_detail_images_data);
			foreach($iimdata as $pdim){				
				File::move(public_path('tempimg/'.$pdim), public_path('products/'.$pdim));								
				File::delete(public_path('tempimg/'.$pdim));								
			}			
		}												
				
		$products = new Products();
		$products->pro_name = $pro_name;		
		$products->pro_display_name = $request->pro_display_name;
				
		$products->pro_main_image = $pro_main_image;		
		$products->pro_cart_image = $pro_cart_image;		
		$products->pro_relpro_img = $pro_relpro_img;
		
		$products->pro_price = $request->pro_price;
		$products->pro_sale_price = $request->pro_sale_price;
		
		$products->pro_market_value = $request->pro_market_value;
		$products->pro_deposit = $request->pro_deposit;
		$products->pro_description = ($request->pro_description)?$request->pro_description:'';		
		$products->pro_size = ($request->pro_size)?$request->pro_size:'';		
		$products->pro_material = ($request->pro_material)?$request->pro_material:'';
		$products->pro_styling_tips = ($request->pro_styling_tips)?$request->pro_styling_tips:'';
		$products->pro_color = ($request->pro_color)?$request->pro_color:0;
		$products->pro_brand = ($request->pro_brand)?$request->pro_brand:0;
		$products->pro_type = ($request->pro_type)?$request->pro_type:0;		
		$products->pro_detail_images = ($request->pro_detail_images_data)?$request->pro_detail_images_data:'';
		$products->pro_status = $request->pro_status;
		$products->pro_order = $pro_order;		
		$products->save();
		
		$pro_id = $products->pro_id;
		
		$category = $request->category;
		if(!empty($category)){			
			foreach($category as $cat){				
				$data = array('pro_id'=>$pro_id,"cid"=>$cat);					
				DB::table('pro_cat_rel')->insert($data);																
			}			
		}
		 
		
		return Redirect::route('products')->with('success', "Record Has Been Added Successfully."); 
			  
	}
	
	
	  	
	public function add(){	  		 		  
		 $data = array();			 
		 $data['attrname'] = 'Product';
		 $data['dbname'] = 'product';		 		 		 
		 $data['back_router'] = 'products';		 				 		 	 		 		 
		 
		 $data['color'] = Productattributesmodal::get_attribute('color');
		 $data['brand'] = Productattributesmodal::get_attribute('brand');
		 $data['type'] = Productattributesmodal::get_attribute('type');
		 
		 $productcats=Productcategory::orderby('corder','desc')->where('cstatus','=',1)->get();		
		 $data['productcats'] = $productcats;			
		 
		 
		 return view('admin/products/add')->with("data",$data);		 		  
	}
	
	public function edit($id){
		 
		 $data = array();			 
		 $data['attrname'] = 'Product';
		 $data['dbname'] = 'product';		 		 
		 $data['back_router'] = 'products';		 
		 $data['color'] = Productattributesmodal::get_attribute('color');
		 $data['brand'] = Productattributesmodal::get_attribute('brand');
		 $data['type'] = Productattributesmodal::get_attribute('type');		 
		 		 		 		 		 
		 $results=DB::table('products')->where('pro_id',$id)->first();		 
		 $data['pdata'] = $results;
		 		 		 		 	
		 $productcats=Productcategory::orderby('corder','desc')->where('cstatus','=',1)->get();		
		 $data['productcats'] = $productcats;
		 
		 $selcats=array();
		 $selectedcats=DB::table('pro_cat_rel')->select('*')->where('pro_id','=',$id)->get();		
		 if(!empty($selectedcats)){
			 foreach($selectedcats as $selc){
				 $selcats[]=$selc->cid;
			 }
		 }		 		 		 
		 $data['selcats'] = $selcats;		 	
		 		 																			 		 	 		 		 
		 return view('admin/products/edit')->with("data",$data);		 		 		  		  
	}	
	
	
	public function delete(Request $request){
	  if($request->pro_id){
		  
		  $first_rec = DB::table('products')            
		  ->select('*')            		            
		  ->where('pro_id',$request->pro_id)->first();		  
		  
		  if(!empty($first_rec)){			 
			 $pro_main_image = $first_rec->pro_main_image;			 
			 if(!empty($pro_main_image)){
				 File::delete(public_path('products/').$pro_main_image);			 
			 }			
			 $pro_detail_images = $first_rec->pro_detail_images;
			 if(!empty($pro_detail_images)){
				$pro_detail_images_arr = explode(',',$pro_detail_images);
				if(!empty($pro_detail_images_arr)){
					foreach($pro_detail_images_arr as $proval){
						File::delete(public_path('products/').$proval);	
					}
				}
			 }			 	
		  }		  		  		  		  	
		  Products::orderby('pro_order','desc')->where('pro_id',$request->pro_id)->delete();			
	  }
	  return Redirect::route('products')->with('success', "Record Has Been Deleted Successfully.");		  
	}	
			
	
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Validator,Redirect,Response;
use App\adminpanel\Productattributes;
use Auth;
use DB;
use File;
use App\adminpanel\Products;

class FrontajxController extends Controller{
   
   
	  public function prod_filt(Request $request){
		  
		  	  
			  $limit = 4;
			  $proddata = '';
			  $color = $request->color;
			  $brand = $request->brand;
			  $type  = $request->type;			  
			  $fetorderby  = $request->orderby;			  
			  $rindex  = $request->rindex;			  
			  $order_by = 'pro_order';
			  $order    = 'desc';
			  
			  
			  //$counts   = Products::where('pro_status',1)->orderby('pro_order','desc')->get();
			  //$total    = $counts->count(); 
			  $products = Products::where('pro_status',1)->orderby('pro_order','desc')->offset($rindex)->limit($limit)->get();
			  
			  if(!empty($fetorderby)){
				  if($fetorderby == 'pricelowhigh'){
					  $order_by = 'pro_price';
					  $order    = 'asc';					  
				  }else if($fetorderby == 'pricehighlow'){
					  $order_by = 'pro_price';
					  $order    = 'desc';					  
				  }else{
					  $order_by = 'pro_order';
					  $order    = 'desc';					  
				  }
				  //$counts   = Products::where('pro_status',1)->orderby($order_by,$order)->get();
				  //$total    = $counts->count(); 				  
				  $products = Products::where('pro_status',1)->orderby($order_by,$order)->offset($rindex)->limit($limit)->get();
			  }			  
			  if(!empty($color)){
				  //$counts   = Products::where('pro_status',1)->whereIn('pro_color',$color)->orderby('pro_order','desc')->get();
				  //$total    = $counts->count();				  
			  	  $products = Products::where('pro_status',1)->whereIn('pro_color',$color)->orderby('pro_order','desc')->offset($rindex)->limit($limit)->get();
			  }			  
			  if(!empty($brand)){
				  //$counts   = Products::where('pro_status',1)->whereIn('pro_brand',$brand)->orderby('pro_order','desc')->get();
				  //$total    = $counts->count();				  
			  	  $products = Products::where('pro_status',1)->whereIn('pro_brand',$brand)->orderby('pro_order','desc')->offset($rindex)->limit($limit)->get();
			  }			  
			  if(!empty($type)){
				  //$counts   = Products::where('pro_status',1)->whereIn('pro_type',$type)->orderby('pro_order','desc')->get();
				  //$total    = $counts->count();				  
			  	  $products = Products::where('pro_status',1)->whereIn('pro_type',$type)->orderby('pro_order','desc')->offset($rindex)->limit($limit)->get();
			  }
			  			  			  			  			  			  
			  if(!empty($products)){			  	
				$proddata = view('bags-list', compact('products'))->render();							  
			  }	
			  $status = (!empty($proddata))?'Y':'N';
			  
			  $response = array(
				  'status' => $status,
				  'msg' => 'Yes',
				  'pdata' => $proddata,
			  );
			  return response()->json($response); 		  
		  
	  }   
}

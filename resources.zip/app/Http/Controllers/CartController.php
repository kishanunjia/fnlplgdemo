<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Validator,Redirect,Response;
use Auth;
use DB;
use App\Cart;
use App\adminpanel\Products;
use App\adminpanel\Coupon;

class CartController extends Controller{
    
	public function give_feedback(Request $request){
			
			$this->validate($request,[
				'or_id' => 'required|max:250',
				'feedback' => 'required|max:550',
			], [], 
			[
				'feedback' => 'Feedback',
				'or_id' => 'Order',				
			]);
			$coupn = Coupon::orderby('coup_id','desc')->first();  	
			$maxid = (isset($coupn->coup_id))?$coupn->coup_id:1;
			$char_count = strlen($maxid);
			$randchar=get_rand_letters(6-$char_count);
			$code= $maxid.$randchar;			
			$plus_six=date('Y-m-d', strtotime('+6 month', time()));			
			$data = array('coup_code'=>$code,'coup_val'=>10,'coup_type'=>'per','coup_generate'=>'Auto','coup_use'=>1,'coup_start_date'=>date('Y-m-d')
			,'coup_end_date'=>$plus_six);
			DB::table('coupon')->insert($data);					
			$coup_id = DB::getPdo()->lastInsertId();						
			DB::table('order_main')->where([['or_id','=',$request->or_id]])->update(array('feedback'=>$request->feedback,'feedback_coupon'=>$coup_id));			
			return redirect()->back();
			
	}
	
	public function order_completed($or_id=0){
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;		
		$orddata=array();
		$order_main = DB::table('order_main')->select('*')->where([['or_id','=',$or_id],['user_id','=',$user_id]])->first();
		if(empty($order_main)){
			$urls = url('/');
			return redirect($urls);					
		}		
		$orddata['ord_prod'] = DB::table('order_product')->select('*')->where('or_id',$or_id)->get();		
		$orddata['order_main'] = $order_main;
		
		return view('ordercompleted')->with("orddata",$orddata);
			
	}
	
	public function cancel_order(Request $request){
		
		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;
		if(isset($request->or_id)){		
			DB::table('order_main')->where([['or_id','=',$request->or_id],['user_id','=',$user_id]])->update(array('or_status'=>'Cancel'));
		}
		
		return redirect()->back();
		
	}
	
	public function create_order(Request $request){

		$user_id =  Auth::id();
		$user_id = ($user_id)?$user_id:0;		
		$has_allow = must_login_front();
		
		if(!$has_allow){
			$urls = url('/').'/'.get_page_url_by_id(15);
			return redirect($urls);	
		}			
		$cart_total = get_cart_total();		
		if($cart_total == 0){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);
		}
		$crtid = get_cart_id();
		$cart_single = Cart::where('crtid',$crtid)->first();
		$shipadd = $cart_single->shipadd;
		$billadd = $cart_single->billadd;
				
		$cart_prod=get_cart_product();
		if(empty($cart_prod)){
			$urls = url('/').'/'.get_page_url_by_id(7);
			return redirect($urls);				
		}
		
		$error='';		
		foreach($cart_prod as $ccpro){
			$final_blocks_dates = get_product_block_dates_final($ccpro->pro_id);
			$books_date_arr = getDatesFromRange($ccpro->start_date,$ccpro->end_date);
			foreach($books_date_arr as $bookdate){
				if(in_array($bookdate,$final_blocks_dates)){
					$error=$ccpro->pro_name.' Not Avaliable On '.indian_date_formate($bookdate);					
					break;
				}
			}
			
		}

		if($cart_single->coup_id != 0 && !empty($cart_single->coup_id)){
			$discccpn = Coupon::where('coup_id',$cart_single->coup_id)->orderby('coup_id','desc')->first();
			if(empty($discccpn)){
				$error="'$cart_single->coupon_code' Coupon Code Not Avaliable. It's already use by another person.";	
			}else{
				if($discccpn->coup_use == 0){
					$error="'$cart_single->coupon_code' Coupon Code Not Avaliable. It's already use by another person.";	
				}
			}
			$nextuse=($discccpn->coup_use-1);			
			if($discccpn->coup_generate == 'Auto' && $nextuse == 0){
				Coupon::where('coup_id',$cart_single->coup_id)->delete();	
			}else{
				Coupon::where('coup_id',$cart_single->coup_id)->update(array('coup_use'=>$nextuse));	
			}
		}
		
		if(!empty($error)){
			return redirect()->back()->with(['error'=>$error]);	
								
		}
						
		
		$user=DB::table('users')->select('*')->where('id',$user_id)->first();
		$c_total=get_cart_total(true);
		
		
		
		$select = DB::table('customer_address')->select('user_id','fname','lname','email','phone_no','address1','address2','city','state','post_code','type')->where('id',$shipadd);
		$bindings = $select->getBindings();				
		$insertQuery = 'INSERT into order_address (user_id,fname,lname,email,phone_no,address1,address2,city,state,post_code,type) '. $select->toSql();		
		DB::insert($insertQuery, $bindings);
		$ord_shipadd = DB::getPdo()->lastInsertId();
		
		$select = DB::table('customer_address')->select('user_id','fname','lname','email','phone_no','address1','address2','city','state','post_code','type')->where('id',$billadd);
		$bindings = $select->getBindings();				
		$insertQuery = 'INSERT into order_address (user_id,fname,lname,email,phone_no,address1,address2,city,state,post_code,type) '. $select->toSql();		
		DB::insert($insertQuery, $bindings);		
		$ord_billadd = DB::getPdo()->lastInsertId();						
		
		
	    $data = array(
			'user_id'=>$user_id,
			'user_name'=>$user->fname.' '.$user->lname,
			'user_email'=>$user->email,
			'user_phone_no'=>$user->phone_no,			
			'or_total'=>$c_total['withoutdisc'],
			'or_total_final'=>$c_total['total'],			
			'or_deposite'=>get_cart_deposit_total(),			
			'coup_id'=>$cart_single->coup_id,			
			'coup_type'=>$cart_single->coup_type,			
			'coup_val'=>$cart_single->coup_val,
			'coupon_code'=>$cart_single->coupon_code,
			
			'coup_disc'=>$c_total['dicount'],
			
			'shipadd'=>$ord_shipadd,
			'billadd'=>$ord_billadd,
						
			'paymentmethod'=>$cart_single->paymentmethod,
			'card_type'=>$cart_single->card_type,
			'card_number'=>$cart_single->card_number,			
			'card_exp_month'=>$cart_single->card_exp_month,
			'card_exp_year'=>$cart_single->card_exp_year,
			'card_holder'=>$cart_single->card_holder,
			'card_cvv'=>$cart_single->card_cvv,
			'or_status'=>'Processing',
			
	    );		
	    DB::table('order_main')->insert($data);		
		$or_id = DB::getPdo()->lastInsertId();
		
		foreach($cart_prod as $cprod){		   
		   $product   = get_product_by_id($cprod->pro_id);
		   $pro_price = (!empty($product->pro_sale_price))?$product->pro_sale_price:$product->pro_price;	
		   $data = array(
		   		'or_id'=>$or_id,
				'pro_id'=>$cprod->pro_id,
				'pro_name'=>$product->pro_name,
				'pro_brand_name'=>get_brand_name_by_id($cprod->pro_brand),
				'start_date'=>$cprod->start_date,
				'end_date'=>$cprod->end_date,
				'pro_price'=>$pro_price,
				'pro_deposit'=>$product->pro_deposit,
		   );
		   DB::table('order_product')->insert($data);		   
		}
		
		if($or_id){	
		   
		   DB::table('cart_product')->where('crtid',$crtid)->delete();
		   DB::table('cart')->where('crtid',$crtid)->delete();
		   		   
		   $product_list='';
			foreach($cart_prod as $cprod){		   
			   $product   = get_product_by_id($cprod->pro_id);
			   $pro_price = (!empty($product->pro_sale_price))?$product->pro_sale_price:$product->pro_price;
			   $pro_cart_image = (isset($product->pro_cart_image))?$product->pro_cart_image:'';			
			   $product_list.='
			   <table border="0" cellpadding="0" cellspacing="0" align="center" width="100%" role="module" data-type="columns" style="padding:20px 20px 0px 30px;" bgcolor="#FFFFFF">
                   <tbody>
                    <tr role="module-content">
                     <td height="100%" valign="top"><table class="column" width="137" style="width:137px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="">
                       <tbody>
                        <tr>
                         <td style="padding:0px;margin:0px;border-spacing:0;"><table class="wrapper" role="module" data-type="image" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="239f10b7-5807-4e0b-8f01-f2b8d25ec9d7.1">
                           <tbody>
                            <tr>
                             <td style="font-size:6px; line-height:10px; padding:0px 0px 0px 0px;" valign="top" align="left"><img class="max-width" border="0" style="display:block; color:#000000; text-decoration:none; font-family:Helvetica, arial, sans-serif; font-size:16px;" width="104" alt="'.$product->pro_name.'" data-proportionally-constrained="true" data-responsive="false" src="'.asset('products/').'/'.$pro_cart_image.'" height="104"></td>
                            </tr>
                           </tbody>
                          </table></td>
                        </tr>
                       </tbody>
                      </table>
                      <table class="column" width="200" style="width:200px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="">
                       <tbody>
                        <tr>
                         <td style="padding:0px;margin:0px;border-spacing:0;"><table class="module" role="module" data-type="text" border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout: fixed;" data-muid="f404b7dc-487b-443c-bd6f-131ccde745e2.1">
                           <tbody>
                            <tr>
                             <td style="padding:0px 0px 18px 0px; line-height:22px; text-align:inherit;" height="100%" valign="top" bgcolor="" role="module-content"><div>
                               <div style="font-family: inherit; text-align: inherit">'.get_brand_name_by_id($cprod->pro_brand).' - '.$product->pro_name.'</div>
                               <div style="font-family: inherit; text-align: inherit"><span style="color: #000000">'.$pro_price.' Rs.&nbsp;</span></div>
                               <div style="font-family: inherit; text-align: inherit"><span style="color: #000000">
                               Delivery Date:  '.indian_date_formate($cprod->start_date).'</span></div>
							   <div style="font-family: inherit; text-align: inherit"><span style="color: #000000">
                               Return Date:  '.indian_date_formate($cprod->end_date).'</span></div>
                               
                               <div></div>
                              </div></td>
                            </tr>
                           </tbody>
                          </table></td>
                        </tr>
                       </tbody>
                      </table>
                      <table width="137" style="width:137px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-2">
                       <tbody>
                        <tr>
                         <td style="padding:0px;margin:0px;border-spacing:0;"></td>
                        </tr>
                       </tbody>
                      </table>
                      <table width="137" style="width:137px; border-spacing:0; border-collapse:collapse; margin:0px 0px 0px 0px;" cellpadding="0" cellspacing="0" align="left" border="0" bgcolor="" class="column column-3">
                       <tbody>
                        <tr>
                         <td style="padding:0px;margin:0px;border-spacing:0;"></td>
                        </tr>
                       </tbody>
                      </table></td>
                    </tr>
                   </tbody>
                  </table>
			   
			   ';
			   
			}
		   $product_list;
		   
		   $site_logo = get_option('site_logo');
		   $store_address=get_option('store_address');
		   
		   $toName=$user->fname.' '.$user->lname;
           $toEmail=$user->email;
           $fromName=from_name();
           $subject = get_option('order_email_subject');
		   $fromEmail = from_email();
		   
           $headers   = 'MIME-Version: 1.0' . "\r\n";
           $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
           $headers .= 'To: '.$toName.' <'.$toEmail.'>' . "\r\n";
           $headers .= 'From: '.$fromName.' <'.from_email().'>' . "\r\n";
					   		   		   		   
		   $shipping = 0;
		   $body_data = get_option('order_email_body');		   
		   $body_data= str_replace('{{site_logo}}',asset('images/').'/'.$site_logo,$body_data);		   
		   $body_data= str_replace('{{or_id}}',$or_id,$body_data);
		   $body_data= str_replace('{{name}}',$user->fname.' '.$user->lname,$body_data);
		   $body_data= str_replace('{{subtotal}}',$c_total['withoutdisc'].'  Rs.',$body_data);		   
		   $body_data= str_replace('{{discount}}',$c_total['dicount'].'  Rs.',$body_data);
		   $body_data= str_replace('{{shipping}}',$shipping.'  Rs.',$body_data);
		   $body_data= str_replace('{{grandtotal}}',$c_total['total'].'  Rs.',$body_data);		   
		   //$body_data= str_replace('{{grandtotal}}',$c_total['total'].'  Rs.',$body_data);		   
		   $body_data= str_replace('{{store_address}}',$store_address,$body_data);		   
		   $body_data= str_replace('{{product_list}}',$product_list,$body_data);
		   
		   		   
		   $body = body_header();
		   $body.= $body_data;
		   $body.= body_footer();		
           
		   //echo $toEmail.$subject.$body.$headers;
		   //die;
		   
		   if(@mail($toEmail, $subject, $body, $headers)){
             //echo "Mail Sent Successfully";
           }else{
             //echo "Mail Not Sent";
           }   		   

           $headers   = 'MIME-Version: 1.0' . "\r\n";
           $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
           $headers .= 'To: '.admin_to_name().' <'.admin_email().'>' . "\r\n";
           $headers .= 'From: '.$fromName.' <'.from_email().'>' . "\r\n";		   	
           $subject = get_option('order_admin_email_subject');		   		   
		   if(@mail(admin_email(), $subject, $body, $headers)){
			   
		   }
		   
		}
		
		$urls = url('/').'/order-completed/'.$or_id;
		return redirect($urls);					
		
	}
	
	public function card_detail_save(Request $request){
		
		$this->validate($request,[
			'card_type' => 'required|max:250',
			'card_number' => 'required|max:250',
			'card_exp_month' => 'required|max:250',
			'card_exp_year' => 'required|max:250',			
			'card_holder' => 'required|max:250',
			'card_cvv' => 'required|max:250',			
		], [], 
		[
			'card_type' => 'Card Type',
			'card_number' => 'Card Number',
			'card_exp_month' => 'Expiration Month',
			'card_exp_year' => 'Expiration Year',			
			'card_holder' => 'Card Holder',
			'card_cvv' => 'CVV Security Code',							
		]);
		
		$crtid = get_cart_id();
		Cart::where('crtid',$crtid)->first()->update(array(
			'card_type'=>$request->card_type,
			'card_number'=>$request->card_number,
			'card_exp_month'=>$request->card_exp_month,
			'card_exp_year'=>$request->card_exp_year,
			'card_holder'=>$request->card_holder,
			'card_cvv'=>$request->card_cvv
		));	
		
		$urls = url('/').'/'.get_page_url_by_id(19);
		return redirect($urls);				
		
	}
	
	public function add_paymentmethod(Request $request){		
		$this->validate($request,[
			'paymentmethod' => 'required|max:250',
		], [], 
		[
			'shipadd' => 'Payment Method',							
		]);		
		$paymentmethod = $request->paymentmethod;
		$crtid = get_cart_id();
		Cart::where('crtid',$crtid)->first()->update(array('paymentmethod'=>$paymentmethod));
		if($paymentmethod == 'cash'){
			$urls = url('/').'/'.get_page_url_by_id(18);
			return redirect($urls);		
		}		
	}
	
	public function remove_coupon($crtid){
		Cart::where('crtid',$crtid)->first()->update(array('coup_id'=>0,'coup_disc'=>0,'disc_display'=>'','coupon_code'=>''));
		return redirect()->back();
	}
	
	public function del_prod_to_cart($cpid){
		
		//Cart::where('crtid',$crtid)->first()->update(array('coup_id'=>$coup_id,'coup_disc'=>$discount,'disc_display'=>$disc_txt,'coupon_code'=>$coup_code));
		
		$has_prod = DB::table('cart_product')->select('*')->where('cpid',$cpid)->first();
		if(isset($has_prod->crtid)){
			Cart::where('crtid',$has_prod->crtid)->first()->update(array('coup_id'=>0,'coup_disc'=>0,'disc_display'=>'','coupon_code'=>'','coup_type'=>'','coup_val'=>''));
		}
		DB::table('cart_product')->where('cpid',$cpid)->delete();						
		return redirect()->back()->with(['success'=>'Product Successfully deleted.']);
				
	}
	
	public function add_coupon_code(Request $request){									  
			  $crtid = $request->crtid;		
			  $coupon_code = $request->coupon_code;			  
			  $disc_txt = '';				  
			  $discount = 0;
			  $cart=Cart::where('crtid',$crtid)->first();
			  $mcoup_id = (isset($cart->coup_id))?$cart->coup_id:0;
			  $total = 0;
			  $error = 'Error coupon not applicable';			  			  
			  if(!$mcoup_id){
				  $date = date('Y-m-d');
				  $sql = "SELECT * FROM coupon Where coup_use > 0 AND (coup_code = '$coupon_code' AND coup_use > 0) AND (coup_end_date >= $date OR coup_end_date is NULL)"; 
				  $coupon = DB::select($sql);		  
				  if(!empty($coupon)){
					  $coup_id = $coupon[0]->coup_id;
					  $coup_code = $coupon[0]->coup_code;
					  $coup_type = $coupon[0]->coup_type;
					  $coup_val = $coupon[0]->coup_val;				  
					  $total = get_cart_total();
					  if($coup_type == 'per'){
						 $disc_txt = $coup_val.' %';
						 $discount = round(($total*$coup_val)/100);					 
					  }else{
						 $disc_txt = $coup_val.' RS.'; 
						 $discount = $coup_val;
					  }
					  $error = '';				  
					  Cart::where('crtid',$crtid)->first()->update(array(
						  'coup_id'=>$coup_id
						  ,'coup_disc'=>$discount
						  ,'disc_display'=>$disc_txt
						  ,'coupon_code'=>$coup_code
						  ,'coup_type'=>$coup_type
						  ,'coup_val'=>$coup_val						  
					  ));																		  
				  }
			  }else{
				  $error = 'Coupon code already applied.';
			  }
			  $status = (empty($error))?'Y':'N';			  
			  $response = array(
				  'status' => $status,
				  'discount' => $discount,
				  'coupon_code' => $coupon_code,
				  'total' => $total-$discount,
				  'error' => $error,
			  );
			  return response()->json($response);						
	}
	
	public function add_to_cart(Request $request){
		
		$error_msg = '';
		$book_on = '';
		
		$rntperiod = $request->rntperiod;		
		$pro_id = $request->pro_id;				
		
		$start_date = date_to_db($request->start_date);
		$end_date   = date_to_plus_day($request->start_date,($request->rntperiod-1));				
		$blocks_dates = get_product_block_dates_final($pro_id);		
		$books_date_arr = getDatesFromRange($start_date,$end_date);
		
		
		
		$user_id = Auth::id();
		$user_id = ($user_id)?$user_id:0; 
		$ip = ($user_id)?'':get_the_user_ip();		
		if($user_id){
			$cart = Cart::where('user_id',$user_id)->first();			
		}else{
			$cart = Cart::where('ip',$ip)->first();
		}		
		if(!empty($cart)){
			$crtid = $cart->crtid;
			$has_prod = DB::table('cart_product')->select('*')->where([['crtid','=',$crtid],['pro_id','=',$pro_id]])->first();
			if(!empty($has_prod)){
				$error_msg = 'This Product Already Exists In Cart';	
			}
		}
		
		foreach($books_date_arr as $dval){
			if(in_array($dval,$blocks_dates)){
				$book_on = $dval;
				$error_msg = 'This Product Not Avaliable On '.db_to_date($book_on);				
			}
		}		
		if(empty($error_msg)){
											
			$product = Products::where('pro_id',$pro_id)->first();		
			$user = auth()->user();		
			if(empty($cart)){			
				$data = array('ip'=>$ip,'user_id'=>$user_id);
				$insid = DB::table('cart')->insert($data);
				$crtid = DB::getPdo()->lastInsertId();				
			}else{
				$crtid = $cart->crtid;
			}						
			$data = array('crtid'=>$crtid,'pro_id'=>$pro_id,'start_date'=>$start_date,'end_date'=>$end_date,'pro_price'=>$product->pro_price,'pro_deposit'=>$product->pro_deposit);
			$insid = DB::table('cart_product')->insert($data);				
			$cart_data=Cart::where('crtid',$crtid)->first();		
			$cart_total     = $cart_data->cart_total+$product->pro_price;
			$deposite_total = $cart_data->deposite_total+$product->pro_deposit;												
			Cart::where('crtid',$crtid)->first()->update(array('cart_total'=>$cart_total,'deposite_total'=>$deposite_total));
			
			//echo 'Successfully Added....';
			
			return redirect()->back()->with(['error'=>$error_msg,'success'=>'Yes']);
			
		}else{
			//echo $error_msg;
			return redirect()->back()->with(['error'=>$error_msg,'success'=>''])->withInput($request->all());
		}
		
			
				
	}	
	
}

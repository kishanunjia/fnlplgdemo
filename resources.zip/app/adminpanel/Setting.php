<?php

namespace App\adminpanel;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Setting extends Model{
    
}

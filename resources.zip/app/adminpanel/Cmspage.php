<?php

namespace App\adminpanel;
use Cviebrock\EloquentSluggable\Sluggable;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Cmspage extends Model
{

	use Sluggable;

    protected $table = 'cms_page';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['id'];
	protected $primaryKey = 'id';

    public function sluggable()
    {
        return [
            'page_slug' => [
                'source' => 'page_name'
            ]
        ];
    }

}

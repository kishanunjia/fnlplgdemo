<?php

namespace App\adminpanel;
use Cviebrock\EloquentSluggable\Sluggable;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Productcategory extends Model{
    
	use Sluggable;
	
    protected $table = 'product_category';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['cid'];
	protected $primaryKey = 'cid';

    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'cname'
            ]
        ];
    }	
	
}

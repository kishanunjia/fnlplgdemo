<?php

namespace App\adminpanel;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Menu extends Model{
   
    protected $table = 'menu_manage';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['m_id'];
	protected $primaryKey = 'm_id';   
   
}

<?php

namespace App\adminpanel;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Productattributesmodal extends Model
{
    protected $table = 'product_attributes';
    protected $fillable = [];
	protected $dates = ['create_at'];
	
	
    public static function get_attribute($type){	  
	   $result = DB::table('product_attributes')            
		->select('*')            
		->where('attr_type',$type)
		->where('attr_status',1)            
		->orderby('attr_order', 'desc')->get();
		
	   return $result;				 	   
    }
}

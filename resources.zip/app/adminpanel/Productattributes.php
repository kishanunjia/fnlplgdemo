<?php

namespace App\adminpanel;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Productattributes extends Model
{
    protected $table = 'product_attributes';
    protected $fillable = [];
	
	
    public static function get_attribute($type){	  
	   $result = DB::table('product_attributes')            
		->select('*')            
		->where('attr_type',$type)            
		->orderby('attr_order', 'asc');
	   return $result;				 	   
    }	
	
}

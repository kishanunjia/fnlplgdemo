<?php

namespace App\adminpanel;
use Cviebrock\EloquentSluggable\Sluggable;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
	use Sluggable;

    protected $table = 'products';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['pro_id'];
	protected $primaryKey = 'pro_id';

    public function sluggable()
    {
        return [
            'pro_slug' => [
                'source' => 'pro_name'
            ]
        ];
    }

}

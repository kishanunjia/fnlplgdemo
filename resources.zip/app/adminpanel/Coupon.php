<?php

namespace App\adminpanel;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Coupon extends Model{
	
    protected $table = 'coupon';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['coup_id'];
	protected $primaryKey = 'coup_id';	
	    
}

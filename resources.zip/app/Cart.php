<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model{

    protected $table = 'cart';
    protected $fillable = [];
	protected $dates = ['create_at'];
	public $timestamps = false;

	protected $guarded = ['crtid'];
	protected $primaryKey = 'crtid';
	
	

}

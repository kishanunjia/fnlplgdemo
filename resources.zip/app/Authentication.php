<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Authentication extends Model{
   
  public static function getuserData($id=0){

    if($id==0){
      $value=DB::table('users')->orderBy('id', 'asc')->get(); 
    }else{
      $value=DB::table('users')->where('id', $id)->first();
    }
    return $value;
	
  } 
  
   public static function auth_login($data){
	   $users = '';
	   if(isset($data['email']) && isset($data['password'])){
		   $hash_val = md5($data['password']);	   
		   $users = DB::table('users')
						 ->select('*')
						 ->where([
							['email', '=', $data['email']],
							['password', '=', $hash_val],
							['is_admin', '=', 1]
						 ])->get();
	   }
	   return $users;				 	   
   }
      
}
